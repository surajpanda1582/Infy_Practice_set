import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import sun.management.counter.perf.PerfStringCounter;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.DateUtility;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellOmfPerformanceLogsProcessorConsumerCounter extends LineProcessorWithData {

	static private Pattern NUM_DASH_PATTERN = Pattern.compile("[0-9]-- ");
	public static int STATS_SIZE = 500;

	private File currentFile;
	private String currentServer;
	private int serverCount;

	private String startPath = "";
	HashMap<String, HashMap<String, StatisticalDoubleVector>> perfData = new HashMap<String, HashMap<String, StatisticalDoubleVector>>();

	public  static ArrayListNoDuplicates<String> channels = new ArrayListNoDuplicates<String>();
	public  static ArrayListNoDuplicates<String> services = new ArrayListNoDuplicates<String>();
	
	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	private WordString words = new WordString("");

	static FileProcessorWithData fp = null;
	static BellOmfPerformanceLogsProcessorConsumerCounter line = null;

	public static boolean LOG_DATA = false;

	public BellOmfPerformanceLogsProcessorConsumerCounter(String dir, String outDir, String fileStartsWith, String minMs, String maxMs) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { ' ', '[', ']' });

	}

	public void print(OmfParameters data) {
		
		StringWriter writer2;

		Collections.sort(channels);
		Collections.sort(services);

		writer2 = new StringWriter(outDir + File.separator + "channel-services.tab");
		writer2.open();


		writer2.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write(services.get(i) + "\t\t\t\t");
		}
		writer2.writeLine("");
		writer2.write("Channel\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write("Num\tAvg\t90%\tMax\t");
		}
		writer2.writeLine("");

		for (int k = 0; k < channels.size(); k++) {
			String channel = channels.get(k);
			
			writer2.write(channel + "\t");
			HashMap<String, StatisticalDoubleVector> pdata = perfData.get(channel);
			for (int i = 0; i < services.size(); i++) {
				
				StatisticalDoubleVector stats = pdata.get(services.get(i));
				
				if (stats == null) {
					writer2.write("\t\t\t\t");
				} else {
					writer2.write(stats.size() + "\t"+ stats.getAverage() + '\t' + stats.getPercentile(.9) + '\t' + stats.getMaximum() + '\t');	
				}
				
			}
			
			writer2.writeLine("");
			
		}
		writer2.close();
	
		
		System.out.println("Done");

	}		
	
	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			
			str = Utility.replaceString(str, "- Target ", "- ");
			str = Utility.replaceString(str, " (self-tuning)'", "");
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);
			
			if (parms.use(date, timeMs)) {
				
				str = str.replaceAll("\\[ +", "[");
				words.setString(str);

				if (str.indexOf("CACHE_") > 0) {
				    Matcher matcher = NUM_DASH_PATTERN.matcher(str);
				    if (matcher.find()) {
				    	int p = matcher.start(); 
				    	str = str.substring(0, p+1);
				    }
					words.setString(str);
				}

				String txn = words.getWord(6);
				
				txn = txn.replace("OMF.", "");
				int p = str.indexOf(" PERFORMANCE-");
				String txn2 = words.getWord(16);
				if (txn2 != null) txn2 = txn2.replace("OMF.", "");
				String srvTxn2 = txn2;
				if (p > 0) {
					txn2 = str.substring(p+13).trim();
				}

				String channel = words.getWord(8);
				String hoi = words.getWord(10);
				String stxnPerf = words.getWord(words.getWordCount()-1);
				p = stxnPerf.lastIndexOf(':');
				if (p > 0) {
					stxnPerf = stxnPerf.substring(p+1);
				}
				
				if (Utility.isNumber(stxnPerf)) {
					long txnPerf = Long.parseLong(stxnPerf);
					
					//String consumer = words.getWord(8);
					String txnSrvcName = null;

					p = txn.indexOf('.');
					//String txnOperName = "";
					txnSrvcName = txn;
					if (p > 0) {
						//txnOperName = txn.substring(p+1);
						txnSrvcName = txn.substring(0, p);
					}
					
					if (srvTxn2 != null && srvTxn2.indexOf(txnSrvcName+'.') >= 0) {
						srvTxn2 = txnSrvcName;
					}
					
					if (txn != null && txn.length() > 0 && txnSrvcName.equals(srvTxn2)) {
						
						HashMap<String, StatisticalDoubleVector> pdata = perfData.get(channel);
						if (pdata == null) {
							pdata = new HashMap<String, StatisticalDoubleVector>();
							perfData.put(channel, pdata);
						}
						StatisticalDoubleVector stats = pdata.get(txn);
						if (stats == null) {
							stats = new StatisticalDoubleVector(5000, 1000);
							pdata.put(txn, stats);
						}
						
						stats.add(txnPerf);
						channels.add(channel);
						services.add(txn);
					}
				} 
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data, long start) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
//				int p = child.getName().lastIndexOf('.');
//				String ext = child.getName().substring(p+1);
//				int num = 999;
//				if (!ext.equals("log")) {
//					try {
//						num -= Integer.parseInt(ext);
//					} catch (NumberFormatException ignored) {
//						
//					}
//				}
//				
//				files.add(String.valueOf(num) + "-" + child.getName());
				files.add(getStartTime(child.getAbsolutePath()) + "|" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName1 = files.get(i);
			int pos = fileName1.indexOf('|');
			String fileName = fileName1.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				long time = 0;
				if (i > 0) {
					long msPer = ((System.currentTimeMillis()-start) / (i));
					time = (files.size()-i) * msPer;
					System.out.println("Processing: "+fileName1 + " approximately " + Utility.longTo24DayHour((time+500)/1000L) + " - each: " + Utility.longTo24HourMilli(msPer));
				} else {
					System.out.println("Processing: "+fileName1);
					
				}
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data, start);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	private String getStartTime(String absoluteFile) {

		StringReader reader = new StringReader(absoluteFile);
		if (reader.open() == 1) {
			throw new RuntimeException("Cannot open file: " + absoluteFile);
		}
		
		String str = reader.readLine();
		int count = 5;
		
		while (count > 0 && (str == null || str.length() < 20 || str.charAt(4) != '-' || str.charAt(7) != '-')) {
			str = reader.readLine();
		}
		
		if (str != null && str.length() > 20 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			reader.close();
			return str.substring(0, 23);
		} else {
			throw new RuntimeException("Error in file (not date): " + absoluteFile);
		}
		
	}

	public static void main(String[] args) {

		if (args.length != 6) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date yyyy-mm-dd");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.exit(-1);
				
		}
		
		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0] + "      Out Dir: " + args[5]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellOmfPerformanceLogsProcessorConsumerCounter(args[0],args[5],args[2], args[3], args[4]);
		}

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(date, 0);
		parms.setStartEnd(args[3], args[4]);
		
		line.recurse(f, parms, System.currentTimeMillis());

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName();
		int p = currentFile.getName().indexOf('.');
		
		if (p > 15) {
			this.currentServer = currentFile.getName().substring(15, p);
		}
		this.serverCount = 0;
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}

