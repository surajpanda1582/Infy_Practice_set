import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellOmPerformanceLogsProcessor extends LineProcessorWithData {

	
	private static boolean NORMALISE_ONLY = false;
	
	private File currentFile;
	private String currentServer;
	private String dir;
	private String outDir;

	private String startPath = "";
	@SuppressWarnings("rawtypes")
	Hashtable perfData = new Hashtable();
	@SuppressWarnings("rawtypes")
	ArrayList servers = new ArrayList();
	@SuppressWarnings("rawtypes")
	ArrayList services = new ArrayList();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	
	private WordString words = new WordString("");
	private WordString words2 = new WordString("");

	private StringWriter logNormalWriter;
	
	public BellOmPerformanceLogsProcessor(String dir, String outDir, String fileStartsWith, String minMs, String maxMs) {

		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { '|' });
		words2.setDelimiters(new char[] { ' ' });
		
		System.out.println("Output to: " + outDir);

	}

	public void print(OmParameters data) {
		
		if (NORMALISE_ONLY) {
			logNormalWriter.close();
			return;
		}
		
		StringWriter writer;
		
		String lDir = "";
		lDir = outDir + File.separator;
		
		writer = new StringWriter(lDir + "servers.tab");
		writer.open();

		writeServersHeader(writer);

		long tMinMs = minMs;
		long tMaxMs = maxMs;
		
		if (data.date2 != null) {
			maxMs = OmParameters.MAXMS;

			Integer interval = new Integer((int)(minMs / data.interval));
			int maxInterval = (int)(maxMs / data.interval);

			writeServerData(writer, data, interval, maxInterval);
			
			interval = new Integer(0);
			maxInterval = (int)(tMaxMs / data.interval);

			writeServerData(writer, data, interval, maxInterval);
			
		} else {
			Integer interval = new Integer((int)(minMs / data.interval));
			int maxInterval = (int)(maxMs / data.interval);

			writeServerData(writer, data, interval, maxInterval);
			
		}

		writer.close();
		writer = null;
		
		Collections.sort(services);
		ArrayList fullServices = services;
		services = new ArrayList();
		ArrayList otherServices = new ArrayList();
		String lastServiceType = "";
		
		for (Iterator iterator = fullServices.iterator(); iterator.hasNext();) {
			String service = (String) iterator.next();
			String serviceType;
			
			int p = service.indexOf('-');
			if (p > 0) {
				serviceType = service.substring(0, p);
			} else {
				serviceType = "";
				otherServices.add(service);
			}
			
			if (serviceType.length() > 0) {
				if (lastServiceType.length() > 0 && ! lastServiceType.equals(serviceType)) {
					
					writeServicesData(lastServiceType, data, tMinMs, tMaxMs);
					services.clear();
				}
				
				services.add(service);
				lastServiceType = serviceType;
			}
		}
		
		writeServicesData(lastServiceType, data, tMinMs, tMaxMs);
		
		services = otherServices;
		writeServicesData("Other", data, tMinMs, tMaxMs);
		
		services = fullServices;

	}

	/**
	 * @param data
	 * @param tMinMs
	 * @param tMaxMs
	 */
	private void writeServicesData(String serviceType, OmParameters data, long tMinMs, long tMaxMs) {
		
		StringWriter writer;
		String lDir = "";
		lDir = outDir + File.separator;

		writer = new StringWriter(lDir + serviceType+".tab");
		writer.open();
		writeServicesHeader(writer);
		
		if (data.date2 != null) {
			minMs = tMinMs;
			maxMs = OmParameters.MAXMS;

			Integer interval = new Integer((int)(minMs / data.interval));
			int maxInterval = (int)(maxMs / data.interval);

			writeServicesData(writer, data, interval, maxInterval);
			
			interval = new Integer(0);
			maxInterval = (int)(tMaxMs / data.interval);

			writeServicesData(writer, data, interval, maxInterval);
			
		} else {
			Integer interval = new Integer((int)(minMs / data.interval));
			int maxInterval = (int)(maxMs / data.interval);

			writeServicesData(writer, data, interval, maxInterval);
			
		}
		
		writer.close();
	}

	/**
	 * 
	 */
	private void writeServicesHeader(StringWriter writer) {
		writer.write("\t");
		for (int i = 0; i < services.size(); i++) {
			
			String service = services.get(i).toString();
			int p = service.indexOf('-');
			if (p > 0) {
				service = service.substring(p+1);
			}
			p = service.lastIndexOf('/');
			if (p > 0) {
				service = service.substring(p+1);
			}
						
			writer.write(service + "\t\t\t");
		}
		writer.writeLine("All");
		writer.write("Interval\t");
		for (int i = 0; i < services.size(); i++) {
			writer.write("Num\tAvg\t90%\t");
		}
		writer.writeLine("Num\tAvg\t90%");
	}

	/**
	 * 
	 */
	private void writeServersHeader(StringWriter writer) {
		writer.write("\t");
		for (int i = 0; i < servers.size(); i++) {
			writer.write(servers.get(i) + "\t\t\t");
		}
		writer.writeLine("All");
		writer.write("Interval\t");
		for (int i = 0; i < servers.size(); i++) {
			writer.write("Num\tAvg\t90%\t");
		}
		writer.writeLine("Num\tAvg\t90%");
	}

	/**
	 * @param data
	 * @param interval
	 * @param maxInterval
	 * @return
	 */
	private void writeServicesData(StringWriter writer, OmParameters data, Integer interval,
			int maxInterval) {
		
		while (interval.doubleValue() <= maxInterval) {
			OmDataElement dataElement = (OmDataElement)perfData.get(interval);
			writer.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < services.size(); i++) {
					StatisticalDoubleVector stats = (StatisticalDoubleVector)dataElement.byService.get(services.get(i));
					
					if (stats != null) {
						writer.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t");
					} else {
						writer.write("\t\t\t");
					}
				}
				
				writer.write(dataElement.allStats.size() + "\t" + dataElement.allStats.getAverage() + "\t" + dataElement.allStats.getPercentile(.9) + "\t");
			}
			
			writer.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}

	}

	/**
	 * @param data
	 * @param interval
	 * @param maxInterval
	 */
	private void writeServerData(StringWriter writer, OmParameters data, Integer interval,
			int maxInterval) {

		while (interval.doubleValue() <= maxInterval) {
			OmDataElement dataElement = (OmDataElement)perfData.get(interval);
			writer.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < servers.size(); i++) {
					StatisticalDoubleVector stats = (StatisticalDoubleVector)dataElement.byServer.get(servers.get(i));
					
					if (stats != null) {
						writer.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t");
					} else {
						writer.write("\t\t");
					}
				}
				
				writer.write(dataElement.allStats.size() + "\t" + dataElement.allStats.getAverage() + "\t" + dataElement.allStats.getPercentile(.9) + "\t");
			}
			
			writer.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
	}

	public boolean processLine(String str, Object data) {

		OmParameters parms = (OmParameters) data;
		if (str != null && str.length() > 40 && str.substring(23, 29).equals(" INFO ")) {
			
			str = Utility.replaceString(str, "configureProductsRoute.do|collapse", "configureProductsExpandCollapse.do|collapse");
			str = Utility.replaceString(str, "configureProductsRoute.do|expand", "configureProductsExpandCollapse.do|expand");
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			String hoi = "";
			String user = "";
			String type = "";
			
			if (parms.use(date, timeMs)) {
				
				String txn = null;
				String txnNorm = null;
				String txnPerfS = null;
				
			    if (str.indexOf("|Session|") > 0 || str.indexOf("|Service|") > 0) {
			    	if (words.getWordCount() == 4) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(3);
						type = words.getWord(1);
						
					} else if (words.getWordCount() == 6) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(5);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);
						
					} else {
						throw new RuntimeException();
					}
			    	
			    } else if (str.indexOf("|Servlet|") > 0) {
			    	if (words.getWordCount() == 5) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(4);
						type = words.getWord(1);
						
					} else if (words.getWordCount() == 7) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(6);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);

					}else {
						throw new RuntimeException();
					}
			    	
			    } else if (str.indexOf("|Action|") > 0 || str.indexOf("|JSP|") > 0) {
			    	if (words.getWordCount() == 6) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(5);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);

					} else if (words.getWordCount() == 4) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(3);
						type = words.getWord(1);

					}else {
						//throw new RuntimeException();
						if (str.indexOf("Path:") < 0) {
							System.out.println("Error in action: " + str);
						}
					}
			    	
			    } else if (str.indexOf("|XMLParser|") > 0 || str.indexOf("|JSP|") > 0) {
					txn = words.getWord(3);
					txnNorm = words.getWord(3);
					txnPerfS = words.getWord(5);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = "Other";

			    } else if (str.indexOf("|EBCCS|") > 0) {
					txn = words.getWord(3);
					txnNorm = words.getWord(3);
					txnPerfS = words.getWord(4);
					txnPerfS = Utility.replaceString(txnPerfS, ":", "|");
					words.setString(txnPerfS);
					txnPerfS = words.getWord(words.getWordCount()-1);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = "Downstream";
					
			    } else if (str.indexOf("|Refresh DSL Product") > 0) {
					txn = "Refresh DSL Product";
					txnNorm = "Refresh DSL Product";
					txnPerfS = Utility.stripStringKeeping(words.getWord(3), "0123456789");
					type = "Other";
					
			    } else {
					txn = words.getWord(3) + "-" + words.getWord(4);
					txnNorm = words.getWord(4);
					txnPerfS = words.getWord(5);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = words.getWord(3);
				}
			    
			    if (txnNorm != null) {
				    txnNorm = txnNorm.replace("/OrderMax/", "");
				    txnNorm = txnNorm.replace(".do", "");
				    txnNorm = txnNorm.replace("ca.bell.ordermax.service.", "");
					
				    if (NORMALISE_ONLY) {
				    	logNormalWriter.writeLine(date +"|"+ time +"|"+ user +"|"+ hoi +"|"+ type +"|"+ txnNorm +"|"+ txnPerfS );	
				    }
				    
				    if (!NORMALISE_ONLY) { //txn.startsWith("Servlet") || txn.startsWith("Action")) {
				    	
						long txnPerf = -1;
						try {
							txnPerf = Long.parseLong(txnPerfS);
						} catch (Exception e) {
							if (str.indexOf("JSON") < 0 && str.indexOf("mapPCSResponse") < 0) {
								System.err.println("Line Ignored: " + str);
							}
						}
						
						if (txnPerf >= 0) {
							txn = Utility.replaceString(txn, "ca.bell.ordermax.service.", "");
							txn = Utility.replaceString(txn, "/OrderMax/", "");
							txn = Utility.replaceString(txn, ".do", "");
							if (!services.contains(txn)) {
								services.add(txn);
								//System.out.println(txn);
							}
							
							if (!servers.contains(currentServer)) {
								servers.add(currentServer);
							}
							
							Integer interval = new Integer((int)(timeMs/parms.interval));
							
							OmDataElement dataElement = (OmDataElement)perfData.get(interval);
							if (dataElement == null) {
								dataElement = new OmDataElement(interval);
								perfData.put(interval, dataElement);
							}
							
							dataElement.addStats(currentServer, txn, txnPerf);
						}
				    }
			    }
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;
	static BellOmPerformanceLogsProcessor line = null;

	public static void main(String[] args) {

		if (args.length != 7 && args.length != 8) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date (yyyy-mm-dd)");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.err.println("         end date (yyyy-mm-dd)");
			System.err.println("   Only provide end date if needed to cross midnight");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start this one is invalid: "+args[0]);
			System.exit(0);
		}

		line = new BellOmPerformanceLogsProcessor(args[0], args[6], args[3], args[4], args[5]);
		
		line.setStartPath(f.getAbsolutePath());

		OmParameters parms = new OmParameters(args[1], Integer.parseInt(args[2]), line.minMs, line.maxMs);
		if (args.length > 7) {
			parms.date2 = args[7];
		}
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName().substring(7, 18);
		
		if (NORMALISE_ONLY) {
			if (logNormalWriter != null) {
				logNormalWriter.close();
			}
			
			logNormalWriter = new StringWriter(outDir + File.separator + currentFile.getName());
			logNormalWriter.open();
		}
		
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}
