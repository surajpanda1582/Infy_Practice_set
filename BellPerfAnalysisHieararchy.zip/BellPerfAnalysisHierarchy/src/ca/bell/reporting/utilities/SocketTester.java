package ca.bell.reporting.utilities;

public class SocketTester implements SocketListener {


	public byte[] processData ( byte[] data ) {
	
		System.out.println(Utility.toString(data));
		
		return ("OK".getBytes());
	
	}



	public static void main(String args[])	{


		SocketTester tester = new SocketTester();
		
		SocketServer server = new SocketServer(tester, 4444);

		System.out.println("Server is Listening");
		server.start();

	}
}