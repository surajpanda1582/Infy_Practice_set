package ca.bell.reporting.utilities;

import java.io.*;
import java.net.*;


public class SocketServerReadOnly extends Thread {

	private int port;
	private SocketListenerOneWay listener;
	
public SocketServerReadOnly(SocketListenerOneWay listener, int port)
  throws BindException {

  this.port = port;
  this.listener = listener;

  try {
    ServerSocket ser = new ServerSocket(port);
    ser.close();
  } catch (IOException e) {

    if (e instanceof BindException)
      throw (BindException) e;

  }
}
public void run()  {

  ServerSocket ser = null;
  Socket soc = null;
  StringBuffer sb = new StringBuffer();
  byte[] buffer = new byte[1024];

  try {

    ser = new ServerSocket(port);

    while (true) {

      soc = ser.accept();

      InetAddress replyAddr = soc.getInetAddress();

      InputStream is = soc.getInputStream();

      int num = 0;
      sb.setLength(0);

      do {

        num = is.read(buffer);
        for (int i = 0; i < num; i++) {
          sb.append((char) buffer[i]);
        }

      } while (num > 0);

      listener.processData(sb.toString().getBytes());

      is.close();
      soc.close();

    }

  } catch (Exception e) {

    System.out.println(e);
    System.exit(0);

  }
}
}
