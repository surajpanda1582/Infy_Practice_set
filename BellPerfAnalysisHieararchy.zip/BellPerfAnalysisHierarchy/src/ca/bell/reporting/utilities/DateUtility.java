package ca.bell.reporting.utilities;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import java.util.Date;

/**
 * This type was created in VisualAge.
 */
public class DateUtility implements Cloneable, Comparable {
	
	public final static String[] MONTHS = new String[] {
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	};
	private GregorianCalendar gc = null;
	private String tz = null;
	private String asString = null;
	private boolean timeOnly = false;
	
	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility() {
		super();
		gc = new GregorianCalendar();
		asString = toNotesString();
	}
	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility(long time) {
		super();
		gc = new GregorianCalendar();
		gc.setTime(new Date(time));
		asString = toNotesString();
	}
	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility(DateUtility du) {
		super();
		gc =
			new GregorianCalendar(
				du.getYear(),
				du.getMonth() - 1,
				du.getDay(),
				du.getHour(),
				du.getMinute(),
				du.getSecond());
		asString = toNotesString();
	}
	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility(int year, int month, int day) {
		super();
		gc =
			new GregorianCalendar(
				year,
				month - 1,
				day,
				0,
				0,
				0);
		asString = toNotesString();
	}
	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility(String str) {
		super();

		final String AM = "AM";
		final String PM = "PM";

		gc = null;

		if (str == null || str.length() == 0)
			return;

		if (str.length() == 22) {

			int m = 0, y = 0, d = 0, h = 0, mi = 0, s = 0;

			String amPm = str.substring(20, 22);

			if (amPm.equals(AM)) {

				h = Integer.parseInt(str.substring(11, 13));
				if (h == 12)
					h = 0;

			} else if (amPm.equals(PM)) {

				h = Integer.parseInt(str.substring(11, 13));

				if (h < 12) {

					h += 12;

				}

			} else {

				return;

			}

			y = Integer.parseInt(str.substring(6, 10));
			m = Integer.parseInt(str.substring(0, 2)) - 1;
			d = Integer.parseInt(str.substring(3, 5));

			mi = Integer.parseInt(str.substring(14, 16));
			s = Integer.parseInt(str.substring(17, 19));

			gc = new GregorianCalendar(y, m, d, h, mi, s);
			
		} else if (str.length() == 26) {

			int m = 0, y = 0, d = 0, h = 0, mi = 0, s = 0;

			String amPm = str.substring(20, 22);

			if (amPm.equals(AM)) {

				h = Integer.parseInt(str.substring(11, 13));
				if (h == 12)
					h = 0;

			} else if (amPm.equals(PM)) {

				h = Integer.parseInt(str.substring(11, 13));

				if (h < 12) {

					h += 12;

				}

			} else {

				return;

			}

			y = Integer.parseInt(str.substring(6, 10));
			m = Integer.parseInt(str.substring(0, 2)) - 1;
			d = Integer.parseInt(str.substring(3, 5));

			mi = Integer.parseInt(str.substring(14, 16));
			s = Integer.parseInt(str.substring(17, 19));

			tz = str.substring(23, 26);

			gc = new GregorianCalendar(y, m, d, h, mi, s);
			
		} else if (str.length() == 10) {

			int m = 0, y = 0, d = 0;

			if (!Utility.isNumber(str.substring(4, 5))) {

				// yyyy/mm/dd
				y = Integer.parseInt(str.substring(0, 4));
				m = Integer.parseInt(str.substring(5, 7)) - 1;
				d = Integer.parseInt(str.substring(8, 10));

			} else {

				// mm/dd/yyyy	
				m = Integer.parseInt(str.substring(0, 2)) - 1;
				d = Integer.parseInt(str.substring(3, 5));
				y = Integer.parseInt(str.substring(6));

			}

			gc = new GregorianCalendar(y, m, d);
			
		} else if (str.length() == 11) {

			gc = new GregorianCalendar();
			
			setTime(str);
			
		} else if (str.length() == 12) {

			String[] data = str.split(":|,|-");
			
			if (data.length == 4) {

				gc = new GregorianCalendar();
				
				setHour(Integer.parseInt(data[0]));
				setMinute(Integer.parseInt(data[1]));
				setSecond(Integer.parseInt(data[2]));
				setMilliSecond(Integer.parseInt(data[3]));
				
			}
		}
		asString = toNotesString();

	}

	/**
	 * DateUtility constructor comment.
	 */
	public DateUtility(GregorianCalendar calendar) {
		super();
		gc = calendar;
		asString = toNotesString();
	}
	/**
	 * 
	 * 
	 * Creation date: (6/24/2001 10:30:18 PM)
	 * @return boolean
	 * @param date com.followme.abastien.utilities.DateUtility
	 */
	public boolean after(DateUtility date) {

		long me = gc.getTime().getTime();
		long other = date.gc.getTime().getTime();
		
//		date.increment(gc.SECOND, 1);
//		
//		boolean ret = this.gc.after(date.gc);
//
//		date.increment(gc.SECOND, -1);
//
		return me > other;		
	}
	/**
	 * 
	 * 
	 * Creation date: (6/24/2001 10:30:18 PM)
	 * @return boolean
	 * @param date com.followme.abastien.utilities.DateUtility
	 */
	public boolean before(DateUtility date) {

		long me = gc.getTime().getTime();
		long other = date.gc.getTime().getTime();

		return me < other;//this.gc.before(date.gc);

	}
	/**
	 * 
	 * 
	 * Creation date: (6/24/2001 10:30:18 PM)
	 * @return boolean
	 * @param date com.followme.abastien.utilities.DateUtility
	 */
	public boolean beforeOrSame(DateUtility date) {

		long me = gc.getTime().getTime();
		long other = date.gc.getTime().getTime();

//		date.increment(gc.SECOND, 1);
//		boolean ret = this.gc.before(date.gc);
//
//		date.increment(gc.SECOND, -1);

		return me <= other;

	}
	/**
	 * DateUtility constructor comment.
	 */
	public Object clone() {
		return new DateUtility(toString());
	}
	/**
	 * 
	 * 
	 */
	public int compareTo(Object obj) {

		if (obj == null)
			return 1;

		if (this.getClass().equals(obj.getClass())) {

			DateUtility du = (DateUtility) obj;

			if (du.gc.equals(this.gc))
				return 0;
			else if (this.gc.before(du.gc))
				return -1;
			else
				return 1;

		} else {

			return -1;

		}

	}
	/**
	 * Get Days difference
	 * 
	 * NOTE: maximum of 1 year difference only
	 */
	public int daysDifference(DateUtility date) {

		int ret = 0;

		if (this.isSameDate(date))
			return 0;

		if (date.getYear() == this.getYear()) {

			int days1, days2;

			days1 = this.getDayOfYear();
			days2 = date.getDayOfYear();

			ret = days2 - days1;

		} else {

			if (date.getYear() > this.getYear()) {

				int days1 = this.getDayOfYear();

				DateUtility du = new DateUtility(this);
				du.setMonth(12);
				du.setDate(31);
				int days2 = du.getDayOfYear();

				int days3 = date.getDayOfYear();

				ret = days2 - days1 + days3;

			} else {

				int days1 = date.getDayOfYear();

				DateUtility du = new DateUtility(date);
				du.setMonth(12);
				du.setDate(31);
				int days2 = du.getDayOfYear();

				int days3 = this.getDayOfYear();

				ret = -1 * (days2 - days1 + days3);

			}
		}

		return ret;

	}
	/**
	 * 
	 */
	public void decrement() {

		if (gc == null)
			return;

		gc.add(GregorianCalendar.DAY_OF_MONTH, -1);
		asString = toNotesString();
	}
	/**
	 * 
	 */
	public void decrement(int days) {

		gc.add(GregorianCalendar.DAY_OF_MONTH, -1 * days);
		asString = toNotesString();
	}
	/**
	 * 
	 * 
	 */
	public boolean equals(Object obj) {

		if (obj == null)
			return false;

		if (this.getClass().equals(obj.getClass())) {

			DateUtility du = (DateUtility) obj;

			return this.getMonth() == du.getMonth()
				&& this.getDay() == du.getDay()
				&& this.getYear() == du.getYear()
				&& this.getHour() == du.getHour()
				&& this.getMinute() == du.getMinute()
				&& this.getSecond() == du.getSecond();

		} else {

			return false;

		} 

	}
	
	public int hashCode() {
	
		return gc.hashCode();
	}
	
	
	/**
	 * Get day
	 */
	public GregorianCalendar getCalendar() {
		return gc;
	}
	/**
	 * Get day
	 */
	public int getDay() {
		return gc.get(GregorianCalendar.DAY_OF_MONTH);
	}
	/**
	 * Get day
	 */
	public String getDayZeroFill() {
		String ret = String.valueOf(gc.get(GregorianCalendar.DAY_OF_MONTH));

		if (ret.length() == 1)
			return "0" + ret;
		else
			return ret;
	}
	/**
	 * Get Days difference
	 * 
	 * NOTE: maximum of 1 year difference only
	 */
	public int getDayOfYear() {

		int ret = 0;
		int days[] =
			{ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365 };
		int lydays[] =
			{ 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335, 366 };

		if (this.gc.isLeapYear(this.getYear())) {

			ret = lydays[this.getMonth() - 1] + this.getDay();

		} else {

			ret = days[this.getMonth() - 1] + this.getDay();
		}

		return ret;

	}
	/**
	 * Get day
	 */
	public int getHour() {
		return gc.get(GregorianCalendar.HOUR_OF_DAY);
	}
	/**
	 * Get day
	 */
	public int getMinute() {
		return gc.get(GregorianCalendar.MINUTE);
	}
	/**
	 * Get month
	 */
	public int getMonth() {
		return gc.get(GregorianCalendar.MONTH) + 1;
	}
	/**
	 * Get month
	 */
	public String getMonthZeroFill() {
		String ret = String.valueOf(gc.get(GregorianCalendar.MONTH) + 1);

		if (ret.length() == 1)
			return "0" + ret;
		else
			return ret;
	}
	/**
	 * Get second
	 */
	public int getSecond() {
		return gc.get(GregorianCalendar.SECOND);
	}

	public int getMilliSecond() {
		return gc.get(GregorianCalendar.MILLISECOND);
	}

	public long getSecondsFromMidnight() {
		return this.getHour() * 3600l + this.getMinute() * 60l + this.getSecond();
	}
	/**
	 * Get year
	 */
	public int getYear() {
		return gc.get(GregorianCalendar.YEAR);
	}
	/**
	 * 
	 */
	public void increment() {

		if (gc == null)
			return;

		gc.add(GregorianCalendar.DAY_OF_MONTH, 1);
		asString = toNotesString();
	}
	/**
	 * 
	 */
	public void increment(int field, int amount) {

		gc.add(field, amount);
		asString = toNotesString();
	}
	/**
	 * 
	 * 
	 */
	public boolean isSameDate(DateUtility du) {

		if (du == null)
			return false;

		return this.getYear() == du.getYear()
			&& this.getMonth() == du.getMonth()
			&& this.getDay() == du.getDay();

	}
	/**
	 * 
	 * 
	 */
	public boolean isSameTime(DateUtility du) {

		if (du == null)
			return false;

		return this.getHour() == du.getHour()
			&& this.getMinute() == du.getMinute()
			&& this.getSecond() == du.getSecond();

	}
	
	public boolean isMidnight() {

		return this.getHour() == 0
			&& this.getMinute() == 0
			&& this.getSecond() == 0;

	}
	public boolean isWeekday() {
		int dow = gc.get(GregorianCalendar.DAY_OF_WEEK);

		if (dow == GregorianCalendar.SATURDAY || dow == GregorianCalendar.SUNDAY)
			return false;

		return true;
	}
	public boolean isFriday() {
		int dow = gc.get(GregorianCalendar.DAY_OF_WEEK);

		return (dow == GregorianCalendar.FRIDAY);
	}
	/**
	 * 
	 * 
	 * Creation date: (10/18/2001 8:29:43 PM)
	 * @param args java.lang.String[]
	 */
	public static void main(String[] args) {

		DateUtility test = new DateUtility(1314244800536L);
		System.out.println(test.toString());
		test = new DateUtility("12/31/2066");
		System.out.println(test.toString());
		test = new DateUtility("2014/08/06");
		System.out.println(test.toString());
		System.exit(0);
		
		DateUtility now = new DateUtility();
		DateUtility dua = new DateUtility("02/01/2003");
		
		if (dua.before(now)) {
			
			System.out.println("error");
		}
		

		DateUtility du = new DateUtility("01/15/2003 02:00:00 PM");

		du.setDate(30);

		du.increment(GregorianCalendar.MONTH, 1);
		du.setDate(30);

		du.increment(GregorianCalendar.MONTH, 1);
		du.setDate(30);

		du.increment(GregorianCalendar.MONTH, 1);
		du.setDate(30);

		System.exit(0);
		
		System.out.println(new DateUtility());
		
		DateUtility du1 = new DateUtility("10/24/1996 08:00:00 AM");
		DateUtility du2 = new DateUtility("01/01/1996 09:00:00 AM");
		int i;

		System.out.println(du1.getTimeZone()+" - "+du1.getTimeZoneLong());
		System.out.println(du2.getTimeZone()+" - "+du2.getTimeZoneLong());

		i = du2.daysDifference(du1);
		if (i != 297)
			System.out.println("ERROR 1:" + i);

		du1 = new DateUtility("10/24/2001 08:00:00 AM");
		du2 = new DateUtility("01/01/2001 09:00:00 AM");
		i = du2.daysDifference(du1);
		if (i != 296)
			System.out.println("ERROR 2:" + i);

		du1 = new DateUtility("01/05/2002 08:00:00 AM");
		du2 = new DateUtility("01/01/2001 09:00:00 AM");
		i = du2.daysDifference(du1);
		if (i != 369)
			System.out.println("ERROR 3:" + i);

		du1 = new DateUtility("01/05/1997 08:00:00 AM");
		du2 = new DateUtility("01/01/1996 09:00:00 AM");
		i = du2.daysDifference(du1);
		if (i != 370)
			System.out.println("ERROR 4:" + i);

		du1 = new DateUtility("01/01/1996 08:00:00 AM");
		du2 = new DateUtility("01/05/1997 09:00:00 AM");
		i = du2.daysDifference(du1);
		if (i != -370)
			System.out.println("ERROR 5:" + i);

		System.out.println("Done");
	}
	public boolean sameDate(DateUtility du) {
		return this.getDay() == du.getDay()
			&& this.getMonth() == du.getMonth()
			&& this.getYear() == du.getYear();
	}
	public void setDate(int date) {

		int i = gc.get(GregorianCalendar.MONTH);
		
		gc.set(GregorianCalendar.DAY_OF_MONTH, date);
		
		while (i != gc.get(GregorianCalendar.MONTH)) {
			
			gc.add(GregorianCalendar.DAY_OF_MONTH, -1);
		}
		
		asString = toNotesString();
	}

	public final static int MDY = 1;
	public final static int YMD = 2;
	public final static int DMY = 3;

	public void setDate(String date, String deliminator, int type) {

		int mn, dy, yr;
		
		WordString words = new WordString(date);
		words.setDelimiters(deliminator.toCharArray());

		switch (type) {
			case MDY :
			
				mn = Integer.parseInt(words.getWord(0));
				dy = Integer.parseInt(words.getWord(1));
				yr = Integer.parseInt(words.getWord(2));
				
				break;

			case DMY :
				
				mn = Integer.parseInt(words.getWord(1));
				dy = Integer.parseInt(words.getWord(0));
				yr = Integer.parseInt(words.getWord(2));
				
				break;

			case YMD :
				
				mn = Integer.parseInt(words.getWord(1));
				dy = Integer.parseInt(words.getWord(2));
				yr = Integer.parseInt(words.getWord(0));
				
				break;

			default :
				throw new RuntimeException("DateUtiltiy Error: invalid type on setDate");
		}

		if (yr > 90 && yr < 100) yr += 1900;
		else if (yr < 1000) yr += 2000;
		
		setDate(yr, mn, dy);
	}

	/**
	 * 
	 * 
	 * Creation date: (6/24/2001 10:30:18 PM)
	 * @return boolean
	 * @param date com.followme.abastien.utilities.DateUtility
	 */
	public DateUtility setDateTime(DateUtility date) {

		this.gc.set(GregorianCalendar.YEAR, date.gc.get(GregorianCalendar.YEAR));
		this.gc.set(GregorianCalendar.MONTH, date.gc.get(GregorianCalendar.MONTH));
		this.gc.set(GregorianCalendar.DAY_OF_MONTH, date.gc.get(GregorianCalendar.DAY_OF_MONTH));

		this.gc.set(GregorianCalendar.HOUR_OF_DAY, date.gc.get(GregorianCalendar.HOUR_OF_DAY));
		this.gc.set(GregorianCalendar.MINUTE, date.gc.get(GregorianCalendar.MINUTE));
		this.gc.set(GregorianCalendar.SECOND, date.gc.get(GregorianCalendar.SECOND));

		asString = toNotesString();

		return this;
	}
	public void setHour(int hour) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.HOUR_OF_DAY, hour);
		asString = toNotesString();
	}
	public void setMinute(int min) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.MINUTE, min);
		asString = toNotesString();
	}
	/**
	 * Get month
	 */
	public void setMonth(int month) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.MONTH, month - 1);
		asString = toNotesString();
	}

	public void setDate(int year, int month, int day) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.DAY_OF_MONTH, day);
		gc.set(GregorianCalendar.MONTH, month - 1);
		gc.set(GregorianCalendar.YEAR, year);
		asString = toNotesString();
	}

	/**
	 * Get day
	 */
	public void setSecond(int seconds) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.SECOND, seconds);
		asString = toNotesString();
	}

	public void setMilliSecond(int msseconds) {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.MILLISECOND, msseconds);
		asString = toNotesString();
	}

	public void zeroSeconds() {
		gc.set(GregorianCalendar.SECOND, 0);
		gc.set(GregorianCalendar.MILLISECOND, 0);
		asString = toNotesString();
	}
	public void zeroTime() {

		if (gc == null)
			return;

		gc.set(GregorianCalendar.HOUR_OF_DAY, 0);
		gc.set(GregorianCalendar.MINUTE, 0);
		gc.set(GregorianCalendar.SECOND, 0);
		gc.set(GregorianCalendar.MILLISECOND, 0);
		asString = toNotesString();
	}
	public void setLastTime() {
		gc.set(GregorianCalendar.HOUR_OF_DAY, 23);
		gc.set(GregorianCalendar.MINUTE, 59);
		gc.set(GregorianCalendar.SECOND, 59);
		asString = toNotesString();
	}
	/**
	 * 
	 * 
	 * Creation date: (6/24/2001 10:30:18 PM)
	 * @return boolean
	 * @param date com.followme.abastien.utilities.DateUtility
	 */
	public DateUtility setTime(DateUtility date) {

		this.gc.set(GregorianCalendar.HOUR_OF_DAY, date.gc.get(GregorianCalendar.HOUR_OF_DAY));
		this.gc.set(GregorianCalendar.MINUTE, date.gc.get(GregorianCalendar.MINUTE));
		this.gc.set(GregorianCalendar.SECOND, date.gc.get(GregorianCalendar.SECOND));

		asString = toNotesString();
		return this;
	}
	public void setWeekAndDay(int week, int day) {

		int month = gc.get(GregorianCalendar.MONTH);
		gc.set(GregorianCalendar.DAY_OF_MONTH, 1);
		if (gc.get(GregorianCalendar.DAY_OF_WEEK) != day)
			gc.set(GregorianCalendar.DAY_OF_WEEK, day);
		if (month != gc.get(GregorianCalendar.MONTH))
			gc.add(GregorianCalendar.DAY_OF_MONTH, 7);

		if (week == 5) {

			int lastDay = gc.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);
			int cDay = gc.get(GregorianCalendar.DAY_OF_MONTH);

			while (cDay <= lastDay) {
				cDay += 7;
			}

			cDay -= 7;
			gc.set(GregorianCalendar.DAY_OF_MONTH, cDay);

		} else {

			if (week > 1)
				gc.add(GregorianCalendar.DAY_OF_MONTH, 7 * (week - 1));

		}

		asString = toNotesString();
	}
	
	public int getWeekDay() {
		
		if (gc == null) return 0;
		
		return gc.get(GregorianCalendar.DAY_OF_WEEK);
	}

	public void setWeekDay(int day) {

		int week = gc.get(GregorianCalendar.WEEK_OF_YEAR);
		gc.set(GregorianCalendar.DAY_OF_WEEK, day);

		if (week > gc.get(GregorianCalendar.WEEK_OF_YEAR))
			gc.add(GregorianCalendar.DAY_OF_MONTH, -7);

		if (week < gc.get(GregorianCalendar.WEEK_OF_YEAR))
			gc.add(GregorianCalendar.DAY_OF_MONTH, 7);
		asString = toNotesString();
	}
	/**
	 * Get month
	 */
	public void setYear(int year) {
		gc.set(GregorianCalendar.YEAR, year);
		asString = toNotesString();
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public GregorianCalendar toCalendar() {
		return gc;
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toDateString(char separator) {
		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();
		sb.append(gc.get(GregorianCalendar.YEAR));
		sb.append(separator);
		if (gc.get(GregorianCalendar.MONTH) + 1 < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.MONTH) + 1);
		sb.append(separator);
		if (gc.get(GregorianCalendar.DAY_OF_MONTH) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.DAY_OF_MONTH));
		return sb.toString();
	}
	
	public String toDateString() {
		
		return toDateString('/');
	}

	public long toLong() {
		
		return gc.getTime().getTime();
	}
	
	
	public String toLongDateString() {
		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();
		sb.append(MONTHS[gc.get(GregorianCalendar.MONTH)]);
		sb.append(" ");
		sb.append(this.getDay());
		sb.append(", ");
		sb.append(this.getYear());
		

		return sb.toString();
	}

	public String toLongDateStringNoYear() {
		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();
		sb.append(MONTHS[gc.get(GregorianCalendar.MONTH)]);
		sb.append(" ");
		sb.append(this.getDay());

		return sb.toString();
	}

	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toNotesDateString() {
		int i;

		if (gc == null)
			return "";
		
		StringBuffer sb = new StringBuffer();
		if (gc.get(GregorianCalendar.MONTH) + 1 < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.MONTH) + 1);
		sb.append('/');
		if (gc.get(GregorianCalendar.DAY_OF_MONTH) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.DAY_OF_MONTH));
		sb.append('/');
		sb.append(gc.get(GregorianCalendar.YEAR));

		return sb.toString();
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toNotesString() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();
		
		if (! timeOnly) {
			if (gc.get(GregorianCalendar.MONTH) + 1 < 10)
				sb.append('0');
			sb.append(gc.get(GregorianCalendar.MONTH) + 1);
			sb.append('/');
			if (gc.get(GregorianCalendar.DAY_OF_MONTH) < 10)
				sb.append('0');
			sb.append(gc.get(GregorianCalendar.DAY_OF_MONTH));
			sb.append('/');
			sb.append(gc.get(GregorianCalendar.YEAR));
	
			sb.append(' ');
		}
		sb.append(this.toTimeString());

		if (! timeOnly) {
			if (tz != null && tz.length() == 3) {
	
				sb.append(' ');
				sb.append(tz);
	
			} else {
	
				TimeZone tz2 = gc.getTimeZone();
				sb.append(' ');
				sb.append(
					tz2.getDisplayName(tz2.inDaylightTime(gc.getTime()), TimeZone.SHORT));
			}
		}
		
		return sb.toString();
	}
	public String toStringXML() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();

		sb.append(gc.get(GregorianCalendar.YEAR));
		if (gc.get(GregorianCalendar.MONTH) + 1 < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.MONTH) + 1);
		if (gc.get(GregorianCalendar.DAY_OF_MONTH) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.DAY_OF_MONTH));
		if (gc.get(GregorianCalendar.HOUR_OF_DAY) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.HOUR_OF_DAY));
		if (gc.get(GregorianCalendar.MINUTE) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.MINUTE));
		sb.append('0');
		sb.append('0');

		TimeZone tz2 = gc.getTimeZone();
		sb.append(' ');
		sb.append(
			tz2.getDisplayName(tz2.inDaylightTime(gc.getTime()), TimeZone.SHORT));

		return sb.toString();
	}

	public String getTimeZone () {
		
		TimeZone tz2 = gc.getTimeZone();
		return tz2.getDisplayName(tz2.inDaylightTime(gc.getTime()), TimeZone.SHORT);
		
	}
	public String getTimeZoneNoDaylightST () {
		
		TimeZone tz2 = gc.getTimeZone();
		return tz2.getDisplayName(false, TimeZone.SHORT);
		
	}
	public String getTimeZoneLong () {
		
		TimeZone tz2 = gc.getTimeZone();
		return tz2.getDisplayName(tz2.inDaylightTime(gc.getTime()), TimeZone.LONG);
		
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toString() {

		return (this.toNotesString());

	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toString(char separator) {
		StringBuffer sb = new StringBuffer();
		sb.append(gc.get(GregorianCalendar.YEAR));
		sb.append(separator);
		if (gc.get(GregorianCalendar.MONTH) + 1 < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.MONTH) + 1);
		sb.append(separator);
		if (gc.get(GregorianCalendar.DAY_OF_MONTH) < 10)
			sb.append('0');
		sb.append(gc.get(GregorianCalendar.DAY_OF_MONTH));
		return sb.toString();
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toTimeString() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();

		i = gc.get(GregorianCalendar.HOUR_OF_DAY);

		String amPm = "AM";

		if (i > 12) {

			i -= 12;
			amPm = "PM";

		} else if (i == 12) {

			amPm = "PM";

		} else if (i == 0) {

			i = 12;
		}

		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.MINUTE);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		sb.append(':');

		i = gc.get(GregorianCalendar.SECOND);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		sb.append(' ');
		sb.append(amPm);

		return sb.toString();
	}

	/**
	 * This method was created in VisualAge.
	 * @return java.lang.String
	 */
	public String toTimeString24H() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();

		i = gc.get(GregorianCalendar.HOUR_OF_DAY);

		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.MINUTE);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		sb.append(':');

		i = gc.get(GregorianCalendar.SECOND);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		return sb.toString();
	}

	public String toTimeStringMillis() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();

		i = gc.get(GregorianCalendar.HOUR_OF_DAY);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.MINUTE);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.SECOND);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.MILLISECOND);
		if (i < 10)
			sb.append("00");
		if (i >= 10 && i < 100)
			sb.append('0');
		sb.append(i);

		return sb.toString();
		
	}
	
	public static String toTimeStringMillis(long currentTimeMillis) {
		int i;

		GregorianCalendar gc2 = new GregorianCalendar();
		gc2.setTime(new Date(currentTimeMillis));

		StringBuffer sb = new StringBuffer();

		i = gc2.get(GregorianCalendar.HOUR_OF_DAY);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc2.get(GregorianCalendar.MINUTE);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc2.get(GregorianCalendar.SECOND);
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc2.get(GregorianCalendar.MILLISECOND);
		if (i < 10)
			sb.append("00");
		if (i >= 10 && i < 100)
			sb.append('0');
		sb.append(i);

		return sb.toString();
		
	}
	
	public static String toDateString(long currentTimeMillis) {
		int i;

		GregorianCalendar gc2 = new GregorianCalendar();
		gc2.setTime(new Date(currentTimeMillis));

		StringBuffer sb = new StringBuffer();

		i = gc2.get(GregorianCalendar.YEAR);
		sb.append(i);
		sb.append('/');

		i = gc2.get(GregorianCalendar.MONTH)+1;
		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append('/');

		i = gc2.get(GregorianCalendar.DAY_OF_MONTH);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		return sb.toString();
		
	}
	
	public String toTimeStringNoSeconds() {
		int i;

		if (gc == null)
			return "";

		StringBuffer sb = new StringBuffer();

		i = gc.get(GregorianCalendar.HOUR_OF_DAY);

		String amPm = "AM";

		if (i > 12) {

			i -= 12;
			amPm = "PM";

		} else if (i == 12) {

			amPm = "PM";

		} else if (i == 0) {

			i = 12;
		}

		if (i < 10)
			sb.append('0');
		sb.append(i);
		sb.append(':');

		i = gc.get(GregorianCalendar.MINUTE);
		if (i < 10)
			sb.append('0');
		sb.append(i);

		sb.append(' ');
		sb.append(amPm);

		return sb.toString();
	}

	public void setTime(String str) {

		final String AM = "AM";
		final String PM = "PM";
		final String ZERO = "0";

		if (str == null || str.length() == 0)
			return;

		if (str.length() == 8 || str.length() == 7) {  // HH:MM PM or H:MM PM

			if (str.length() == 7) str = ZERO + str;
			
			int h = 0, mi = 0, s = 0;

			String amPm = str.substring(6, 8);

			if (amPm.equalsIgnoreCase(AM)) {

				h = Integer.parseInt(str.substring(0, 2));
				if (h == 12)
					h = 0;

			} else if (amPm.equalsIgnoreCase(PM)) {

				h = Integer.parseInt(str.substring(0, 2));

				if (h < 12) {

					h += 12;

				}

			} else {

				return;

			}

			mi = Integer.parseInt(str.substring(3, 5));
			
			this.setHour(h);
			this.setMinute(mi);
			this.setSecond(s);
			
		} else if (str.length() == 11 || str.length() == 10) { // HH:MM:SS PM or H:MM:SS PM

			if (str.length() == 10) str = ZERO + str;

			int h = 0, mi = 0, s = 0;

			String amPm = str.substring(9, 11);

			if (amPm.equalsIgnoreCase(AM)) {

				h = Integer.parseInt(str.substring(0, 2));
				if (h == 12)
					h = 0;

			} else if (amPm.equalsIgnoreCase(PM)) {

				h = Integer.parseInt(str.substring(0, 2));

				if (h < 12) {

					h += 12;

				}

			} else {

				return;

			}

			mi = Integer.parseInt(str.substring(3, 5));
			s = Integer.parseInt(str.substring(6, 8));
			
			this.setHour(h);
			this.setMinute(mi);
			this.setSecond(s);
		} else throw new RuntimeException("DateUtility:setTime error");

		asString = toNotesString();
	}

	public void setTime24Hour(String str) {

		if (str == null || str.length() == 0)
			return;

		if (str.length() == 8) {

			int h = 0, mi = 0, s = 0;

			h = Integer.parseInt(str.substring(0, 2));
			mi = Integer.parseInt(str.substring(3, 5));
			s = Integer.parseInt(str.substring(6));
			
			this.setHour(h);
			this.setMinute(mi);
			this.setSecond(s);
		} else throw new RuntimeException("DateUtility:setTime24Hour error");
		asString = toNotesString();
	}

	public void setTime24HourMillis(String str) {

		if (str == null || str.length() == 0)
			return;

		if (str.length() == 12) {

			int h = 0, mi = 0, s = 0, ms = 0;

			h = Integer.parseInt(str.substring(0, 2));
			mi = Integer.parseInt(str.substring(3, 5));
			s = Integer.parseInt(str.substring(6,8));
			ms = Integer.parseInt(str.substring(9));
			
			this.setHour(h);
			this.setMinute(mi);
			this.setSecond(s);
			gc.set(GregorianCalendar.MILLISECOND, ms);
		} else throw new RuntimeException("DateUtility:setTime24HourMillis error");
		
		asString = toNotesString();
	}

	/**
	 * 
	 * 
	 */
	public DateUtility setDate(DateUtility date) {

		this.gc.set(GregorianCalendar.YEAR, date.gc.get(GregorianCalendar.YEAR));
		this.gc.set(GregorianCalendar.MONTH, date.gc.get(GregorianCalendar.MONTH));
		this.gc.set(GregorianCalendar.DAY_OF_MONTH, date.gc.get(GregorianCalendar.DAY_OF_MONTH));

		asString = toNotesString();
		return this;
	}
	
	/**
	 * Return time diffrence in milli seconds
	 * 
	 * @param startTime
	 * @return time diffrence in milli seconds
	 */
	public long difference(DateUtility startTime) {
		
		if (gc == null || startTime == null || startTime.gc == null) {
			return 0;
		}

		long diff = gc.getTime().getTime() - startTime.gc.getTime().getTime();
		
		return diff;
	}
	public boolean isTimeOnly() {
		return timeOnly;
	}
	public void setTimeOnly(boolean timeOnly) {
		this.timeOnly = timeOnly;
	}
	
	public static Calendar convertToCalendar(Date intervelStartDate) {

		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(intervelStartDate);

		return gc;
	}
	public long toLongTimeOnly() {
		
		return (getHour()*3600000) + (getMinute()*60000) + (getSecond()*1000) + getMilliSecond();
	}
}


