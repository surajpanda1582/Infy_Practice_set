package ca.bell.reporting.utilities;

public class TimeMonitor {

	private long startMillis;
	private long currentMillis;
	
	public TimeMonitor() {
	
		currentMillis = System.currentTimeMillis();
		startMillis = currentMillis;
	
	}
	
	public long mark() {
	
		long newCurr = System.currentTimeMillis();
		
		long retCurr = newCurr - currentMillis;
		
		currentMillis = newCurr;
		
		return (retCurr);
		
	}
	
	public long total() {
	
		return (System.currentTimeMillis() - startMillis);
	
	}
}