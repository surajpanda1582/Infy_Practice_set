package ca.bell.reporting.utilities;

public interface SocketListenerOneWay {


	public void processData ( byte[] data );
}
