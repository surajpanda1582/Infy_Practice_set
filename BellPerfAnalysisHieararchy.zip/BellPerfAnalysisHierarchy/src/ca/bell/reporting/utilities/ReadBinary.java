package ca.bell.reporting.utilities;

import java.io.*;

public class ReadBinary 
{

	public static void main(String args[]) 
	{
		File f;
		DataInputStream is = null;
		try 
		{
			f = new File("C:\\PALM\\BastieA\\address\\address.dat");
			f = new File("C:\\temp.dat");
			is = new DataInputStream(new FileInputStream(f));
		} catch (Exception e)
		{
			System.out.println(e.toString());
			System.exit(-1);
		}
		
		byte line[] = new byte[16];
		StringBuffer sb;
		
		try 
		{
			for (int j=1; j<10; j++)
			{
				is.read(line);
		
				for (int i = 0; i<16; i++)
				{
					sb = new StringBuffer(new Byte(line[i]).intValue()+"");
					switch (sb.length())
					{
						case 1:
							sb.insert(0, "  ");
							break;
						case 2:
							sb.insert(0, " ");
							break;
					}

					System.out.print(sb.toString());
					if (line[i]<32) System.out.print("(.) ");
					else System.out.print("("+(char)line[i]+") ");
				}
				System.out.println("");

				for (int i = 0; i<16; i++)
				{
					if (line[i]<32) System.out.print(".");
					else System.out.print((char)line[i]);
				}
			System.out.println("");
			}
		} catch (Exception ignored) 
		{
		}
	}
}
