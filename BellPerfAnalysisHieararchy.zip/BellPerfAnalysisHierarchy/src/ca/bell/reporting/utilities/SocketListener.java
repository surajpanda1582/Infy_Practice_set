package ca.bell.reporting.utilities;

public interface SocketListener {


	public byte[] processData ( byte[] data );


}