package ca.bell.reporting.utilities;

import java.util.ArrayList;

public class WordString {

	private StringBuilder strData;
	private ArrayList<String> words = new ArrayList<String>();
	private ArrayList<Integer> wordPos = new ArrayList<Integer>();
	private ArrayList<String> wordsQ;
	private ArrayList<Integer> wordPosQ;
	private final static char[] defaultDelimiters = { ' ' };
	private char[] delimiters = defaultDelimiters;

	public WordString() {

	}
	
	public WordString(String str) {

		setString(str);

	}
	
	public WordString(StringBuilder str) {

		setString(str);

	}
	
	public void setDelimiters(char[] delimiters) {
		
		this.delimiters = delimiters;
		parseString();
		
	}


	public void setString(String str) {
		
		strData = cleanString(new StringBuilder(str));	
		parseString();
	}
	
	public void setString(StringBuilder str) {
		
		strData = cleanString(str);	
		parseString();
	}
	
	public void setStringNoClean(String str) {
		
		strData.setLength(0);
		strData.append(str);	
		parseString();
	}
	
	public static StringBuilder cleanString(StringBuilder str) {

		if (str == null) {
			return (null);
		}

		int i, l = str.length();
		boolean lastWasBlank = true;
		char ch;
		StringBuilder strRet = new StringBuilder(str.length());

		for (i = 0; i < l; i++) {

			ch = str.charAt(i);

			if (ch == ' ' || ch == '\t') {

				if (lastWasBlank) {

					lastWasBlank = true;

				} else {
					lastWasBlank = true;
					strRet.append(ch);
				}
			} else {

				lastWasBlank = false;
				strRet.append(ch);

			}

		}

		return strRet;

	}

	public String getWord(int position) {
		if (words != null && position < words.size()) {
			return words.get(position);
		}
		
		return null;
	}
	
	private void parseString () {

		if (strData == null) {
			return;
		}
		
		int i, j;
		int st;
		char ch;
		
		words.clear();
		wordPos.clear();
		wordsQ = null;
		wordPosQ = null;

		st = 0;

		for (i = 1; i < strData.length(); i++) {

			ch = strData.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					words.add(strData.substring(st, i));
					wordPos.add(st);
					st = i + 1;
					break;
				}
			}
		}
		
		if (st < strData.length()) {
			words.add(strData.substring(st));
			wordPos.add(st);
		}

	}

	private void parseStringQuoted() {

		if (strData == null) {
			return;
		}
		
		if (wordsQ != null) {
			return;
		}
		
		wordsQ = new ArrayList<String>();
		wordPosQ = new ArrayList<Integer>();
		
		int i, j;
		int st;
		char ch;
		boolean inquote = false;
		
		st = 0;

		for (i = 0; i < strData.length(); i++) {

			ch = strData.charAt(i);

			if (ch == '"') {
				inquote = ! inquote;
			}
			
			if (!inquote) {
				for (j = 0; j < delimiters.length; j++) {
					if (ch == delimiters[j]) {
						wordsQ.add(strData.substring(st, i));
						wordPosQ.add(st);
						st = i + 1;
						break;
					}
				}
			}
		}
		
		if (st < strData.length()) {
			wordsQ.add(strData.substring(st));
			wordPosQ.add(st);
		}

	}

	public int getWordPos(int position) {

		if (wordPos != null && position < wordPos.size()) {
			return wordPos.get(position);
		}
		
		return (-1);
	}

	public int getWordPosQuoted(int position) {

		if (wordPosQ != null && position < wordPosQ.size()) {
			return wordPosQ.get(position);
		}
		
		return (-1);
	}

	public int getWordCount() {

		return words.size();
	}

	public static int getWordCount(String str) {

		return (getWordCount(str, defaultDelimiters));

	}

	public static int getWordCount(String str, char[] delimiters) {
		StringBuilder strData = new StringBuilder(str);
		
		return getWordCount(strData, delimiters);
	}
	
	public static int getWordCount(StringBuilder str, char[] delimiters) {

		int i, j, counter;
		int last = -1;
		char ch;

		counter = 0;

		str = cleanString(str);

		for (i = 1; i < str.length(); i++) {

			ch = str.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					counter++;
					last = i;
					break;
				}
			}
		}

		if (last < str.length() - 1) {
			counter++;
		}

		return (counter);
	}

	public int getWordCountQuoted() {

		parseStringQuoted();
		
		return wordsQ.size();

	}

	public static int getWordCountQuoted(String str) {

		return (getWordCountQuoted(str, defaultDelimiters));

	}

	public static int getWordCountQuoted(String str, char[] delimiters) {
		return getWordCountQuoted(new StringBuilder(str), delimiters);
	}
	
	public static int getWordCountQuoted(StringBuilder str, char[] delimiters) {

		int counter, i;
		String word;

		counter = 0;
		i = 0;

		WordString words = new WordString(str);

		word = words.getWord(i);

		while (word != null) {

			counter++;

			if (word.startsWith("\"")) {

				word = words.getWords(i, "\"");
				i += WordString.getWordCount(word) - 1;

			}

			i++;
			word = words.getWord(i);

		}

		return (counter);
	}

	public String getWordQuoted(int position) {

		parseStringQuoted();
		
		if (wordsQ != null && position < wordsQ.size()) {
			return cleanQuotes(wordsQ.get(position));
		}
		
		return null;
	}

	private String cleanQuotes(String word) {

		if ("\"\"".equals(word)) {
			return "";
		}
		if (word.length() > 1 && word.charAt(0) == '"' && word.charAt(word.length()-1) == '"') {
			return word.substring(1, word.length()-1);
		}

		return word;
	}

	public String getWordQuotedAndOn(int position) {

		parseStringQuoted();
		
		int p = getWordPosQuoted(position);

		if (p >= 0) return strData.substring(p);
			
		return (null);
	}

	public String getWordAndOn(int position) {

		int p = getWordPos(position);

		if (p >= 0) return strData.substring(p);
			
		return (null);
	}
	
	public String getWords(int startPosition, int number) {

		int p1 = getWordPos(startPosition);
		int end = startPosition+number;
		
		if (p1 >= 0 && end >= getWordCount()) {
			return getWordAndOn(startPosition);
		}
		
		int p2 = getWordPos(end);
		
		if (p2 >= 0) {
			p2 += getWord(end).length();
		}
		
		return strData.substring(p1, p2-1);
	}

	public String getWords(int startPosition, String endChar) {

		int i = startPosition;
		String retS = null;
		String word;

		retS = getWord(i);
		if (retS.endsWith(endChar) && retS.length() != 1) {
			return retS;
		}

		word = getWord(++i);
		while (word != null) {

			retS = retS + delimiters[0] + word;

			if (word.endsWith(endChar)) {
				break;
			}

			i++;
			word = getWord(i);
		}

		return (retS);
	}

	public String toString() {
		return (strData.toString());
	}

	public static void main2(String args[]) {
		
		
		WordString words = new WordString(" 	  Vector currencyResponse = this.getParentEPanel().getCIBCEPanelContainer().sendCommsMessage(currencyRequest);");
    	words.setDelimiters(new char[] { '=', '}', '.', ' ', '{', '\t', '(', ')' });

		int l = words.getWordCount();

		for (int i = 0; i < l; i++) {

			String word = words.getWord(i);
			System.out.println(word);
		}
	}
	
	public static void main(String args[]) {

		//WordString words1 = new WordString("objectclasses: ( 1.3.18.0.2.6.120 NAME 'eNTGroup' DESC 'Object class class used to define entries that represent DNS domains in the directory. The domainComponent attribute should be used for naming entries of this object class.' SUP top MUST eNTDomainGroupID MAY ( description $ eNTGroupAttributes $ member $ ntGroupCreateNewGroup $ ntGroupDeleteGroup $ ntGroupID $ ntGroupType $ principalPtr ) )");
		WordString words1 =
			new WordString("####<Oct 29, 1999 8:41:13 AM EDT> <Debug> <cibc.cbfe> <cbfe-dev-app01> <1bdit-srv1> <ExecuteThread: '71' for queue: 'default'> <> <57:790404fcd71827fe> <000000> <1999.10.29 8:41:13:604 America/Montreal::BT001::LOGON::EA10004  com.bankframe.cibc.ei.transactionhandler.response.CoinsResponse::executeMethod::The methodName =  getResponseType> ");
						//   0          1        2     3     4   5   6     7     8       9        10     11    12      13              14          15    16171819       20         21   22  23      24     25 26         27          28  29 30  31 32                  33                                                    34     35      36        37                        38
		words1.setDelimiters("<>:".toCharArray());
		
		int l = words1.getWordCount();
		for (int i = 0; i < l; i++) {
			System.out.println(i + ": " +words1.getWord(i));
		}

		System.out.println(words1.getWords(24, 4));

		String desc = words1.getWords(1, "3");
		System.out.println(desc);
		int i = WordString.getWordCount(desc, "<>:".toCharArray());
		System.out.println(i);
		System.out.println(words1.getWord(i + 1));

		WordString words2 =
			new WordString("'Object class class used to define entries that represent DNS domains in the directory. The domainComponent attribute should be used for naming entries of this object class.'");
		System.out.println(words2.getWordCount());

		System.out.println("Quoted");
		String strs = "\"word1 word2\" \"word3 word4\" word5";
		System.out.println(WordString.getWordCountQuoted(strs) + " - " + WordString.getWordCount(strs) + " - " + strs);
		WordString wqs = new WordString(strs);
		l = wqs.getWordCountQuoted();
		for (i = 0; i < l; i++) {
			System.out.println(i + ": " +wqs.getWordQuoted(i));
		}
		
		strs = "#IF 1 = 1 \"\"";
		System.out.println(WordString.getWordCountQuoted(strs) + " - " + WordString.getWordCount(strs) + " - " + strs);
		wqs = new WordString(strs);
		l = wqs.getWordCountQuoted();
		for (i = 0; i < l; i++) {
			System.out.println(i + ": " +wqs.getWordQuoted(i));
		}

		strs = "#ADDTO !S_TEMP \" minutes\" \" test \"";
		System.out.println(WordString.getWordCountQuoted(strs) + " - " + WordString.getWordCount(strs) + " - " + strs);

		wqs = new WordString(strs);
		l = wqs.getWordCountQuoted();
		for (i = 0; i < l; i++) {
			System.out.println(i + ": " +wqs.getWordQuoted(i));
		}

		System.out.println(wqs.getWordQuotedAndOn(2));

	}

	public StringBuilder getString() {
		return strData;
	}

}