package ca.bell.reporting.utilities;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

public class SelectOneBox extends Dialog implements ActionListener {
	static public final int OK = 1;
	static public final int CANCEL = 4;

	private int buttonPressed = -1;
	private String message = new String("");
	private List 	list;
	private Button bnOK;
	private Button bnCancel;
	private Panel buttonPanel;
	
	private int[] selected;

	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 */
	public SelectOneBox(Frame parent) {

		super(parent, parent.getTitle());
		init(300, 120);
	}
	
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param title java.lang.String
	 */
	public SelectOneBox(Frame parent, String title) {
		super(parent, title);
		init(300, 120);
	}
	
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param title java.lang.String
	 * @param modal boolean
	 */
	public SelectOneBox(Frame parent, String title, boolean modal) {
		super(parent, title, modal);
		init(300, 120);
	}
	
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param modal boolean
	 */
	public SelectOneBox(Frame parent, boolean modal) {
		super(parent, parent.getTitle(), modal);
		init(300, 120);
	}

	public SelectOneBox(Frame parent, String title, boolean modal,
		Vector items, int width, int height) {
		super(parent, title, modal);

		init(width, height);
		setList(items);
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {

		String actionName = "";

		if (e.getSource() instanceof Button) {
			Button bn = (Button) e.getSource();
			actionName = bn.getName();
		}

		buttonPressed = -1;

		if (actionName.equals("OK")) {
			
			buttonPressed = OK;
			
			selected = list.getSelectedIndexes();
			
			
		} else if (actionName.equals("Cancel")) {
			
			buttonPressed = CANCEL;
			selected = null;

		}
		
		if (buttonPressed > 0) {

			setVisible(false);
			dispose();
		}
	}
	
	public int[] getSelectedIndexes() {
		
		return selected;
		
	}

	public int getButtonPressed() {
		
		return buttonPressed;
		
	}

	protected void init(int w, int h) {

		buttonPanel = new Panel();

		setLayout(new BorderLayout());
		setBounds(100, 300, w, h);

		list = new List();
		list.setMultipleMode(true);
		
		add(list, "Center");
		add(buttonPanel, "South");

		bnOK = makeButton(buttonPanel, "OK");
		bnCancel = makeButton(buttonPanel, "Cancel");
	}

	protected Button makeButton(Panel pn, String name) {
		Button button = new Button(name);
		pn.add(button);
		button.setName(name);
		button.addActionListener(this);
		return button;
	}

	public void setList(Vector list) {

		for (int i = 0; i < list.size(); i++) {

			this.list.add((String)list.get(i));
			
		}
		
	}
	
	public static void main(String args[]) {
	
		Vector list = new Vector();
		
		list.add("Item 1");
		list.add("Item 2");
		list.add("Item 3");
		list.add("Item 4");
		list.add("Item 5");
		
		Frame frame = new Frame();
		
		SelectOneBox box = new SelectOneBox(frame, "Title", true, list, 300, 200);
		
		box.setVisible(true);
		
		if (box.getButtonPressed() == SelectOneBox.OK) {

			int[] sel = box.getSelectedIndexes();
			
			for (int i = 0; i < sel.length; i++) {
	
				System.out.print(sel[i]+" ");
				
			}

			System.out.println(" ");
			
		} else {
		
			System.out.println("Cancelled");	
		}
		
	}
}