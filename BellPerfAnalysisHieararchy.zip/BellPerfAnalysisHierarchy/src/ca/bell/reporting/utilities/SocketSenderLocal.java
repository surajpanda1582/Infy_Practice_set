package ca.bell.reporting.utilities;

import java.io.*;
import java.net.*;

public class SocketSenderLocal {

	private int port;
	private int readPort;
	private String address;
	
	public SocketSenderLocal( String address, int port, int readPort ) {
	
		this.port = port;
		this.readPort = readPort;
		this.address = address;
	
	}
	public static void main(String args[]) {
	
		SocketSenderLocal sender = new SocketSenderLocal("211.211.211.1", 8020, 8021);
		
		System.out.println("Reply:"+Utility.toString(sender.send("#CMD !BASEMT_REC_LIGHT On ".getBytes())));
		System.out.println("Reply:"+Utility.toString(sender.send("#CMD !BASEMT_REC_LIGHT Off ".getBytes())));

	}
	public byte[] send( byte[] data ) {

		StringBuffer sb = new StringBuffer();
		ServerSocket ser = null;
		byte[] buffer = new byte[1024];


		try {

			ser = new ServerSocket(readPort);

			Socket soc = new Socket(address, port);

			OutputStream os = soc.getOutputStream();

			os.write(data);
			os.close();
			soc.close();


			
			soc = ser.accept();
			
			InputStream is = soc.getInputStream();
			
			int num = 0;
			sb.setLength(0);
			
			do {
				
				num = is.read(buffer);
				for (int i=0; i<num; i++) {
					sb.append((char)buffer[i]);
				}
				
			} while (num > 0);

			
			is.close();
			soc.close();
			ser.close();

		} catch (Exception e) {

			System.out.println(e);
			System.exit(1);

		}
		
		return (sb.toString().getBytes());
	}
}
