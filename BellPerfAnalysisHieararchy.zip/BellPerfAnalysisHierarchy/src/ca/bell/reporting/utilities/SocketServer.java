package ca.bell.reporting.utilities;

import java.io.*;
import java.net.*;

public class SocketServer extends Thread {

	private int port;

	private SocketListener listener;

	public SocketServer(SocketListener listener, int port) {

		this.port = port;
		this.listener = listener;

	}

	public void run() {

		ServerSocket ser = null;
		Socket soc = null;
		StringBuffer sb = new StringBuffer();
		byte[] buffer = new byte[1024];

		try {

			ser = new ServerSocket(port);

			while (true) {

				soc = ser.accept();

				InetAddress replyAddr = soc.getInetAddress();

				InputStream is = soc.getInputStream();
				OutputStream os = soc.getOutputStream();

				int num = 0;
				sb.setLength(0);

				//Wait for available chars
				while (is.available() == 0) {

					try {

						Thread.sleep(100);
					} catch (InterruptedException ignored) {
					}

				}

				do {

					num = is.read(buffer);
					for (int i = 0; i < num; i++) {
						sb.append((char) buffer[i]);
					}

				} while (is.available() > 0);

				byte[] reply = listener.processData(sb.toString().getBytes());

				if (reply != null)
					os.write(reply);

				//is.close();
				//os.close();
				soc.close();

			}

		} catch (IOException e) {

			System.out.println(e);

		}
	}
}
