package ca.bell.reporting.utilities;

public class Semaphor {
	
	private String data = null;
	
	public Semaphor() {
	}
	
	public Semaphor(String data) {
		
		this.data = data;
	}
	
	public synchronized void signal() {
		notify();
	}
	
	public synchronized String getData() {
		return data;
	}
	
	public synchronized boolean hasData() {
		return data != null;
	}
	
	public synchronized void setData(String data) {
		this.data = data;
	}
	
	
	public synchronized void waitForever() throws InterruptedException {
		wait();
	}
	
	public synchronized void waitTimed(long time) throws InterruptedException {
		wait(time);
	}
	
	public static void main(String[] args) {

		Semaphor sem = new Semaphor();
		
		SemTestThread thread = new SemTestThread(sem);

		System.out.println("starting thread");

		thread.start();
		
		System.out.println("main waiting");

		try {
			sem.waitForever();
		} catch (InterruptedException ignored) {
		
			System.out.println("main interrupted");
		}

		if (sem.getData() != null) {
			
			System.out.println("Data:"+sem.getData());
			
		} else {
		
			thread.interrupt();

			try {
				Thread.sleep(2000);
			} catch (InterruptedException ignored) {
			
				System.out.println("thread interrupted");
			}
			
		}


		System.out.println("main done");

		System.exit(0);		
	}
}

class SemTestThread extends Thread {
	
	private Semaphor sem;
	
	public SemTestThread (Semaphor sem) {
		
		this.sem = sem;	
	}
	
	public void run() {
	
		System.out.println("thread running");

		try {
			Thread.sleep(2000);
		} catch (InterruptedException ignored) {
		
			System.out.println("thread interrupted");
		}
		
		sem.setData("data");
		System.out.println("thread done");
		sem.signal();
	}
}