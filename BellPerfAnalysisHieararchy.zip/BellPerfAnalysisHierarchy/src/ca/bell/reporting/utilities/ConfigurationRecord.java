package ca.bell.reporting.utilities;

/**
 * This type was created in VisualAge.
 */
public class ConfigurationRecord {
	static public final int INT_TYPE = 1;
	static public final int INT_ARRAY_TYPE = 2;
	static public final int DATE_TYPE = 3;
	static public final int STRING_TYPE = 4;
	public String name;
	public int type;
	public int intValue;
	public int[] intArrayValue;
	public String stringValue;
	public java.util.GregorianCalendar dateValue;
static public ConfigurationRecord read(CSVReader reader)
{
	if (!reader.readRecord())
		return null;
	ConfigurationRecord rec = new ConfigurationRecord();
	rec.name = reader.getColumn(0);
	rec.type = reader.getColumnAsInt(1);
	switch (rec.type)
	{
		case INT_TYPE :
			rec.intValue = reader.getColumnAsInt(2);
			break;
		case STRING_TYPE :
			rec.stringValue = reader.getColumn(2);
			break;
		case INT_ARRAY_TYPE :
			rec.intArrayValue = reader.getColumnAsIntArray(2);
			break;
		case DATE_TYPE :
			rec.dateValue = reader.getColumnAsCalendar(2);
			break;
		default :
			return null;
	}
	return rec;
}
public boolean write(CSVWriter writer)
{
	writer.add(name);
	writer.add(type);
	switch (type)
	{
		case INT_TYPE :
			writer.add(intValue);
			break;
		case STRING_TYPE :
			writer.add(stringValue);
			break;
		case INT_ARRAY_TYPE :
			writer.add(intArrayValue);
			break;
		case DATE_TYPE :
			writer.add(dateValue);
			break;
		default :
			return false;
	}
	return writer.writeRecord();
}
}