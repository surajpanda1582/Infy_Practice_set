package ca.bell.reporting.utilities;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Calendar;
import java.util.GregorianCalendar;

import ca.bell.reporting.io.StringReader;

import com.sun.xml.internal.ws.util.StringUtils;

/**
 * This type was created in VisualAge.
 */
public class Utility {
	
	public static String DIGITS = "0123456789";
	public static String DIGITS_DOT = "0123456789.";

	/**
	* Utility constructor comment.
	*/ 
	private Utility() {
		super();
	}
	/**
	* This method was created in VisualAge.
	* @return boolean
	* @param searchIn String
	* @param searchFor String
	*/
	public static boolean after(GregorianCalendar searchIn, GregorianCalendar searchFor) {
		if (searchFor == null)
			return false;
		if (searchIn == null)
			return true;
		return searchIn.after(searchFor);
	}
	
	public static int countChars(String haystack, char needle) {
	    int count = 0;
	    for (int i=0; i < haystack.length(); i++)
	    {
	        if (haystack.charAt(i) == needle)
	        {
	             count++;
	        }
	    }
	    return count;
	}
	
	
	/**
	* This method was created in VisualAge.
	* @return boolean
	* @param searchIn String
	* @param searchFor String
	*/
	public static boolean before(GregorianCalendar searchIn, GregorianCalendar searchFor) {
		if (searchFor == null)
			return false;
		if (searchIn == null)
			return true;
		return searchIn.before(searchFor);
	}
	/**
	* This method was created in VisualAge.
	* @return boolean
	* @param searchIn String
	* @param searchFor String
	*/
	public static boolean contains(String searchIn, String searchFor) {
		if (searchFor == null || searchFor.length() == 0)
			return true;
		if (searchIn == null || searchIn.length() == 0)
			return false;
		if (searchIn.toUpperCase().indexOf(searchFor.toUpperCase()) == -1)
			return false;
		return true;
	}

	/**
	* Test equality
	* @return boolean
	* @param searchIn String
	* @param searchFor String
	*/
	public static boolean isEqualOrNull(String searchIn, String searchFor) {
		if (searchFor == null || searchFor.length() == 0)
			return true;
		if ((searchIn == null || searchIn.length() == 0) && (searchFor != null && searchFor.length() > 0))
			return false;
		if (searchIn.equalsIgnoreCase(searchFor))
			return true;
		return false;
	}
/**
	* This method was created in VisualAge.
	* @param str java.lang.String
	*/
	public static String fixMixCase(String str) {
		int i;
		char ch;
		boolean inWord = false;
		if (str == null || str.length() == 0)
			return str;
		StringBuffer sb = new StringBuffer(str.length());
		for (i = 0; i < str.length(); i++) {
			ch = str.charAt(i);
			if (inWord) {
				if (ch == ' ' || ch == '-' || ch == ':' || ch == ',' || ch == '.' || ch == 0)
					inWord = false;
				sb.append(String.valueOf(ch).toLowerCase());
			}
			else {
				if (ch != ' ' && ch != '-' && ch != ':' && ch != ',' && ch != '.' && ch != 0)
					inWord = true;
				sb.append(ch);
			}
		}
		return new String(sb);
	}
	/**
	* This method was created in VisualAge.
	* @return boolean
	* @param searchIn int[]
	* @param searchFor int[]
	*/
	public static boolean intArrayContains(int[] searchIn, int[] searchFor) {
		int i, j, k;
		if (searchFor == null || searchFor.length == 0)
			return true;
		if (searchIn == null || searchIn.length == 0)
			return false;
		for (i = 0; i < searchFor.length; i++) {
			k = -1;
			for (j = 0; j < searchIn.length; j++) {
				if (searchFor[i] == searchIn[j]) {
					k = j;
					j = searchIn.length;
				}
			}
			if (k == -1)
				return false;
		}
		return true;
	}
	/**
	* This method was created in VisualAge.
	* @param args java.lang.String[]
	*/
	public static void main(String args[]) {
		int[] i = new int[3];
		int[] j1 = new int[3];
		int[] j2 = new int[2];
		int[] j3 = new int[1];
		
		System.out.println(longTo24HourMilli(75467039L));
		System.exit(0);
		
		String time = "2002.7.15 15:53:1,211 America/Montreal::DEBUG:UserSessionID=0000000059::com.ba";
		System.out.println(time);
		long ltime = time24HourMilliToLong(time);
		System.out.println(ltime);
		System.out.println(longTo24HourMilli(ltime));
		
		StringBuffer sb = new StringBuffer();
		
		if (equalsIgnoreCrLf("AbcdED", "AbcdED")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abcd5ED", "AbcdED")) System.out.println("ERROR");
		else System.out.println("OK");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD", "A\n\rbcdE\nD")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD\n", "A\n\rbcdE\nD")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD", "A\n\rbcdE\nD\n")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD\r", "A\n\rbcdE\nD\n")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD\r\n", "A\n\rbcdE\nD\n")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD\r\n", "A\n\rbcdE\nD\n\r")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\ndE\rD\n", "A\n\rbcdE\nD\r\n")) System.out.println("OK");
		else System.out.println("ERROR");
		
		if (equalsIgnoreCrLf("Abc\nde\rD\n", "A\n\rbcdE\nD\r\n")) System.out.println("ERROR");
		else System.out.println("OK");
		
		System.out.println(fixMixCase("TEST TESTING END"));
		System.out.println(fixMixCase("test testing end"));
		System.out.println(fixMixCase("23232 3232 323"));
		System.out.println(fixMixCase(""));
		System.out.println(fixMixCase("YEY"));
		System.out.println(fixMixCase(null));
		i[0] = 3;
		i[1] = 7;
		i[2] = 23;
		j1[0] = 7;
		j1[1] = 3;
		j1[2] = 23;
		System.out.println(intArrayContains(i, j1));
		j1[0] = 3;
		j1[1] = 7;
		j1[2] = 20;
		System.out.println(intArrayContains(i, j1));
		j2[0] = 23;
		j2[1] = 7;
		System.out.println(intArrayContains(i, j2));
		j2[0] = 23;
		j2[1] = 8;
		System.out.println(intArrayContains(i, j2));
		j3[0] = 23;
		System.out.println(intArrayContains(i, j3));
		j3[0] = 24;
		System.out.println(intArrayContains(i, j3));
		System.out.println(intArrayContains(i, null));
		System.out.println(intArrayContains(null, j3));
		System.out.println(intArrayContains(null, null));
		
		System.out.println("Is not in String");
		System.out.println(containsOnly("1929", DIGITS));
		System.out.println(containsOnly("19 29", DIGITS));
		
		System.out.println("Test isNumber");
		System.out.println("null "+isNumber((String)null));
		System.out.println(" "+isNumber(""));
		System.out.println("-1231 "+isNumber("-1231"));
		System.out.println("1221 "+isNumber("1221"));
		System.out.println("sss "+isNumber("sss"));
		System.out.println("12s2 "+isNumber("12s2"));
		System.out.println("+122 "+isNumber("+122"));
		System.out.println("+ "+isNumber("+"));
		System.out.println("' 1' "+isNumber(" 1"));
		System.out.println("1 "+isNumber("1"));

		System.out.println( longToAmPm(timeToLong("03:00AM")) );
		System.out.println( longToAmPm(timeToLong("03:00PM")) );
		System.out.println( longToAmPm(timeToLong("12:00PM")) );
		System.out.println( longToAmPm(timeToLong("03:00:00")) );
		System.out.println( longToAmPm(timeToLong("15:00:00")) );
		System.out.println( longToAmPm(timeToLong("12:00:00")) );
		System.out.println( longToAmPm(timeToLong("14:01:00")) );
		System.out.println( longToAmPm(timeToLong("12:30pm") + timeToLong("01:31:00")) );

		System.out.println( replaceString("ABCDEF", "ABC", "abc") );
		System.out.println( replaceString("ABCDEF", "BCD", "bcd") );
		System.out.println( replaceString("ABCDEF", "DEF", "def") );
		System.out.println( replaceString("ABAAEF", "A", "a") );
		System.out.println( replaceString("AAAA", "A", "a") );
		System.out.println( replaceString("Aaaa", "Aa", "AA") );
		System.out.println( replaceString("Aaaa", "Aa", "Aa") );

	
		System.out.println( "'"+stringRetrieve("<s>Aaaa<e>", "<s>", "<e>") +"'");
		System.out.println( "'"+stringRetrieve("<s>Aaaa", "<s>", "<e>") +"'");
		System.out.println( "'"+stringRetrieve("2010-02-09 17:24:56,617 DEBUG OrderMax- |A23D39X9||At GetCalendarsBFO handleCallToParallelFramework:: schedule called successful for ID::ID:P<687960.1265754296615.0>", "|", "|") +"'");
}
	
	public static String newString(String from) {
	
		if (from == null) {
			return (null);
		}
		
		return (new String(from));
	}

	public static String toString(byte[] data) {
	
		StringBuffer sb = new StringBuffer();
		
		for (int i=0; i<data.length; i++) {
			sb.append((char)data[i]);
		}
		
		return (sb.toString());
	}

	public static boolean containsOnly(String searchString, String allowable) {
	
		int i, j;
		boolean found = false;
		char[] searchStringChars = searchString.toCharArray();
		char[] allowableChars = allowable.toCharArray();
		
		for (i=0; i<searchStringChars.length; i++) {
		
			found = false;
			for (j=0; j<allowableChars.length; j++) {
			
				if (searchStringChars[i] == allowableChars[j]) {
				
					found = true;
					break;
				
				}
			
			}
			
			if (!found) {
			
				return (false);
			
			}
		
		}

		return (true);			
	
	}

	public static boolean isNumber(String value)	{
	  
		if (value == null || value.length() == 0) return (false);
		

	  char ch = value.charAt(0);
		
	  if (ch == '-' || ch == '+')  value = value.substring(1);

	  if (value.length() == 0) return false;
	  
	  return (containsOnly(value, DIGITS));
	}	

	public static boolean isDigitsOnly(String value)	{
		  
			if (value == null || value.length() == 0) return (false);
			

		  if (value.length() == 0) return false;
		  
		  return (containsOnly(value, DIGITS));
		}	

	public static String digitsOnly(String value)	{
	  
		if (value == null || value.length() == 0) return ("");
		
		StringBuffer ret = new StringBuffer();

	  	int ch = value.charAt(0);
		
		for (int i = 0; i < value.length(); i++) {
			
			ch = value.charAt(i);
			
			if (DIGITS.indexOf(ch) >= 0) ret.append((char)ch);
		}
			
	  	return ret.toString();
	}	

	public static boolean isDecimalNumber(String value)	{
	  
		if (value == null || value.length() == 0) return (false);

	  char ch = value.charAt(0);
		
	  if (ch == '-' || ch == '+')  value = value.substring(1);

	  return (containsOnly(value, DIGITS_DOT));
	}	

	public static String toDateString(GregorianCalendar date) {
	
		StringBuffer sb = new StringBuffer();
		int i;
		
		sb.append(date.get(Calendar.YEAR));
		sb.append('-');
		
		sb.append(toMonthDayString(date));
		
		return (sb.toString());
	}
			
	public static String toDateTimeString(GregorianCalendar date) {
	
		StringBuffer sb = new StringBuffer();
		int i;
		
		sb.append(toDateString(date));
		sb.append('-');
		
		sb.append(toTimeString(date));
			
		return (sb.toString());
	}

	public static String toMonthDayString(GregorianCalendar date) {
	
		StringBuffer sb = new StringBuffer();
		int i;
		
		i = date.get(Calendar.MONTH)+1;
		if (i<10) sb.append("0"+i);
		else sb.append(i);
		sb.append('-');
		
		i = date.get(Calendar.DAY_OF_MONTH);
		if (i<10) sb.append("0"+i);
		else sb.append(i);
	
		return (sb.toString());
	}
	
	public static String toTimeString(GregorianCalendar date) {
	
		StringBuffer sb = new StringBuffer();
		int i;
		
		i = date.get(Calendar.HOUR_OF_DAY);
		if (i<10) sb.append("0"+i);
		else sb.append(i);
		sb.append(':');

		i = date.get(Calendar.MINUTE);
		if (i<10) sb.append("0"+i);
		else sb.append(i);
		sb.append(':');

		i = date.get(Calendar.SECOND);
		if (i<10) sb.append("0"+i);
		else sb.append(i);
	
		return (sb.toString());
	}

	public static boolean equalsIgnoreCrLf(String str1, String str2) {
	
		char ignored[] = { '\r','\n','\t',' '};
		
		if (str1 == null && str2 == null) {
			return (true);
		}
		if (str1 == null || str2 == null) {
			return (false);
		}

		String cstr1 = stripString(str1, ignored);
		String cstr2 = stripString(str2, ignored);


		return (cstr1.equals(cstr2));
	
	}

	public static boolean equalsIgnoreNumerically(String str1, String str2) {
		
		char ignored[] = { '0','1','2','3','4','5','6','7','8','9'};
		
		if (str1 == null && str2 == null) {
			return (true);
		}
		if (str1 == null || str2 == null) {
			return (false);
		}

		String cstr1 = stripStringKeeping(str1, ignored);
		String cstr2 = stripStringKeeping(str2, ignored);


		return (cstr1.equals(cstr2));
	
	}

	public static boolean equalsIgnoreCrLfAndLongLength(String str1, String str2) {
		
		char ignored[] = { '\r','\n','\t',' '};
		
		if (str1 == null && str2 == null) {
			return (true);
		}
		if (str1 == null || str2 == null) {
			return (false);
		}

		String cstr1 = stripString(str1, ignored);
		String cstr2 = stripString(str2, ignored);
		
		int l = Math.min(cstr1.length(), cstr2.length());
		
		if (l > 200) {
			cstr1 = cstr1.substring(0, l);
			cstr2 = cstr2.substring(0, l);
		}

		return (cstr1.equals(cstr2));
	
	}

/**
 * 
 * 
 * Creation date: (6/24/2001 8:15:54 PM)
 * @return java.lang.String
 */
public static String firstLine( String lines ) {

	int i = lines.indexOf("\r");
	int j = lines.indexOf("\n");

	if (i == -1 && j == -1)
		return lines;

	if (i == -1)
		return lines.substring(0, j);
	
	if (j == -1)
		return lines.substring(0, i);
	
	return lines.substring(0, Math.min( i, j));
	
}

public static String fixCrLf( String lines ) {

	if (lines == null) return null;

	StringBuffer ret = new StringBuffer();

	int l = lines.length();

	for (int i = 0; i < l; i++) {

		char ch = lines.charAt(i);

		if (ch == '\n') {

			if (lines.charAt(i-1) != '\r')
				ret.append('\r');
		}

		ret.append(ch);
	}
	
	return ret.toString();
	
}

public static boolean inChar(char ch, char ignore[]) {
  int i;

  for (i = 0; i < ignore.length; i++)
  	if (ch == ignore[i]) return true;
  
  return false;
}

	/**
	*
	* @param str java.lang.String
	*/
	public static String leftJustify(String str, int length) {

		if ( str == null ) str = "";

		if ( str.length() >= length ) return str.substring(0, length);
		return str + 
			"                                                                        ".substring(0, length - str.length());
		
	}

	public static String leftJustify(String str, int length, char ch) {

		if ( str == null ) str = "";

		StringBuffer sb = new StringBuffer(str);
		
		if ( str.length() >= length ) return str.substring(0, length);
		
		int l = length - str.length();
		for (int i = 0; i < l; i++) sb.append(ch);
		
		return sb.toString();
		
	}
/**
 * 
 * 
*/
public static String longToAmPm( long time ) {

	long hours = time/3600;

	time = time - (hours*3600);

	long minutes = time/60;

	long seconds = time - (minutes*60);

	String ap = "AM";

	if (hours > 12L) {
		
		hours -= 12L;
		ap = "PM";

	} else if (hours == 12L) {

		ap = "PM";
	}

	return Utility.zeroFill(hours, 2) + ":" +
		Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2) + ap;	
}

public static String longTo24HourTimeOnly( long time ) {

	DateUtility du = new DateUtility(time);
	int hours = du.getHour();
	int minutes = du.getMinute();
	int seconds = du.getSecond();
	
	return Utility.zeroFill(hours, 2) + ":" +
	Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);	

}

public static String longTo24Hour( long time ) {

	long hours = time/3600;

	time = time - (hours*3600);

	if (hours > 23) {
		hours = hours - ((hours/24)*24);
	}
	
	long minutes = time/60;

	long seconds = time - (minutes*60);

	return Utility.zeroFill(hours, 2) + ":" +
		Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);	
}

public static String longTo24DayHour( long time ) {

	long hours = time/3600;

	time = time - (hours*3600);

	long days = 0;
	if (hours > 23) {
		days = hours/24;
		hours = hours - (days*24);
	}
	
	long minutes = time/60;

	long seconds = time - (minutes*60);

	if (days > 0) {
		return days + ":" + Utility.zeroFill(hours, 2) + ":" +
		Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);	
	
	} else {
		return Utility.zeroFill(hours, 2) + ":" +
		Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);	
		
	}
}

public static String longTo24HourNoDate( long time ) {

	DateUtility dt = new DateUtility(time);
	
		return dt.toTimeString24H();
}

public static String longTo24HourMilliBlankedZero( long time ) {
	if (time == 0L) {
		return "";
	}
	
	return longTo24HourMilli(time);
}

public static String longTo24HourMilli( long time ) {

	long hours = time/3600000;

	time = time - (hours*3600000);

	long minutes = time/60000;

	time = time - (minutes*60000);

	long seconds = time/1000;

	long milli = time - (seconds*1000);

	return Utility.zeroFill(hours, 2) + ":" +
		Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2)
		+":"+Utility.zeroFill(milli, 3);	
}

public static String longTo24HourMilli2( long time ) {

	long hours = time/3600000;

	time = time - (hours*3600000);

	long minutes = time/60000;

	time = time - (minutes*60000);

	long seconds = time/1000;
	
	String days = "";
	
	if (hours > 24) {
		
		long ldays = hours/24;
		days = ldays + "d:";
		
		hours = hours - (ldays*24);
	}
	
	if (hours > 0 || days.length() > 0) { 
		return days + Utility.zeroFill(hours, 2) + ":" +
			Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);
	} else {
		return Utility.zeroFill(minutes, 2) + ":" + Utility.zeroFill(seconds, 2);
	}
}

	/**
	*
	* @param str java.lang.String
	*/
	public static String replaceString(String str, String find, String replace) {

		if ( str == null ) return null;

		int oldPos = -1;
		int flen = find.length();
		int rlen = replace.length();

		int pos = str.indexOf(find);
		
		while ( pos >= 0 && pos != oldPos) {

			if (pos == 0) {

				str = replace + str.substring( flen );
					
			} else if (pos == str.length()) {

				str = str.substring( 0, pos ) + replace;
				
			} else {
				
				str = str.substring( 0, pos ) + replace + str.substring( pos+flen );
			} 

			oldPos = pos;
			pos = str.indexOf(find);
		}

		return str;
	}

public static String stripString(String str, char ignore[]) {
  int i;
  char ch;
  
  if (str == null || str.length() == 0)
    return str;
    
  StringBuffer sb = new StringBuffer(str.length());
  
  for (i = 0; i < str.length(); i++) {
	  
    ch = str.charAt(i);

    if (!inChar(ch, ignore))
    	sb.append(ch);

  }
  
  return sb.toString();
}

public static String stripStringKeeping(String str, String keep) {
	
	return stripStringKeeping(str, keep.toCharArray());
}

public static String stripStringKeeping(String str, char keep[]) {
	  int i;
	  char ch;
	  
	  if (str == null || str.length() == 0)
	    return str;
	    
	  StringBuffer sb = new StringBuffer(str.length());
	  
	  for (i = 0; i < str.length(); i++) {
		  
	    ch = str.charAt(i);

	    if (inChar(ch, keep))
	    	sb.append(ch);

	  }
	  
	  return sb.toString();
	}

 /**
  * Time to long milliseconds
  * Format of time: HH:MM:SS:mmm
  */
public static long time24HourMilliToLong( String str ) {

	long time = 0L;
	int[] times = {0,0,0,0};

	char[] chars = new char[50];
	
	int l = Math.min(50, str.length());
	str.getChars(0, l, chars, 0);

	// Find first digit
	int i = 0;
	for (;i < l && !Character.isDigit(chars[i]); i++);
	
	StringBuffer buffer = new StringBuffer();
	
	for (int j = 0; j < 4; j++) {
	
		buffer.setLength(0)	;
		
		for (;i < l && Character.isDigit(chars[i]); i++) {
			
			buffer.append(chars[i]);
			
		}
		i++;    //Skip : and space
	
		try {
			
			times[j] = Integer.parseInt(buffer.toString());

		} catch (NumberFormatException ignored) {

			return 0l;
		}
	}
	
	
	time = times[0] * 3600000L +
		   	times[1] * 60000L +
		   	times[2] * 1000L +
		   	times[3];
	
	return time;

}

public static long time24HourMilliToLongNoSpace( String str ) {

	long time = 0L;
	int[] times = {0,0,0,0};

	char[] chars = new char[50];
	
	int l = Math.min(50, str.length());
	str.getChars(0, l, chars, 0);

	int i = 0;

	StringBuffer buffer = new StringBuffer();
	
	for (int j = 0; j < 4; j++) {
	
		buffer.setLength(0)	;
		
		for (;i < l && chars[i] != ' ' && chars[i] != ':'; i++) {
			
			buffer.append(chars[i]);
			
		}
		i++;    //Skip : and space
	
		try {
			
			times[j] = Integer.parseInt(buffer.toString());

		} catch (NumberFormatException ignored) {

			return 0l;
		}
	}
	
	
	time = times[0] * 3600000L +
		   	times[1] * 60000L +
		   	times[2] * 1000L +
		   	times[3];
	
	return time;

}

public static long timeToLong( String time ) {


	if (time == null || time.length() == 0) return 0L;
	
	time = time.toUpperCase();

	int i1 = time.indexOf(':');
	int i2 = time.indexOf(':', i1+1);
	int i3 = time.indexOf('M');

	int hours, minutes, seconds;
	
	if (i3 > 0) {

		char ap = time.charAt(i3-1);

		hours = Integer.parseInt(time.substring(0, i1));
		minutes = Integer.parseInt(time.substring(i1+1, i3-1).trim());
		seconds = 0;

		if (ap == 'P' && hours < 12) {

			hours = hours + 12;
			
		}

		if (ap == 'A' && hours == 12) {

			hours = 0;
			
		}
			
	} else {

		hours = Integer.parseInt(time.substring(0, i1));

		if (i2 > 0) {
			
			minutes = Integer.parseInt(time.substring(i1+1, i2));
			seconds = Integer.parseInt(time.substring(i2+1));
			
		} else {

			minutes = Integer.parseInt(time.substring(i1+1));
			seconds = 0;

		}

	}
	
	return (hours*3600L) + (minutes*60L) + seconds;
}

public static int timeHrMinToMinutes(String time) {
	
	int i1 = time.indexOf(':');

	int hours = Integer.parseInt(time.substring(0, i1));
	int minutes = Integer.parseInt(time.substring(i1+1).trim());
	
	return minutes + (hours *60);

}

/**
 * Wraps text with crlf after given characters
 * 
 */
public static String wrapText( String toWrap, int maxLen ) {

	if (toWrap == null || toWrap.length() <= maxLen) return toWrap;

	StringBuffer buffer = new StringBuffer();
	int threeQuarters = maxLen*3/4;

	while (toWrap.length() > maxLen) {

		int breakLoc = -1;
		for (int i=maxLen; i>threeQuarters; i--) {

			String ch = toWrap.substring(i, i+1);
			if (ch.equals(" ") || ch.equals("\t") || ch.equals("-")) {

				breakLoc = i;
				
			}
			
		}

		if (breakLoc == -1) breakLoc = maxLen;

		buffer.append(toWrap.substring(0, breakLoc+1).trim());
		buffer.append("\r\n");
		toWrap = toWrap.substring(breakLoc+1).trim();

	}

	if (toWrap.length() != 0) buffer.append(toWrap);
	
	return buffer.toString();
	
}

	/**
	*
	* 
	*/
	public static String zeroFill(long number, int length) {

		String snumber = String.valueOf(number);

		if (snumber.length() >= length) return snumber;
		
		return "000000000000000000000".substring(0, length-snumber.length())+snumber;
	
	}
	/**
	 * @param int array
	 * @param int array
	 * @return
	 */
	public static boolean isEqual(int[] array1, int[] array2) {
		
		if (array1.length != array2.length) return false;
		
		for (int i = 0; i < array1.length; i++) {
			
			if (array1[i] != array2[i]) return false;
		}
		return true;
	}
	public static String stringRetrieve(String str, String startStr, String endStr) {

		int p1 = str.indexOf(startStr);
		
		if (p1 < 0) {
			return "";
		}
		
		int p2 = str.indexOf(endStr, p1+startStr.length());
		if (p2 < 0) {
			p2 = str.length();
		}
		
		return str.substring(p1+startStr.length(), p2);
	}

	public static String[] getFileStart(File absoluteFile, int lines) {

		String ret[] = new String[lines];
		
		StringReader reader = new StringReader(absoluteFile.getAbsolutePath());
		if (reader.open() == 1) {
			throw new RuntimeException("Cannot open file: " + absoluteFile);
		}
		
		for (int i = 0; i < lines; i++) {
			String str = reader.readLine();
			ret[i] = str;
		}

		reader.close();
		
		return ret;
	}

	public static String[] tailFile( File file, int lines) {
		final long bufferSize = 204800;
		byte buffer[] = new byte[(int)bufferSize];
		
		String[] retLines = new String[lines];
		
	    RandomAccessFile fileHandler = null;
	    
	    try {
	        fileHandler = 
	            new RandomAccessFile( file, "r" );
	        long fileLength = fileHandler.length() - 1;
	        StringBuilder sb = new StringBuilder();
	        int line = lines-1;
	        
	        if (fileLength == 0) {
	        	System.out.println("Empty file: " + file.getAbsolutePath());
	        	return retLines;
	        }

	        long filePointer = fileLength-bufferSize;
	        if (filePointer < 0) {
	        	filePointer = 0l;
	        }
	        for(; filePointer >= 0; filePointer-=bufferSize){
	            fileHandler.seek( filePointer );
	            int readByte = fileHandler.read(buffer);
	            if (readByte > 0) {
		            String bufferS = new String(buffer, 0, readByte);
		            sb.insert(0, bufferS);
		            
		            int p1 = sb.lastIndexOf("\r");
		            int p2 = sb.lastIndexOf("\n");
		            int l = 1;
		            
		            if (p1 >= 0 && p2 >= 0) {
		            	p1 = Math.min(p1, p2);
		            	l = 2;
		            } else if (p2 >= 0) {
		            	p1 = p2;
		            }
		            
		            while (p1 >= 0 && line >= 0) {
		            	retLines[line] = sb.substring(p1+l).toString();
		            	sb.setLength(p1);
		            	line--;
		            	
			            p1 = sb.lastIndexOf("\r");
			            p2 = sb.lastIndexOf("\n");
			            l = 1;
			            
			            if (p1 >= 0 && p2 >= 0) {
			            	p1 = Math.min(p1, p2);
			            	l = 2;
			            } else if (p2 >= 0) {
			            	p1 = p2;
			            }
		            }
	            }
	            if (line < 0 || readByte <= 0) {
	                break;
	            }
	        }

	        if (line >= 0 && sb.length() > 0) {
	        	retLines[line] = sb.toString();
            	line--;
            }
	        
	        return retLines;
	        
	    } catch( java.io.FileNotFoundException e ) {
	    	System.err.println("Exception in file: " + file.getAbsolutePath());
	        e.printStackTrace();
	        return null;
	    } catch( java.io.IOException e ) {
	    	System.err.println("Exception in file: " + file.getAbsolutePath());
	        e.printStackTrace();
	        return null;
	    }
	    finally {
	        if (fileHandler != null )
	            try {
	                fileHandler.close();
	            } catch (IOException e) {
	            }
	    }
	}

}
