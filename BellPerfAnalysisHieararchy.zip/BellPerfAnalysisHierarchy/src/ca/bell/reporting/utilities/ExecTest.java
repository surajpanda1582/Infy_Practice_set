package ca.bell.reporting.utilities;

/**
 * This type was created in VisualAge.
 */
public class ExecTest {
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	String[] pargs = new String[1];
	pargs[0] = "start c:\\temp\\smail0A.jpg";
	try
	{
		Runtime.getRuntime().exec(pargs);
	}
	catch (java.io.IOException e)
	{
		e.printStackTrace();
	}
}
}