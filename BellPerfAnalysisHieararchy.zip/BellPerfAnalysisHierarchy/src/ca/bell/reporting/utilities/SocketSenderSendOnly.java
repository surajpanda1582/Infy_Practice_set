package ca.bell.reporting.utilities;

import java.io.*;
import java.net.*;

public class SocketSenderSendOnly {

	private int port;
	private String address;
	
	public SocketSenderSendOnly( String address, int port ) {
	
		this.port = port;
		this.address = address;
	
	}
public void send(byte[] data) {

  StringBuffer sb = new StringBuffer();
  ServerSocket ser = null;
  byte[] buffer = new byte[1024];

  try {

    Socket soc = new Socket(address, port);

    OutputStream os = soc.getOutputStream();

    os.write(data);
    os.close();
    soc.close();

  } catch (Exception e) {

    System.out.println(e);
    System.exit(1);

  }

}
}
