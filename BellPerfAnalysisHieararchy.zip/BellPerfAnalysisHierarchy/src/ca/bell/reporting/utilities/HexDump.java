/*
 * Created on May 18, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package ca.bell.reporting.utilities;


public class HexDump
{

    private static final String identString = "@(#) $Header: /userland/cvs/pixelmed/imgbook/com/pixelmed/utils/HexDump.java,v 1.8 2003/09/25 22:19:26 dclunie Exp $";

    private HexDump()
    {
    }

    public static String toPaddedDecimalString(int i, char c, int j, String s, String s1)
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(s != null)
            stringbuffer.append(s);
        String s2 = Integer.toString(i);
        for(int k = s2.length(); k++ < j;)
            stringbuffer.append(c);

        stringbuffer.append(s2);
        if(s1 != null)
            stringbuffer.append(s1);
        return stringbuffer.toString();
    }

    public static String byteToPaddedDecimalString(int i)
    {
        return toPaddedHexString(i & 0xff, ' ', 3, null, null);
    }

    public static String shortToPaddedDecimalString(int i)
    {
        return toPaddedHexString(i & 0xffff, ' ', 6, null, null);
    }

    public static String intToPaddedDecimalString(int i)
    {
        return toPaddedHexString(i & 0xffffffff, ' ', 9, null, null);
    }

    public static String toPaddedHexString(int i, char c, int j, String s, String s1)
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(s != null)
            stringbuffer.append(s);
        String s2 = Integer.toHexString(i);
        for(int k = s2.length(); k++ < j;)
            stringbuffer.append(c);

        stringbuffer.append(s2);
        if(s1 != null)
            stringbuffer.append(s1);
        return stringbuffer.toString();
    }

    public static String byteToPaddedHexString(int i)
    {
        return toPaddedHexString(i & 0xff, '0', 2, null, null);
    }

    public static String shortToPaddedHexString(int i)
    {
        return toPaddedHexString(i & 0xffff, '0', 4, null, null);
    }

    public static String intToPaddedHexString(int i)
    {
        return toPaddedHexString(i & 0xffffffff, '0', 8, null, null);
    }

    public static String byteToPaddedHexStringWith0x(int i)
    {
        return toPaddedHexString(i & 0xff, '0', 2, "0x", null);
    }

    public static String shortToPaddedHexStringWith0x(int i)
    {
        return toPaddedHexString(i & 0xffff, '0', 4, "0x", null);
    }

    public static String intToPaddedHexStringWith0x(int i)
    {
        return toPaddedHexString(i & 0xffffffff, '0', 8, "0x", null);
    }

    public static boolean isPrintableCharacter(char c)
    {
        switch(Character.getType(c))
        {
        case 1: // '\001'
        case 2: // '\002'
        case 3: // '\003'
        case 5: // '\005'
        case 6: // '\006'
        case 7: // '\007'
        case 8: // '\b'
        case 9: // '\t'
        case 12: // '\f'
        case 20: // '\024'
        case 21: // '\025'
        case 22: // '\026'
        case 23: // '\027'
        case 24: // '\030'
        case 25: // '\031'
        case 26: // '\032'
        case 27: // '\033'
        case 28: // '\034'
            return true;

        case 4: // '\004'
        case 10: // '\n'
        case 11: // '\013'
        case 13: // '\r'
        case 14: // '\016'
        case 15: // '\017'
        case 16: // '\020'
        case 17: // '\021'
        case 18: // '\022'
        case 19: // '\023'
        default:
            return false;
        }
    }

    public static String byteArrayToPrintableString(byte abyte0[], int i, int j)
    {
        StringBuffer stringbuffer = new StringBuffer();
        stringbuffer.append(" ");
        while(j-- > 0) 
        {
            char c = (char)abyte0[i++];
            if(isPrintableCharacter(c))
                stringbuffer.append(c);
            else
                stringbuffer.append(".");
        }
        return stringbuffer.toString();
    }

    public static String dump(byte abyte0[], int i)
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(abyte0 != null && i > 0)
        {
            int j = 0;
            int k = 0;
            int l = 0;
            do
            {
                if(j >= i)
                    break;
                if(j % 16 == 0)
                {
                    if(j != 0)
                        stringbuffer.append("\n");
                    stringbuffer.append(intToPaddedDecimalString(j));
                    stringbuffer.append(" (");
                    stringbuffer.append(intToPaddedHexStringWith0x(j));
                    stringbuffer.append("):");
                    k = j;
                    l = 0;
                }
                stringbuffer.append(" ");
                stringbuffer.append(byteToPaddedHexString(abyte0[j]));
                j++;
                l++;
                if(j % 16 == 0 || j == i)
                    stringbuffer.append(byteArrayToPrintableString(abyte0, k, l));
            } while(true);
        }
        stringbuffer.append("\n");
        return stringbuffer.toString();
    }

    public static String dump(byte abyte0[])
    {
        return dump(abyte0, abyte0 != null ? abyte0.length : 0);
    }

    public static void main(String args[])
    {
        byte abyte0[] = new byte[256];
        for(int i = 0; i < 256; i++)
            abyte0[i] = (byte)i;

        System.err.println(dump(abyte0));
    }
}