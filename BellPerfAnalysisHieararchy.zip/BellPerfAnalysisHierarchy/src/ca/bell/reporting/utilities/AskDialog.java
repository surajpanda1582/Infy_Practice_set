package ca.bell.reporting.utilities;

import java.awt.*;
import java.awt.event.*;

public class AskDialog extends Dialog implements ActionListener {

	public String value;
	private TextField field;
	
	public AskDialog(Frame parent, String title, String lineOne) {
		super(parent, title, true);

		Panel labelPanel = new Panel();
		labelPanel.setLayout(new GridLayout(2, 1));
		labelPanel.add(new Label(lineOne, Label.CENTER));
		field = new TextField();
		labelPanel.add(field);
		add(labelPanel, "Center");

		Panel buttonPanel = new Panel();
		Button okButton = new Button("OK");
		okButton.addActionListener(this);
		buttonPanel.add(okButton);
		add(buttonPanel, "South");

		FontMetrics fm = getFontMetrics(getFont());
		int width = fm.stringWidth(lineOne);

		setSize(400, 115);
		setLocation(parent.getLocationOnScreen().x + 30, 
			parent.getLocationOnScreen().y + 30);
		setVisible(true);
	}

	/**
	Handles events from the OK button. When OK is pressed the dialog becomes
	invisible, disposes of its self, and retruns.
	*/
	public void actionPerformed(ActionEvent e) {
	
		value = field.getText();
	
		setVisible(false);
		dispose();
	}
}

