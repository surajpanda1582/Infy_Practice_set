package ca.bell.reporting.utilities;

public interface AskDialogListener {

	

}