package ca.bell.reporting.io;
import java.io.*;

import ca.bell.reporting.utilities.DateUtility;
import ca.bell.reporting.utilities.Utility;

public class FileProcessorWithData {
	FileReader ivFileIn;
	BufferedReader ivDataIn;
	LineProcessorWithData ivLineProcessor;
	public int ivLineCounter = 0;
	long ivLength, ivCurrent = 0l;
	Object data = null;
	protected boolean checkEndOfFile;
	private String[] lastFiveLines;

	public FileProcessorWithData(String filename, LineProcessorWithData lineProcessor, Object data) 
		throws IOException {
		
		this(filename, lineProcessor, data, false); 
	}
	
	public FileProcessorWithData(String filename, LineProcessorWithData lineProcessor, Object data, boolean checkEndOfFile)
		throws IOException {
		ivLineProcessor = lineProcessor;
		this.data = data;

		if (filename.charAt(0) == '*') {
			filename = filename.substring(1);
		}

		File file = new File(filename);
		
		if (checkEndOfFile) {
			lastFiveLines = tail(file, 5);
		}
		
		ivLength = (file).length();
		
		ivFileIn = new FileReader(filename);
		ivDataIn = new BufferedReader(ivFileIn);

		lineProcessor.ivFP = this;
		this.checkEndOfFile = checkEndOfFile;
	}

	/**
	 * processFile
	 * 
	 * @return Returns true if at least one line was processed correctly.
	 */
	public boolean processFile() {
		String str;
		int countLines = 0;
		
		if (checkEndOfFile && lastFiveLines != null) {
			
			for (int i = lastFiveLines.length-1; i >= 0; i--) {
				if (!ivLineProcessor.checkLastLines(lastFiveLines[i], data)) {
					return false;
				}
			}
			
			checkEndOfFile = false;
			lastFiveLines = null;
		}
		
		long start = new DateUtility().getSecondsFromMidnight();

		while (true) {
			try {
				str = ivDataIn.readLine();
				if (str != null) {
					ivCurrent += str.length()+2;
					ivLineCounter++;
				}

//				if (ivLineCounter % 5000 == 0) {
//					
//					long percent = ivCurrent*1000/ivLength;
//					long decimal = percent - percent/10*10;
//					percent = percent/10;
//					
//					long current = new DateUtility().getSecondsFromMidnight();
//					long remaining = ((current - start) * ivLength / ivCurrent) - 
//							(current - start);
//					System.out.println(percent+"."+decimal+" "+Utility.longTo24Hour(remaining));
//					
//					ivLineCounter = 0;
//				}
				
			} catch (IOException e) {
				System.out.println(e);
				return countLines != 0;
			}

			if (str == null) {
//				System.out.println("");
				return countLines != 0;
			}

			try {
				if (!ivLineProcessor.processLine(str, data)) {
//					System.out.println("");
					return countLines != 0;
				} else {
					countLines++;
				}
			} catch (Exception e) {
				
				System.out.println("Exception at line "+ivLineCounter+":");
				System.out.println("str: '"+str+"'");
				e.printStackTrace();
				return countLines != 0;
			}
		}
	}

	protected String readLine() {
		String str;

		ivLineCounter++;
		
		try {
			str = ivDataIn.readLine();
		} catch (IOException e) {
			return "";
		}
		if (str == null)
			return "";

		return str;
	}

	public void close() {
		try {
			ivDataIn.close();
			ivFileIn.close();
		} catch (IOException e) {
			System.out.println("ERROR closing:" + e);
		}
	}

	public String[] tail( File file, int lines) {
		return Utility.tailFile(file, lines);
	}
}