
package ca.bell.reporting.io;
public abstract class LineProcessor
{
  public FileProcessor ivFP;

  public abstract boolean processLine(String str);

  
}
