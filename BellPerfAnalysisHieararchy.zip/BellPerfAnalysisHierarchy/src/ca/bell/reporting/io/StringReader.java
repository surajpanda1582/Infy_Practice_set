package ca.bell.reporting.io;

import java.io.*;

public class StringReader
{
  String         ivName;
  BufferedReader ivBuff;
  FileReader     ivFile;

  public StringReader(String name)
    {
    ivName = name;
    }
  public void close() 
    {
    try
      {
      ivBuff.close();
      ivFile.close();
      }
    catch (IOException e) {}
    }
  public int open()
    {
    try
      {
      ivFile = new FileReader(ivName);
      ivBuff = new BufferedReader(ivFile);
      }
    catch (IOException e) {return -1;}
    return 0;
    }
public String readEntireFile() {

	StringBuffer buffer = new StringBuffer();

	buffer.append( readLine() );

	String str = null;
	
	while ( (str = readLine()) != null ) {

		buffer.append( "\r\n" );
		buffer.append( str );
		
	}

	return buffer.toString();
	
}
  public String readLine()
    {
    try
      {
      return ivBuff.readLine();
      }
    catch (IOException e) {return null;}
    }
  
	public static String readLine(String filename) {
		
		StringReader reader = new StringReader(filename);
		if (reader.open() == 0) {
			String ret = reader.readLine();
			reader.close();
			return ret;
		}
		
		return null;
	}
}
