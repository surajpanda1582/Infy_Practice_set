package ca.bell.reporting.io;

import java.io.*;

public class StringWriter {
	String ivFile;
	BufferedWriter ivBuff;
	FileWriter ivWriter;
	PrintWriter ivPrint;

	public StringWriter(File file) {
		ivFile = file.getAbsolutePath();
	}
	
	public StringWriter(String name) {
		ivFile = name;
	}
	
	public PrintWriter getPrintWriter() {
		
		if (ivPrint == null) ivPrint = new PrintWriter(ivBuff);
		
		return ivPrint;
		
	}
	
	public void close() {
		try {
			if (ivPrint != null) ivPrint.close();
			ivBuff.close();
			ivWriter.close();
		} catch (IOException e) {}
	}
	
	public int open() {
		try {
			ivWriter = new FileWriter(ivFile);
			ivBuff = new BufferedWriter(ivWriter);
		} catch (IOException e) {
			System.err.println("Cannot open file:"+ivFile+" - "+e);
			return -1;
		}
		return 0;
	}
	
	public int openAppend() {
		try {
			ivWriter = new FileWriter(ivFile, true);
			ivBuff = new BufferedWriter(ivWriter);
		} catch (IOException e) {
			System.err.println("Cannot open file:"+ivFile+" - "+e);
			return -1;
		}
		return 0;
	}
	
	public void write(String data) {
		try {
			ivBuff.write(data);
			ivBuff.flush();
		} catch (IOException e) {}
	}
	
	public void writeLine(String data) {
		try {
			ivBuff.write(data + "\r\n");
			ivBuff.flush();
		} catch (IOException e) {}
	}
	
	public void flush() {
		try {
			ivBuff.flush();
			ivWriter.flush();
		} catch (IOException e) {}
	}

	public static void fileWrite(String filename, String string) {

		StringWriter writer = new StringWriter(filename);
		if (writer.open() == 0) {
			writer.writeLine(string);
			writer.close();
		}		
	}
}