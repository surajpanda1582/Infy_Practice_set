
package ca.bell.reporting.io;
public abstract class LineProcessorWithData
{
	  public FileProcessorWithData ivFP;
	
	  public abstract boolean processLine(String str, Object data);
	
	  public boolean checkLastLines(String str, Object data) {
			return true;
	  }


}
