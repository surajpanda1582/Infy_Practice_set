import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.StatisticalDoubleVector;


/*
 * Created on Jan 21, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class BellProcessMergePerformanceOmOmf {

	private static final String OMF = "omf:";
	private static final String OM = "om:";
	private static final String DOWNSTREAM = "ds";
	private static final String COMPONENT = "c";
	private static final String COMPONENT_PARALLEL = "pc";
	private static final String ZERO_COMPONENT = "zc";

	public static void main(String[] args) {
		
		if (args.length < 1 || args.length > 2) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         config file");
			System.err.println("         in/out dir (optional)");
			System.exit(-1);
		}

		int p = args[0].lastIndexOf(File.separatorChar);
		String dir = "."+File.separatorChar;
		String dir2 = null;
		if (p > 0) {
			dir2 = args[0].substring(0, p+1);
		}
		String fileName = args[0];

		if (args.length == 2) {

			p = args[1].lastIndexOf(File.separatorChar);
			dir = args[1];
			if (p != args[1].length()-1) {
				dir = args[1] + File.separatorChar;
				System.out.println("Directory: "+ dir);
			}
			
			fileName = args[0];
			dir2 = null;
		}

		ArrayList<BPMPOConfig> configs = parseCfg(fileName);
		
		if (dir2 != null) {
			int count1 = 0;
			int count2 = 0;

			for (Iterator<BPMPOConfig> iterator = configs.iterator(); iterator.hasNext();) {
				BPMPOConfig config = iterator.next();
				
				if (new File(dir + config.omFile).exists()) {
					count1++;
				} else {
					count2++;
				}
	
			}

			if (count2 > count1) {
				dir = dir2;
				dir2 = null;
			} else {
				dir2 = null;
			}
		}	
		
		String date = StringReader.readLine(dir + "date.txt");

		StringWriter writer = new StringWriter(dir + "OM_OMF_Performance_details.tab");
		writer.open();
		writer.writeLine("\t" + date);
		writer.writeLine("Component\t# Calls\tTime(ms)");
		

		for (Iterator<BPMPOConfig> iterator = configs.iterator(); iterator.hasNext();) {
			BPMPOConfig config = iterator.next();
			
			if (dir2 == null) {
				loadConfig(dir, config);
			} else {
				if (new File(dir + config.omFile).exists()) {
					loadConfig(dir, config);
				} else {
					loadConfig(dir2, config);
				}
			}

			printConfig(writer, config);

		}
		
		writer.close();

		writer = new StringWriter(dir + "OM_OMF_Performance.tab");
		writer.open();
		writer.writeLine("\t" + date);
		writer.writeLine("Component\tMeasurement\tTime(ms)");
		

		for (Iterator<BPMPOConfig> iterator = configs.iterator(); iterator.hasNext();) {
			BPMPOConfig config = iterator.next();
			
			printConfigChartData(writer, config);

		}
		
		writer.close();
		
		writer = new StringWriter(dir + "OM_OMF_PerformanceSummary.tab");
		writer.open();
		
		writer.writeLine("\t" + date);
		

		for (Iterator<BPMPOConfig> iterator = configs.iterator(); iterator.hasNext();) {
			BPMPOConfig config = iterator.next();
			
			printConfigServletTime(writer, config);

		}
		
		writer.writeLine("");
		writer.writeLine("\t" + date);
		

		for (Iterator<BPMPOConfig> iterator = configs.iterator(); iterator.hasNext();) {
			BPMPOConfig config = iterator.next();
			
			printConfigServletVolume(writer, config);

		}
		
		writer.close();

	}
	
	public static DecimalFormat formatter = new DecimalFormat("#,###");
	public static DecimalFormat formatter2= new DecimalFormat("#.#");
	
	private static void printConfig(StringWriter writer, BPMPOConfig config) {

		
		//if (! config.valid) {
		//	return;
		//}
		
		int count = 0;
		if (config.countData.get(OM+config.servletName) != null) {
			count = config.countData.get(OM+config.servletName).intValue();
		}
		double perf = 0;
		if (config.perfData.get(OM+config.servletName) != null) {
			perf = config.perfData.get(OM+config.servletName);
		}
		
		writer.writeLine(">>"+config.name + '\t' + formatter.format(count) + '\t' + formatter.format(count == 0 ? 0:perf/count));

		for (Iterator<BPMPOComponent> iterator = config.omComponents.iterator(); iterator.hasNext();) {
			double serviceProportional = 1;
			double serviceProportionalNetwork = 1;

			BPMPOComponent omComp = iterator.next();
			double omTime = 0;
			if (config.perfData.get(OM+omComp.name1) != null) {
				omTime = config.perfData.get(OM+omComp.name1);
			}
			int omCount = 0;
			if (config.countData.get(OM+omComp.name1) != null) {
				omCount = config.countData.get(OM+omComp.name1).intValue();
			}
			omTime  = omCount>0?omTime/omCount:0;
			
			if (omComp.name2 != null) {
				double omServiceTimeTotal = 0;
				double omServiceCountTotal = 0;
				for (int i = 0; i < omComp.name2.length; i++) {
					if (config.name.equals("Select or Confirm Appointment") && omComp.name.equals("Save Quote") && omComp.name1.equals("Action-saveOrderCustomerAppointment")) {
						int dd=0;
					}
					double omServiceTime = 0;
					int omServiceCount = 0;
					if (config.perfData.get(OM+omComp.name2[i]) != null) {
						omServiceCount = config.countData.get(OM+omComp.name2[i]);
						omServiceTime = config.perfData.get(OM+omComp.name2[i])/omServiceCount;
						if (omServiceCount < omCount) {
							serviceProportional = ((double)omServiceCount)/omCount;
						}
						omServiceTimeTotal += omServiceTime*serviceProportional;
						omServiceCountTotal += omServiceCount;
						
					} else {
						int dd=0;
						if (omServiceCount == 0) {
							serviceProportional = 0;
						}
					}
					double serviceTime = 0.0;
					int serviceCount = 0;
					
					if (omCount == 0 && omServiceCount == 0) {
						for (Iterator<BPMPOServiceComponent> iterator2 = config.services.iterator(); iterator2
								.hasNext();) {
							BPMPOServiceComponent service = iterator2.next();
							
							if (omComp.name2[i].equals(service.omName)) {
								if (config.perfData.get(OMF+service.name) != null) {
									serviceTime = config.perfData.get(OMF+service.name);
									serviceCount = config.countData.get(OMF+service.name).intValue();
									serviceTime = serviceTime / serviceCount;
									if (serviceCount < omServiceCount) {
										serviceProportionalNetwork = ((double)serviceCount)/omServiceCount;
									}
									omServiceTimeTotal += omServiceTime;
									omServiceCountTotal += serviceCount;
								}
							}
						}
					} 
					//if (omCount > 0) {
					//	omServiceCountTotal = omCount;
					//}
				}
				
				//if (omServiceCount == 0) {
					
				//}
				if (omCount > 0) {
					omServiceTimeTotal = omTime - omServiceTimeTotal;
				}
				writer.writeLine("  " + omComp.name + '\t' + (count > 0?formatter.format(omServiceCountTotal*100/count):0) + "%/" + formatter.format(serviceProportional*100) + "%\t" + formatter.format(checkNum(omServiceTimeTotal)));
				

				for (int i = 0; i < omComp.name2.length; i++) {
					serviceProportional = 1;
					serviceProportionalNetwork = 1;

					if (i>0 || omComp.name1.equals("Action-saveOrderOrderSummary")) {
						int dd=0;
					}
					double omServiceTime = 0;
					int omServiceCount = 0;
					if (config.perfData.get(OM+omComp.name2[i]) != null) {
						omServiceCount = config.countData.get(OM+omComp.name2[i]);
						omServiceTime = config.perfData.get(OM+omComp.name2[i])/omServiceCount;
						if (omServiceCount < omCount) {
							serviceProportional = ((double)omServiceCount)/omCount;
						}
					} else {
						int dd=0;
						if (omServiceCount == 0) {
							serviceProportional = 0;
						}
					}
					double serviceTime = 0.0;
					int serviceCount = 0;
					double networkTime=0.0;
					
					BPMPOServiceComponent theService = null;
					for (Iterator<BPMPOServiceComponent> iterator2 = config.services.iterator(); iterator2
							.hasNext();) {
						BPMPOServiceComponent service = iterator2.next();
						
						if (omComp.name2[i].equals(service.omName)) {
							theService = service;
							if (config.perfData.get(OMF+service.name) != null) {
								serviceTime = config.perfData.get(OMF+service.name);
								networkTime= config.perfData.get(OMF+service.name+".Network");
								serviceCount = config.countData.get(OMF+service.name).intValue();
								serviceTime = serviceTime / serviceCount;
								networkTime= networkTime/serviceCount;
								if (serviceCount < omServiceCount) {
									serviceProportionalNetwork = ((double)serviceCount)/omServiceCount;
								}
							}
						}
					}
					
					if (theService != null) {
						double downstream = 0.0;
						double compTime = 0.0;
						boolean writeDS = false;
						for (Iterator<BPMPOComponent> iterator2 = theService.omfComponents.iterator(); iterator2.hasNext();) {
							BPMPOComponent comp = iterator2.next();
							
							if (comp.type.equals(ZERO_COMPONENT)) {
								if (config.perfData.get(OMF+comp.name1) == null) {
									writer.writeLine("    " + comp.name + '\t' + 0 + "%\t" + formatter.format(0));
								} else {
									double ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
									writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(config.countData.get(OMF+comp.name1)*100/serviceCount):0) + "%\t" + formatter.format(ct));
								}
							}
							if (comp.type.equals(COMPONENT)) {
								double ct = 0;
								double cnt = 0;
								if (comp.name.indexOf("CPQ") >= 0) {
									int dd = 0;
								}
								if (config.perfData.get(OMF+comp.name1) != null) {
									ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
									cnt = config.countData.get(OMF+comp.name1);
								}
								writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(cnt*100/serviceCount):0) + "%\t" + formatter.format(checkNum(ct)));
								if (serviceCount > 0) {
									compTime += (ct*cnt)/serviceCount;
								}
							}
							if (comp.type.equals(COMPONENT_PARALLEL)) {
								double ct = 0;
								double cnt = 0;
								if (comp.name.indexOf("CPQ") >= 0) {
									int dd = 0;
								}
								if (config.perfData.get(OMF+comp.name1) != null) {
									ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
									cnt = config.countData.get(OMF+comp.name1);
								}
								writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(cnt*100/serviceCount):0) + "%\t" + formatter.format(checkNum(ct)));
								if (serviceCount > 0) {
									compTime += ct;
								}
							}
							if (comp.type.equals(DOWNSTREAM)) {
								writeDS = true;
								if (config.countData.get(OMF+comp.name1) == null) {
									System.err.println("ERROR: " + OMF+comp.name1 + " is not present for " + config.name);
								} else {
									int cnt = config.countData.get(OMF+comp.name1).intValue();
									double avg = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
									downstream += ((double)cnt / serviceCount) * avg;
									
									if (comp.name2 != null && comp.name2[i] != null) {
										cnt = 0;
										avg = 0;
										if (config.countData.get(OMF+comp.name2[i]) != null) {
											cnt = config.countData.get(OMF+comp.name2[i]).intValue();
											avg = config.perfData.get(OMF+comp.name2[i]) / cnt;
											downstream += ((double)cnt / serviceCount) * avg;
										}
									}
								}
							}
						}
						
						double tnum = ((double)serviceCount)*100/omServiceCount;
						if (omServiceCount == 0) {
							tnum = 0;
						}
						writer.writeLine("    OMF\t"+formatter.format(tnum)+"%\t" + formatter.format(checkNum(serviceTime - downstream - compTime)));
	
						if (downstream > 0.0 || writeDS) {
							writer.writeLine("    Downstream\t\t" + formatter.format(checkNum(downstream)));
						}
						
						writer.writeLine("    Network\t\t" + formatter.format(checkNum(((omServiceTime*serviceProportionalNetwork))-serviceTime)));
						
						//Enhancement CR
						writer.writeLine("    New Network\t\t" + formatter.format(checkNum(networkTime)));
						
					} else {
						writer.writeLine("    " + omComp.name2[i] + '\t' + (omCount > 0?formatter.format(omServiceCount*100/omCount):0) + "%\t" + formatter.format(checkNum(omServiceTime)));
					}
				}
			} else {
				writer.writeLine("  " + omComp.name + '\t' + (count>0?formatter.format(omCount*100/count):0) + "%\t" + formatter.format(checkNum(omTime)));
				
			}
		}
		
		for (Iterator<BPMPOServiceComponent> iterator2 = config.services.iterator(); iterator2.hasNext();) {
			BPMPOServiceComponent service = iterator2.next();
		
			if ("none".equals(service.omName)) {
				Double serviceTimeD = config.perfData.get(OMF+service.name);
				if (serviceTimeD != null) {
					double serviceTime = config.perfData.get(OMF+service.name);
					int serviceCount = config.countData.get(OMF+service.name).intValue();
					serviceTime = serviceTime / serviceCount;
					writer.writeLine("  Service: " + service.name + '\t' + (count>0?formatter.format(serviceCount*100/count):0) + "%\t" + formatter.format(checkNum(serviceTime)));
	
					double downstream = 0.0;
					double compTime = 0.0;
					
					for (Iterator<BPMPOComponent> iterator3 = service.omfComponents.iterator(); iterator3.hasNext();) {
						BPMPOComponent comp = iterator3.next();
						
						if (comp.type.equals(ZERO_COMPONENT)) {
							//Comment out for testing
							//double ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
							//writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(config.countData.get(OMF+comp.name1)*100/serviceCount):0) + "%\t" + formatter.format(ct));
						}
						if (comp.type.equals(COMPONENT)) {
							double ct = 0;
							double cnt = 0;
							if (config.perfData.get(OMF+comp.name1) != null) {
								ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
								cnt = config.countData.get(OMF+comp.name1);
							}
							writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(cnt*100/serviceCount):0) + "%\t" + formatter.format(checkNum(ct)));
							compTime += (ct*cnt)/serviceCount;
						}
						if (comp.type.equals(COMPONENT_PARALLEL)) {
							double ct = 0;
							double cnt = 0;
							if (config.perfData.get(OMF+comp.name1) != null) {
								ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
								cnt = config.countData.get(OMF+comp.name1);
							}
							writer.writeLine("    " + comp.name + '\t' + (serviceCount > 0?formatter.format(cnt*100/serviceCount):0) + "%\t" + formatter.format(checkNum(ct)));
							compTime += ct;
						}
						if (comp.type.equals(DOWNSTREAM)) {
							int cnt = config.countData.get(OMF+comp.name1).intValue();
							double avg = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
							downstream += ((double)cnt / serviceCount) * avg;
							
							if (comp.name2 != null) {
								for (int i = 0; i < comp.name2.length; i++) {
									cnt = 0;
									avg = 0;
									if (config.countData.get(OMF+comp.name2[i]) != null) {
										cnt = config.countData.get(OMF+comp.name2[i]).intValue();
										avg = config.perfData.get(OMF+comp.name2[i]) / cnt;
										downstream += ((double)cnt / serviceCount) * avg;
									}
								}
							}
						}
					}
				
					if (compTime > .00001 || downstream > 0.000001)writer.writeLine("    OMF\t\t" + formatter.format(checkNum(serviceTime - downstream - compTime)));
	
					if (downstream > 0.0) {
						writer.writeLine("    Downstream\t\t" + formatter.format(checkNum(downstream)));
					}
				}
			}
		}

		
		writer.writeLine("");
	}

	private static Object checkNum(double d) {

		if (d < 0) {
			int dd = 0;
		}
		
		return d;
	}

	private static void printConfigChartData(StringWriter writer, BPMPOConfig config) {

		int count = 0;
		double serviceProportional = 1;
		double serviceProportionalNetwork = 1;
		if (config.countData.get(OM+config.servletName) != null) {
			count = config.countData.get(OM+config.servletName).intValue();
		}
		double perf = 0;
		if (config.perfData.get(OM+config.servletName) != null) {
			perf = config.perfData.get(OM+config.servletName);
		}
		
		writer.writeLine(config.name + "\tTransaction Volume\t" + formatter.format(count));
		writer.writeLine("\tOverall\t" + formatter.format(perf/count));

		for (Iterator<BPMPOComponent> iterator = config.omComponents.iterator(); iterator.hasNext();) {
			BPMPOComponent omComp = iterator.next();
			double omTime = 0;
			if (config.perfData.get(OM+omComp.name1) != null) {
				omTime = config.perfData.get(OM+omComp.name1);
			}
			int omCount = 0;
			if (config.countData.get(OM+omComp.name1) != null) {
				omCount = config.countData.get(OM+omComp.name1).intValue();
			}
			omTime  = omCount>0?omTime/omCount:0;
			
			if (omComp.name2 != null) {
				double omServiceTime = 0;
				int omServiceCount = 0;
				if (config.perfData.get(OM+omComp.name2) != null) {
					omServiceCount = config.countData.get(OM+omComp.name2);
					omServiceTime = config.perfData.get(OM+omComp.name2)/omServiceCount;
					if (omServiceCount < omCount) {
						serviceProportional = ((double)omServiceCount)/omCount;
					}
				} else {
					int dd = 0;
				}
				double serviceTime = 0.0;
				int serviceCount = 0;
				
				BPMPOServiceComponent theService = null;
				for (Iterator<BPMPOServiceComponent> iterator2 = config.services.iterator(); iterator2
						.hasNext();) {
					BPMPOServiceComponent service = iterator2.next();
					
					if (omComp.name2.equals(service.omName)) {
						theService = service;
						serviceTime = config.perfData.get(OMF+service.name);
						serviceCount = config.countData.get(OMF+service.name).intValue();
						serviceTime = serviceTime / serviceCount;
						if (serviceCount < omServiceCount) {
							serviceProportionalNetwork = ((double)serviceCount)/omServiceCount;
						}
					}
				}
				if (omTime < 0.00001) {
					writer.writeLine("\t" + omComp.name + '\t' + formatter.format(omServiceTime));
				} else {
					writer.writeLine("\t" + omComp.name + '\t' + formatter.format(omTime-(omServiceTime*serviceProportional)));
				}
				if (theService != null) {
					double downstream = 0.0;
					double compTime = 0.0;
					
					for (Iterator<BPMPOComponent> iterator2 = theService.omfComponents.iterator(); iterator2.hasNext();) {
						BPMPOComponent comp = iterator2.next();
						
						if (comp.type.equals(COMPONENT)) {
							double ct = 0;
							double cnt = 0;
							if (config.perfData.get(OMF+comp.name1) != null) {
								ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
								cnt = config.countData.get(OMF+comp.name1);
							}
							writer.writeLine("\t  " + comp.name + '\t' + formatter.format(ct));
							compTime += (ct*cnt)/serviceCount;
						}
						if (comp.type.equals(COMPONENT_PARALLEL)) {
							double ct = 0;
							double cnt = 0;
							if (config.perfData.get(OMF+comp.name1) != null) {
								ct = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
								cnt = config.countData.get(OMF+comp.name1);
							}
							writer.writeLine("\t  " + comp.name + '\t' + formatter.format(ct));
							compTime += ct;
						}
						if (comp.type.equals(DOWNSTREAM)) {
							int cnt = config.countData.get(OMF+comp.name1).intValue();
							double avg = config.perfData.get(OMF+comp.name1) / config.countData.get(OMF+comp.name1);
							downstream += ((double)cnt / serviceCount) * avg;
							
							if (comp.name2 != null) {
								cnt = 0;
								avg = 0;
								if (config.countData.get(OMF+comp.name2) != null) {
									cnt = config.countData.get(OMF+comp.name2).intValue();
									avg = config.perfData.get(OMF+comp.name2) / cnt;
									downstream += ((double)cnt / serviceCount) * avg;
								}
							}
						}
					}
					
					writer.writeLine("\t  OMF\t" + formatter.format(serviceTime - downstream - compTime));

					if (downstream > 0.0) {
						writer.writeLine("\t  Downstream\t" + formatter.format(downstream));
					}
					
					writer.writeLine("\t  Network\t" + formatter.format(((omServiceTime*serviceProportionalNetwork))-serviceTime));
					
				} else {
					writer.writeLine("");
				}

			} else {
				writer.writeLine("\t" + omComp.name + '\t' + formatter.format(omTime));
				
			}
		}
		
		writer.writeLine("");
	}

	private static void printConfigServletTime(StringWriter writer, BPMPOConfig config) {

		int count = 0;
		if (config.countData.get(OM+config.servletName) != null) {
			count = config.countData.get(OM+config.servletName).intValue();
		}
		double perf = 0;
		if (config.perfData.get(OM+config.servletName) != null) {
			perf = config.perfData.get(OM+config.servletName);
		}
		
		writer.writeLine(config.name + '\t' + formatter2.format(perf/count/1000));
	}
	
	private static void printConfigServletVolume(StringWriter writer, BPMPOConfig config) {

		int count = 0;
		if (config.countData.get(OM+config.servletName) != null) {
			count = config.countData.get(OM+config.servletName).intValue();
		}
		
		writer.writeLine(config.name + '\t' + formatter.format(count));
	}
	
	
	private static ArrayList<BPMPOConfig> parseCfg(String fileName) {
		StringReader reader = new StringReader(fileName);
		
		if (reader.open() != 0) {
			System.out.println("Cannot open config file: "+fileName);
			throw new RuntimeException("Cannot open config file: "+fileName);
		}
		
		ArrayList<BPMPOConfig> configs = new ArrayList<BPMPOConfig>();
		
		BPMPOConfig config = null;
		BPMPOServiceComponent service = null;
		String temp;
		
		boolean omMode = true;
		
		String lineStr = reader.readLine();
		
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length()==0 || lineStr.charAt(0) == '#') {
				//nop - comment line or blank line
				
			} else if (lineStr.startsWith(">>>")) {
				temp = lineStr.substring(3, lineStr.length()).trim();
				config = new BPMPOConfig(temp);
				configs.add(config);
				omMode = true;
				
			} else if (lineStr.startsWith(">OMF>")) {
				config.omfFile = lineStr.substring(5, lineStr.length()).trim();
				omMode = false;
				
			} else if (lineStr.startsWith(">OM>")) {
				config.omFile = lineStr.substring(4, lineStr.length()).trim();
				omMode = true;
				
			}else if (lineStr.startsWith(">")) {
				temp = lineStr.substring(1, lineStr.length()).trim();
				
				if (omMode) {
					config.servletName = temp;
				} else {
					String[] items = temp.split("\\|");
					service = new BPMPOServiceComponent(items[0], items[1]);
					config.services.add(service);
				}
				
			} else if (lineStr.startsWith("c>")) {
				temp = lineStr.substring(2, lineStr.length()).trim();
				String[] items = temp.split("\\|");
				if (omMode) {
					BPMPOComponent comp = new BPMPOComponent(items);
					config.omComponents.add(comp);
				} else {
					BPMPOComponent comp = new BPMPOComponent(COMPONENT, items);
					service.omfComponents.add(comp);
				}
				
			} else if (lineStr.startsWith("zc>")) {
				temp = lineStr.substring(3, lineStr.length()).trim();
				String[] items = temp.split("\\|");
				if (omMode) {
					BPMPOComponent comp = new BPMPOComponent(items);
					config.omComponents.add(comp);
				} else {
					BPMPOComponent comp = new BPMPOComponent(ZERO_COMPONENT, items);
					service.omfComponents.add(comp);
				}
				
			} else if (lineStr.startsWith("pc>")) {
				temp = lineStr.substring(3, lineStr.length()).trim();
				String[] items = temp.split("\\|");
				if (omMode) {
					BPMPOComponent comp = new BPMPOComponent(items);
					config.omComponents.add(comp);
				} else {
					BPMPOComponent comp = new BPMPOComponent(COMPONENT_PARALLEL, items);
					service.omfComponents.add(comp);
				}
				
			} else if (lineStr.startsWith("ds>")) {
				temp = lineStr.substring(3, lineStr.length()).trim();
				String[] items = temp.split("\\|");
				if (omMode) {
					throw new IllegalStateException("Cannot add downstream to OM: "+config.name);
				} else {
					BPMPOComponent comp = new BPMPOComponent(DOWNSTREAM, items);
					service.omfComponents.add(comp);
				}
				
			} else {
				throw new IllegalStateException("Unknown line: "+lineStr);
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
		
		return configs;
	}
	
	
	private static void loadConfig(String dir, BPMPOConfig config) {
		
		int rc = parseOmTabFile(config, dir + config.omFile, OM);
		
		if (rc == 0) {
			if (config.omfFile != null) {
				parseOmTabFile(config, dir + config.omfFile, OMF);
			}
		} else {
			config.valid =  false;
		}
		
	}
	
	private static int parseOmTabFile(BPMPOConfig config, String fileName, String type) {

		System.out.println("Reading " + fileName);
		StringReader reader = new StringReader(fileName);
		int count = 0;
		
		if (reader.open() != 0) {
			System.err.println("Cannot open file: "+fileName);
			//throw new RuntimeException("Cannot open file: "+fileName);
			return -1;
		}
		
		String lineStr = reader.readLine();
		String[] header = null;
		if (lineStr != null) {
			header = lineStr.split("\\t");
			lineStr = reader.readLine();  // Skip header
			lineStr = reader.readLine();  // Skip header 2
			
		} else {
			reader.close();
			System.out.println("Empty file: "+fileName);
			return -1;
		}

		int maxCols = 0;
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length() > 0) {
				String[] data = lineStr.split("\\t");
				
				maxCols = Math.max(maxCols, data.length);
				
				parseRecord(config, header, data, type);
				
				count++;
				
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
		System.out.println("Read " + count);
		
		if (maxCols < 3) {
			System.err.println("Empty file: "+fileName);
			return - 1;
		}
		
		return 0;
		
	}

	private static void parseRecord(BPMPOConfig config, String[] header, String[] data, String type) {

		int dd = 0;
		
		for (int i = 0; i < header.length; i++) {
			if (header[i].length() > 0) {
				Double stats = config.perfData.get(type+header[i]);
				Integer count = config.countData.get(type+header[i]);
				
				if (data.length > i && data[i].length() > 0) {
					if (stats == null) {
						config.perfData.put(type+header[i], stats);
						count = new Integer(Integer.parseInt(data[i]));
						config.countData.put(type+header[i], count);
						stats = count * Double.parseDouble(data[i+1]);
						config.perfData.put(type+header[i], stats);
						
					} else {
						int ct = Integer.parseInt(data[i]);
						count = new Integer(count.intValue() + ct);
						config.countData.put(type+header[i], count);
						stats += ct * Double.parseDouble(data[i+1]);
						config.perfData.put(type+header[i], stats);
						
					}
				}
			}
		}
		
	}

}

class BPMPOConfig {
	
	String name;
	boolean valid = true;
	
	String omFile;
	String omfFile;
	
	String servletName;
	
	ArrayList<BPMPOComponent> omComponents = new ArrayList<BPMPOComponent>();
	ArrayList<BPMPOServiceComponent> services = new ArrayList<BPMPOServiceComponent>();
	
	HashMap<String, Double> perfData = new HashMap<String, Double>();
	HashMap<String, Integer> countData = new HashMap<String, Integer>();
	
	public BPMPOConfig(String name) {
		this.name = name;
	}
}

class BPMPOComponent {
	
	String name;
	
	String name1;
	String[] name2;
	String type;
	
	
	public BPMPOComponent(String[] names) {
		this.type = "NA";
		this.name = names[0];
		if (names.length > 1) {
			this.name1 = names[1];
		}
		if (names.length > 2) {
			name2 = new String[names.length-2];
			for (int i = 0; i < names.length-2; i++) {
				this.name2[i] = names[2+i];
			}
		}
	}

	public BPMPOComponent(String name, String name1, String name2) {
		this.type = "NA";
		this.name = name;
		this.name1 = name1;
		this.name2 = new String [] {name2};
	}
	
	public BPMPOComponent(String type, String[] names) {
		this.type = type;
		this.name = names[0];
		if (names.length > 1) {
			this.name1 = names[1];
		}
		if (names.length > 2) {
			name2 = new String[names.length-2];
			for (int i = 0; i < names.length-2; i++) {
				this.name2[i] = names[2+i];
			}
		}
	}
	public BPMPOComponent(String type, String name, String name1, String name2) {
		this.type = type;
		this.name = name;
		this.name1 = name1;
		this.name2 = new String [] {name2};
	}

}

class BPMPOServiceComponent {
	
	String name;
	String omName;
	
	ArrayList<BPMPOComponent> omfComponents = new ArrayList<BPMPOComponent>();
	
	public BPMPOServiceComponent(String name, String omName) {
		this.name = name;
		this.omName = omName;
	}
}

