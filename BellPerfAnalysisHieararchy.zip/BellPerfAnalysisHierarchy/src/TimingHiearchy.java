import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class TimingHiearchy implements Comparable<TimingHiearchy>{

	long startMs;
	long endMs;
	long perfMs;
	String name;
	
	ArrayList<TimingHiearchy> children = new ArrayList<TimingHiearchy>();
	
	private TimingHiearchy(String name, long startMs, long endMs) {
		this.startMs = startMs;
		this.endMs = endMs;
		perfMs = endMs - startMs;
		this.name = name;
		
	}
	
	public static TimingHiearchy createTop(String name, long startMs, long endMs) {
		TimingHiearchy ret = new TimingHiearchy(name, startMs, endMs);
				
		return ret;
	}
	
	
	public boolean addItem(String name, long startMs, long endMs) {
		
		// Add child (if name is the same assume sibling)
		if (!this.name.equals(name)&& withinTime(startMs, endMs)) {
			
			for (Iterator<TimingHiearchy> iterator = children.iterator(); iterator.hasNext();) {
				TimingHiearchy child = iterator.next();
				
				if (child.addItem(name, startMs, endMs)) {
					return true;
				}
			}
			
			TimingHiearchy child = new TimingHiearchy(name, startMs, endMs);
			children.add(child);
			Collections.sort(children); // Sort shortest to fastest
			return true;
			
		} else {
			return false;
		}
	}
	
	protected boolean withinTime(long startMs, long endMs) {
		
		if (this.startMs <= startMs && this.endMs >= endMs) {
			return true;
		}
		
		return false;
	}
	
	protected boolean overlapsTime(long startMs, long endMs) {
		
		if (this.startMs > startMs && this.endMs < startMs ||
			this.startMs > endMs && this.endMs < endMs ||
			startMs > this.startMs && endMs < this.startMs ||
			startMs > this.endMs && endMs < this.endMs) {
			return true;
		}
		
		return false;
	}
	
	public void fixParallel() {
		
	}

	@Override
	// Compare to sort by length shortest first
	public int compareTo(TimingHiearchy o) {

		return (int)(this.perfMs - o.perfMs);
	}

	@Override
	public String toString() {
		return "TimingHiearchy [name=" + name + ", startMs=" + startMs
				+ ", endMs=" + endMs + ", children=" + children + "]";
	}

	public static void main(String[] args) {
		
		TimingHiearchy top = TimingHiearchy.createTop("Servlet", 10, 2000);
		
		top.addItem("P2", 500, 1850);  //1350
		top.addItem("P2", 200, 1500);  //1300
		top.addItem("CP2", 250, 1400);  //1150
		top.addItem("CP2", 600, 1700);  //1100
		top.addItem("P2", 250, 1000);  //750
		top.addItem("CP2", 300, 900);  //600
		top.addItem("P1", 20, 100);    //80
		top.addItem("CP1", 25, 90);    //65
		
		System.out.println(top.toString());
	}

}
