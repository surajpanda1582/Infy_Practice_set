import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import java.util.regex.Matcher;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellOmfTraceLogsProcessor extends LineProcessorWithData {

	private File currentFile;
	private String server;
	private String outDir;

	private String startPath = "";
	Hashtable<Integer, CounterData> perfData = new Hashtable<Integer, CounterData>();
	Hashtable<String, StatisticalDoubleVector> reqSizeData = new Hashtable<String, StatisticalDoubleVector>();
	Hashtable<String, StatisticalDoubleVector> respSizeData = new Hashtable<String, StatisticalDoubleVector>();
	ArrayList<String> servers = new ArrayList<String>();
	ArrayList<String> services = new ArrayList<String>();
	Hashtable<String, Integer[]> hoiData = new Hashtable<String, Integer[]>();
	Hashtable<String, ArrayList<String>> hoiRequests = new Hashtable<String, ArrayList<String>>();
	Hashtable<String, ArrayList<String>> hoiActions = new Hashtable<String, ArrayList<String>>();
	Hashtable<String, ArrayList<String>> hoiServerData = new Hashtable<String, ArrayList<String>>();
	ArrayList<String> eligibilityHoiList = new ArrayList<String>();

	public static Pattern eligibleOfferingListStart = Pattern.compile("<ns[0-9]{1,2}:eligibleOfferingList>");
	public static Pattern eligibleOfferingListEnd = Pattern.compile("</ns[0-9]{1,2}:eligibleOfferingList>");
	public StringWriter writerEligibility;

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	
	private WordString words = new WordString("");
	private int numHoiRequest;
	public StringWriter writerLargeTxn;

	public BellOmfTraceLogsProcessor(String dir, String fileStartsWith) {

		numHoiRequest = 0;
		startPath = dir;
		outDir = dir;
		this.fileStartsWith = fileStartsWith;
		words.setDelimiters(new char[] { ' ', '[', ']' });
		
		System.out.println("Opening: "+outDir + File.separator + "largeTransactions.txt");
		writerLargeTxn = new StringWriter(outDir + File.separator + "largeTransactions.txt");
		writerLargeTxn.open();
		writerLargeTxn.writeLine("Writing long transactions");
		writerLargeTxn.flush();
		
		writerEligibility = new StringWriter(outDir + File.separator + "eligibilityData.tab");
		writerEligibility.open();

	}

	public BellOmfTraceLogsProcessor(String dir, String fileStartsWith, String minMs, String maxMs, String oDir, String numHoi) {

		numHoiRequest = Integer.parseInt(numHoi);
		startPath = dir;
		outDir = oDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { ' ', '[', ']' });
		
		System.out.println("Opening: "+outDir + File.separator + "largeTransactions.txt");
		writerLargeTxn = new StringWriter(outDir + File.separator + "largeTransactions.txt");
		writerLargeTxn.open();
		writerLargeTxn.writeLine("Writing long transactions");
		writerLargeTxn.flush();
		
		writerEligibility = new StringWriter(outDir + File.separator + "eligibilityData.tab");
		writerEligibility.open();

	}

	public void print(OmfParameters data) {
		
		writerLargeTxn.close();
		writerEligibility.close();
		
		Integer interval = new Integer((int)(minMs / data.interval));
		int maxInterval = (int)(maxMs / data.interval);
		
		StringWriter writer;
		
		String lDir = "";
		lDir = outDir + File.separator;
		
		writer = new StringWriter(lDir + "servers.tab");
		writer.open();
		
		writer.write("\t");
		for (int i = 0; i < servers.size(); i++) {
			writer.write(servers.get(i) + "\t");
		}
		writer.writeLine("All");
		writer.write("Interval\t");
		for (int i = 0; i < servers.size(); i++) {
			writer.write("Num\t");
		}
		writer.writeLine("Num");

		while (interval.doubleValue() <= maxInterval) {
			CounterData dataElement = perfData.get(interval);
			writer.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < servers.size(); i++) {
					Counter stats = dataElement.byServer.get(servers.get(i));
					
					if (stats != null) {
						writer.write(stats.counter + "\t");
					} else {
						writer.write("\t");
					}
				}
				
				writer.write(dataElement.allCounter + "\t");
			}
			
			writer.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}

		writer.close();
		writer = new StringWriter(lDir + "services.tab");
		writer.open();
		
		writer.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer.write(services.get(i) + "\t");
		}
		writer.writeLine("All");
		writer.write("Interval\t");
		for (int i = 0; i < services.size(); i++) {
			writer.write("Num\t");
		}
		writer.writeLine("Num\t");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			CounterData dataElement = perfData.get(interval);
			writer.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < services.size(); i++) {
					Counter stats = dataElement.byService.get(services.get(i));
					
					if (stats != null) {
						writer.write(stats.counter + "\t");
					} else {
						writer.write("\t");
					}
				}
				
				writer.write(dataElement.allCounter + "\t");
			}
			
			writer.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}

		writer.close();
		writer = new StringWriter(lDir + "messages.tab");
		writer.open();
		
		Set<String> keys = reqSizeData.keySet();
		ArrayList<String> messageNames = new ArrayList<String>();
		messageNames.addAll(keys);

		keys = reqSizeData.keySet();
		for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			if (!messageNames.contains(key)) {
				messageNames.add(key);
			}
		}
		
		Collections.sort(messageNames);
		
		writer.writeLine("Message\tMin Req\tMin Resp\tAvg Req\tAvg Resp\tMax Req\tMax Resp");

		for (int i = 0; i < messageNames.size(); i++) {
			String message = messageNames.get(i);
			StatisticalDoubleVector req = reqSizeData.get(message);
			StatisticalDoubleVector resp = respSizeData.get(message);
			writer.writeLine(message 
					+ "\t" + (req==null?0:req.getMinimum()) + "\t" + (resp==null?0:resp.getMinimum())
					+ "\t" + (req==null?0:req.getAverage()) + "\t" + (resp==null?0:resp.getAverage())
					+ "\t" + (req==null?0:req.getMaximum()) + "\t" + (resp==null?0:resp.getMaximum())
				);
		}

		writer.close();

	
		writer = new StringWriter(lDir + "PCS.tab");
		writer.open();
		
		writer.writeLine("HOI\t# Requests\tFirst Req\tRequest\tResponse\tSession Data\tServers"); 

		keys = hoiData.keySet();
		int totalHoi = 0;
		int totalCalls = 0;
		int totalFirstReqSize = 0;
		int totalReqSize = 0;
		int totalRespSize = 0;
		int totalActions = 0;

		for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
			
			//#calls, first req size, req size total, resp size total, actions and session data size total
			String key = (String) iterator.next();
			Integer[] data2 = hoiData.get(key);
			ArrayList<String> data3 = hoiServerData.get(key);
			
			totalHoi += 1;
			totalCalls += data2[0];
			totalFirstReqSize += data2[1];
			totalReqSize += data2[2];
			totalRespSize += data2[3];
			totalActions += data2[4];
				
			writer.writeLine(key 
					+ "\t" + data2[0] + "\t" + data2[1]
						+ "\t" + data2[2] + "\t" + data2[3]
					+ "\t" + data2[4] + "\t" + data3);
		}
		
		writer.writeLine("Totals" 
				+ "\t" + (totalCalls) + "\t" + (totalFirstReqSize)
					+ "\t" + (totalReqSize) + "\t" + (totalRespSize)
				+ "\t" + (totalActions));
		
		writer.writeLine("Counts" 
				+ "\t" + (totalHoi) + "\t" + (totalHoi)
					+ "\t" + (totalCalls) + "\t" + (totalCalls)
				+ "\t" + (totalCalls-totalHoi));

		writer.writeLine("Average" 
				+ "\t" + (totalHoi==0?0:totalCalls/totalHoi) + "\t" + (totalHoi==0?0:totalFirstReqSize/totalHoi)
					+ "\t" + (totalCalls==0?0:totalReqSize/totalCalls) + "\t" + (totalCalls==0?0:totalRespSize/totalCalls)
				+ "\t" + (totalCalls-totalHoi==0?0:totalActions/(totalCalls-totalHoi)));

		writer.close();
		
		writer = new StringWriter(lDir + "hoiData.log");
		writer.open();
		
		ArrayList<String> hois = new ArrayList<String>();
		hois.addAll(hoiRequests.keySet());
		Collections.sort(hois);
		
		for (Iterator<String> iterator = hois.iterator(); iterator.hasNext();) {
			String hoi = iterator.next();
			
			ArrayList<String> requests = hoiRequests.get(hoi);
			ArrayList<String> actions = hoiActions.get(hoi);
			
			if (requests != null) {
				if (actions != null) {
					requests.addAll(actions);
				}
				Collections.sort(requests);
				
				for (Iterator<String> iterator2 = requests.iterator(); iterator2.hasNext();) {
					String request = iterator2.next();
					writer.writeLine(hoi + " " + request);
				}
			}
		}
		
		writer.write("\t");
		writer.close();
	}

	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50) {
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			
			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);
			
			if (timeMs > (maxMs+parms.interval)) {
				return false;  //End if past test time
			}
			
			if (timeMs >= minMs && timeMs <= (maxMs+parms.interval) && date.equals(parms.date)) {
				
				str = words.getString().toString().replaceAll("\\[ +", "[");
				words.setStringNoClean(str);
				String hoi = words.getWord(10);
				String txn = words.getWord(6);
				String channel = words.getWord(8);
				boolean req = false;
				boolean resp = false;
				if (str.indexOf(":requestHeader>") > 0 || str.indexOf("<requestHeader>") > 0) {
					req = true;
				}
				if (str.indexOf(":responseHeader>") > 0 || str.indexOf("<responseHeader>") > 0) {
					resp = true;
				}
				
				if (req || resp || str.indexOf("actionList>") > 0) {
					
					if (txn.length() == 0) {
						txn = words.getWord(16);
//						if (txn.length() == 0) {
//							System.out.println(str);
//							for (int i = 0; i < words.getWordCount() && i < 25; i++) {
//								System.out.println(i + " -> " + words.getWord(i));
//							}
//						}
					}
					
					txn = txn.replaceFirst("OMF\\.", "");

					if (txn.equals("ProductConfigurationService.productConfigurationRequest") && hoi.length() > 0 && channel.equals("Ordermax")) {
						processHOI(timeMs, server, hoi, str, words);
						
					    if (str.indexOf("eligibleOfferingList") > 0 && !eligibilityHoiList.contains(hoi)) {
					    	eligibilityHoiList.add(hoi);
						    Matcher matcher = eligibleOfferingListStart.matcher(str);
						    if (matcher.find()) {
						    	int p1 = matcher.start(); 
							    matcher = eligibleOfferingListEnd.matcher(str);
							    if (matcher.find()) {
							    	int p2 = matcher.start(); 
							    	String strA = str.substring(p1, p2);
							    	
							    	String str2 = strA.replaceAll("CanKeep", "");
							    	int count = (strA.length()-str2.length())/6;
							    	String str3 = strA.replaceAll("CanOrder", "");
							    	int count2 = (strA.length()-str3.length())/8;
							    	writerEligibility.writeLine(hoi + "\t" + count + "\t" + count2 + "\t" + Math.round(count2*100.0/(count+count2)));
							    }
						    }
					    }

					}

					if (req) {
						if (!services.contains(txn)) {
							services.add(txn);
						}
						
						if (!servers.contains(server)) {
							servers.add(server);
						}
		
	//					System.out.println(str);
	//					for (int i = 0; i < words.getWordCount() && i < 25; i++) {
	//						System.out.println(i + " -> " + words.getWord(i));
	//					}
		
						Integer interval = new Integer((int)(timeMs/parms.interval));
						
						CounterData dataElement = perfData.get(interval);
						if (dataElement == null) {
							dataElement = new CounterData(interval);
							perfData.put(interval, dataElement);
						}
						dataElement.addStats(server, txn);
					}
					
					int msgSize = 0;
					String msg = words.getWordAndOn(20);
					msgSize = msg.length();
					
					if (req) {
						
						StatisticalDoubleVector size = reqSizeData.get(txn);
						if (size == null) {
							size = new StatisticalDoubleVector(1000, 1000);
							reqSizeData.put(txn, size);
						}
						size.add(msgSize);
					}
					if (resp) {
						StatisticalDoubleVector size = respSizeData.get(txn);
						if (size == null) {
							size = new StatisticalDoubleVector(1000, 1000);
							respSizeData.put(txn, size);
						}
						size.add(msgSize);
					}
				} 
				
				if (str.length() > 5000000) {
					writerLargeTxn.writeLine(server + "\t" + str);
					writerLargeTxn.flush();
				}
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				//long modTime = child.lastModified();
				//files.add(String.valueOf(modTime) + "-" + child.getName());
				
				int p = child.getName().lastIndexOf('.');
				
				String txt = child.getName().substring(p+1);
				
				int num = 0;
				if (! txt.equals("log")) {
					num = Integer.parseInt(txt);
				}
				files.add(String.valueOf(999-num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);
					System.out.println("numHoiRequests: " + numHoiRequests + "  -  " + sizeHoiRequests);
					System.out.println("numHoiActions: " + numHoiActions + "  -  " + sizeHoiActions);
					System.out.println("hoiData: " + hoiData.size());
					
				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;
	static BellOmfTraceLogsProcessor line = null;

	public static void main(String[] args) {

		if (args.length != 8) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.err.println("         number of HOI order details");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellOmfTraceLogsProcessor(args[0], args[3], args[4], args[5], args[6], args[7]);
		} else {
			line = new BellOmfTraceLogsProcessor(args[0], args[3]);
		}
		


		OmfParameters parms = new OmfParameters(args[1], Integer.parseInt(args[2]));
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		String str = currentFile.getName();
		
		int pos = str.indexOf("_OM");
		if (pos > 0) {
			server = str.substring(pos+4, pos+13);
		} else {
			pos = str.indexOf("_");
			int pos2 = str.indexOf(".");
			server = str.substring(pos+1, pos2);
		}
		

	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}
	
	
	private static Pattern sessionDataStart = Pattern.compile("<[ns]{0,2}[0-9]{0,2}:{0,1}sessionData>");
	private static Pattern sessionDataEnd = Pattern.compile("</[ns]{0,2}[0-9]{0,2}:{0,1}sessionData>");
	private static Pattern actionListStart = Pattern.compile("<[ns]{0,2}[0-9]{0,2}:{0,1}actionList>");
	private static Pattern actionListEnd = Pattern.compile("</[ns]{0,2}[0-9]{0,2}:{0,1}actionList>");
	
	private static int numHoiRequests, numHoiActions;
	private static long sizeHoiRequests, sizeHoiActions;
	
	private void processHOI(Long timeMs, String currentServer, String hoi, String str, WordString words) {
		
		int posSdS = findPatternIndex(str, sessionDataStart);
		int posSdE = findPatternIndex(str, sessionDataEnd);
		int posAlS = findPatternIndex(str, actionListStart);
		int posAlE = findPatternIndex(str, actionListEnd);
		int posData = str.lastIndexOf("[ProductConfigurationService]") + 30;
		
		ArrayList<String> requests = hoiRequests.get(hoi);
		ArrayList<String> actions = hoiActions.get(hoi);
		
		Integer[] data = hoiData.get(hoi);
		
		if (data == null) {
			//#calls, first req size, req size total, resp size total, actions and session data size total
			data = new Integer[]{new Integer(0), new Integer(0), new Integer(0), new Integer(0), new Integer(0)};  
			
			if (posSdS > 0 || posAlS > 0) {
				
				//System.out.println(hoi + " - First PCS with session Data ignored");
				
				if (posAlS > 0 && posAlE > 0) { //Not first call
					if (hoiRequests.size() < numHoiRequest || hoiRequests.get(hoi) != null) {
						if (actions == null) {
							actions = new ArrayList<String>();
							hoiActions.put(hoi, actions);
						}
						String req = Utility.longTo24HourMilli(timeMs) + " " + str.substring(posAlS);
						actions.add(req);
						numHoiActions++;
						sizeHoiActions += req.length();
					}
				}
				
				return;
				
			} else {
				hoiData.put(hoi, data);

			}
		}
		
		
		if (str.indexOf("productConfigurationRequest") > 0) {
			data[0] += 1;
			
			if (posSdS > 0 || posAlS > 0) { //Not first call
				data[2] += str.length()-posData;
				data[4] += (posSdE-posSdS+18) + (posAlE-posAlS+17) + 250;
				
			} else {
				data[1] = str.length()-posData;
				data[2] = str.length()-posData;
			}
			
			if (hoiRequests.size() < numHoiRequest) {
				if (requests == null) {
					requests = new ArrayList<String>();
					hoiRequests.put(hoi, requests);
				}
				String req = Utility.longTo24HourMilli(timeMs) + " " + str.substring(posData);
				requests.add(req);
				numHoiRequests++;
				sizeHoiRequests += req.length();
			}			
		} else if (posAlS > 0 && posAlE > 0) { //Not first call
			data[2] += str.length()-posData;
			data[4] += (posSdE-posSdS+18) + (posAlE-posAlS+17) + 250;

			if (hoiRequests.size() < numHoiRequest || hoiRequests.get(hoi) != null) {
				if (actions == null) {
					actions = new ArrayList<String>();
					hoiActions.put(hoi, actions);
				}
				String req = Utility.longTo24HourMilli(timeMs) + " " + str.substring(posAlS);
				actions.add(req);
				numHoiActions++;
				sizeHoiActions += req.length();
			}
			
		} else if (str.indexOf("productConfigurationResponse") > 0) {
			data[3] += str.length()-posData;
			
		}
		
		ArrayList<String> serverData = hoiServerData.get(hoi);
		
		if (serverData == null) {
			serverData = new ArrayList<String>();  
			hoiServerData.put(hoi, serverData);
		}
		if (! serverData.contains(currentServer)) {
			serverData.add(currentServer);
		}
	}

	private int findPatternIndex(String str, Pattern pattern) {
	    Matcher matcher = pattern.matcher(str);
	    if (matcher.find()) {
	        return matcher.start();
	    }	
	    
	    return -1;
	}


}
class Counter {
	@Override
	public String toString() {
		return "Counter [counter=" + counter + "]";
	}

	int counter;
}

class CounterData {
	
	Integer interval;
	int allCounter;
	Hashtable<String, Counter> byServer = new Hashtable<String, Counter>(); 
	Hashtable<String, Counter> byService = new Hashtable<String, Counter>(); 
	
	CounterData(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(String server, String service) {

		Counter data = byServer.get(server);
		if (data == null) {
			data = new Counter();
			byServer.put(server, data);
		}
		
		data.counter++;
		
		data = byService.get(service);
		if (data == null) {
			data = new Counter();
			byService.put(service, data);
		}
		data.counter++;

		allCounter++;
	}	
}
