import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;

import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;


public class TimingHierarchy implements Comparable<TimingHierarchy>{

	public static HashMap<String, ArrayListNoDuplicates<String>> parallelCallNames = new HashMap<String, ArrayListNoDuplicates<String>>();

	long startMs;
	long endMs;
	long perfMs;
	String server;
	String name;
	int parallelCount;
	boolean zeroPerformance;
	
	ArrayList<TimingHierarchy> children = new ArrayList<TimingHierarchy>();
	
	private TimingHierarchy(String server, String name, long startMs, long endMs) {
		this.startMs = startMs;
		this.endMs = endMs;
		perfMs = endMs - startMs;
		this.name = name;
		this.server = server;
		
	}
	
	public static TimingHierarchy createTop(String server, String name, long startMs, long endMs) {
		TimingHierarchy ret = new TimingHierarchy(server, name, startMs, endMs);
				
		return ret;
	}
	
	public boolean addItem(String server, String name, long startMs, long endMs) {
		return addItem(server, name, startMs, endMs, 0);
	}
	
	private boolean addItem(String server, String name, long startMs, long endMs, int parallelCount) {
		
		if (!this.name.equals(name) && withinTime(startMs, endMs) && !forcedParallel(this.name, name)) {
			
			for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
				TimingHierarchy child = iterator.next();
				
				if (child.addItem(server, name, startMs, endMs, parallelCount)) {
					return true;
				}
			}
		
			for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
				TimingHierarchy child = iterator.next();
				
				if (child.overlapsTime(startMs, endMs)) {
					
					if (child.startMs >= startMs) {
						child.startMs = startMs;
					} 
					
					if (child.endMs <= endMs) {
						child.endMs = endMs;
					}

					if (name.equals(child.name)) {
						child.name = child.name;
					} else if (name.compareTo(child.name) <= 0) {
						child.name = name + ";" + child.name;
					} else {
						child.name = child.name + ";" + name;
					}
					
					child.parallelCount++;

					child.perfMs = child.endMs - child.startMs;
					
					return true;
				}
			}

			TimingHierarchy child = new TimingHierarchy(server, name, startMs, endMs);
			child.parallelCount = parallelCount;
			children.add(child);
			
			TimingHierarchy.setComparator(0);// Sort shortest to longest
			Collections.sort(children); 
			return true;
			
		} else {
			return false;
		}
	}
	
	private boolean forcedParallel(String name1, String name2) {

		ArrayList<String> pnames = parallelCallNames.get(name1);

		if (pnames == null) {
			return false;
		}
		
		if (pnames.contains(name2)) {
			return true;
		}
		
		return false;
	}

	public TimingHierarchyInfo findParent(long startMs, long endMs) {
		return findParent(startMs, endMs, null);

	}
	
	public TimingHierarchyInfo findParent(long startMs, long endMs, TimingHierarchy timeHierarchyToAdd) {
		
		if (withinTime(startMs, endMs)) {
			
			for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
				TimingHierarchy child = iterator.next();
				
				TimingHierarchyInfo data = child.findParent(startMs, endMs, timeHierarchyToAdd);
				if (data != null) {
					if (parallelCount > 0 && name.indexOf(';') < 0) {
						data.name = (parallelCount+1) + "x" + name +  "|" + data.name;
					} else {
						data.name = name + "|" + data.name;
					}
					
					return data;
				}
			}
		
			TimingHierarchyInfo data = new TimingHierarchyInfo(this.server, name, this.startMs, this.endMs, this.perfMs);
			
			if (timeHierarchyToAdd != null) {
				children.add(timeHierarchyToAdd);
				this.zeroPerformance = true;
			}
			
			if (parallelCount > 0 && name.indexOf(';') < 0) {
				data.name = (parallelCount+1) + "x" + name;
			} else {
				data.name = name;
			}
			
			return data;
			
		} else {
			return null;
		}
	}

	/**
	 *  See if child within THIS parent time
	 *  
	 * @param cStartMs - child
	 * @param cEndMs   - child
	 * 
	 * @return true if within (5 ms variance allowed)
	 */
	public boolean withinTime(long startMs, long endMs) {
		
		return withinTime(this.startMs, this.endMs, startMs, endMs);
	}
	
	/**
	 *  See if child within parent time
	 *  
	 * @param pStartMs - parent
	 * @param pEndMs   - parent
	 * @param cStartMs - child
	 * @param cEndMs   - child
	 * 
	 * @return true if within (5 ms variance allowed)
	 */
	public static boolean withinTime(long pStartMs, long pEndMs, long cStartMs, long cEndMs) {
		
		if (pStartMs <= (cStartMs+5) && pEndMs >= (cEndMs-5)) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * Does this time overlap (must be > 10% overlap - with min 2ms and max 20ms)
	 * 
	 * @param cStartMs - child
	 * @param cEndMs   - child
	 * 
	 * @return true if overlapping
	 */
	public boolean overlapsTime(long startMs, long endMs) {
		
		return overlapsTime(this.startMs, this.endMs, startMs, endMs);
	}
	
	/**
	 * Does child time overlap parent (must be > 10% overlap - with min 2ms and max 20ms)
	 * 
	 * @param pStartMs - parent
	 * @param pEndMs   - parent
	 * @param cStartMs - child
	 * @param cEndMs   - child
	 * 
	 * @return true if overlapping
	 */
	public static boolean overlapsTime(long pStartMs, long pEndMs, long cStartMs, long cEndMs) {
		
		long minOverlap = (pEndMs - pStartMs + 5) / 10;
		if (minOverlap < 2) minOverlap = 2;
		if (minOverlap > 20) minOverlap = 20;
		
		long start = pStartMs;
		if (pStartMs < cStartMs) start = cStartMs; 
		
		long end = pEndMs;
		if (cEndMs < pEndMs) end = cEndMs; 
		
		return end-start > minOverlap;
	}
	
	public void fixParallel() {
		
	}

	private static int compareOperator = 0;
	/**
	 * Set compare type for the class
	 * @param compareOperator:
	 * 		0 - Shortest First (default)
	 * 		1 - Longest First
	 * 		else Start time
	 */
	public static void setComparator(int compareOperator) {
		TimingHierarchy.compareOperator = compareOperator;
	}
	
	@Override
	// Compare to sort by length shortest first
	public int compareTo(TimingHierarchy o) {

		switch (compareOperator) {
			case 0:  // Shortest first
				return (int)(this.perfMs - o.perfMs);
	
			case 1:  // Longest first
				return (int)(o.perfMs - this.perfMs);
	
			default:
				return (int)(this.startMs - o.startMs);
		}
		
	}
	
	public void sortChildren() {
		
		Collections.sort(children);
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.sortChildren();
			
		}
		
	}

	@Override
	public String toString() {
		return "[name=" + name + ", time=" + startMs
				+ "-" + endMs + "("+(perfMs)+"), children=" + children + "]";
	}

	/**
	 * Parses string created by toColumn with bTime true
	 * 
	 * @param nameSeparator as used in to call toColumn
	 * @param scenarioData from toColumn
	 * 
	 * @return
	 */
	public static TimingHierarchy parseText(String nameSeparator, String scenarioData) {
		
		//Servlet-initiateOrderSubmitChange~36068917~36083467~14550:Action-initiateOrderSubmitChange~36068917~36077601~8684,Action-availableServicesSubmit~36077603~36080132~2529,
		//Action-availableServicesSubmit|Service-productavailability.ProductAvailabilityRequest~36077603~36080115~2512,Action-availableServicesSubmit|Service-productavailability.ProductAvailabilityRequest|Service-cbam.CBAMAsynServiceRequest~36077603~36078904~1301,
		//Action-configureProductsRoute~36080133~36083175~3042,Action-configureProductsRoute|Service-productconfiguration.json.JSONProductConfigurationServiceRequest~36080137~36082985~2848,JSP-initiateOrderSubmitChange~36083176~36083466~290

		int topP = scenarioData.indexOf(':');
		
		String parent = scenarioData.substring(0, topP);
		
		scenarioData = scenarioData.substring(topP+1);
		
		String[] pdata = parent.split("~");
		TimingHierarchy ret = new TimingHierarchy(null, pdata[0], Long.parseLong(pdata[1]), Long.parseLong(pdata[2]));

		if (scenarioData.length()==0) {// No children
			return ret;
		}
		
		String[] children = scenarioData.split(",");
		for (int i = 0; i < children.length; i++) {
			String[] cdata = children[i].split("~");
			int p = cdata[0].lastIndexOf('|');
			if (p > 0) cdata[0] = cdata[0].substring(p+1);
			int parallelCount = 0;
			if (cdata.length > 4) {
				p = cdata[0].lastIndexOf('x');
				parallelCount = Integer.parseInt(cdata[4])-1;
				String pc = "" + parallelCount;
				
				if (p > 0 && p == pc.length()) cdata[0] = cdata[0].substring(p+1);
				
			}
			
			ret.addItem(null, cdata[0], Long.parseLong(cdata[1]), Long.parseLong(cdata[2]), parallelCount);
		}
		
		return ret;
	}

	private void toColumnChild(StringBuilder ret, String parentNamePlusNameSeparator, String nameSeparator, boolean bTime) {
		
		String searchName = parentNamePlusNameSeparator+name;
		if (parallelCount > 0 && name.indexOf(';') < 0) {
			searchName = parentNamePlusNameSeparator+(parallelCount+1) + 'x' + name;
		}
		
		ret.append(searchName + (bTime?"~" + startMs + "~" + endMs + "~" + (endMs-startMs) + (parallelCount>0?"~"+(parallelCount+1):""):""));
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			ret.append(',');
			child.toColumnChild(ret, parentNamePlusNameSeparator+name+nameSeparator, nameSeparator, bTime);
		}
		
	}

	public String toColumn(String nameSeparator, boolean bTime) {
		StringBuilder ret =  new StringBuilder();

		ret.append(name + (bTime?"~" + startMs + "~" + endMs + "~" + (endMs-startMs) + (parallelCount>0?"~"+(parallelCount+1):""):""));
		ret.append(':');
		
		boolean first = true;
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			if (first) first = false;
			else ret.append(',');
			
			child.toColumnChild(ret, name+nameSeparator, nameSeparator, bTime);
		}
		
		return ret.toString();
	}

	private void toPrint(StringBuilder ret, int depth) {
		
		for(int i = 0; i < depth; i++) {
			ret.append("   ");
		}
		
		ret.append((parallelCount>0?(parallelCount+1)+"x":"")+name + "~" + Utility.longTo24HourMilli(startMs) + "~" + Utility.longTo24HourMilli(endMs) + "~" + (endMs-startMs) + "~" + perfMs);
		ret.append("\r\n");
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.toPrint(ret, depth+1);
		}
		
	}

	public String toPrint() {
		
		setComparator(2);
		sortChildren();
		StringBuilder ret =  new StringBuilder();
		toPrint(ret, 0);
		
		return ret.toString();
	}


	public void addStats(Hashtable<String, StatisticalDoubleVector> byCall, int statsSize) {
	
		StatisticalDoubleVector data = byCall.get(name);
		if (data == null) {
			data = new StatisticalDoubleVector(statsSize, statsSize);
			byCall.put(name, data);
		}
		
		long sumChildren = 0;
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			sumChildren += child.perfMs;
		}
		data.add(endMs-startMs-sumChildren);
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.addStatsChild(name+"|", byCall, statsSize);
		}
	}
	
	public void addStatsChild(String parentNamePlusNameSeparator, Hashtable<String, StatisticalDoubleVector> byCall, int statsSize) {
		
		long sumChildren = 0;
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			sumChildren += child.perfMs;
		}

		String searchName = parentNamePlusNameSeparator+name;
		if (parallelCount > 0 && name.indexOf(';') < 0) {
			searchName = parentNamePlusNameSeparator+(parallelCount+1) + 'x' + name;
		}
		
		StatisticalDoubleVector data = byCall.get(searchName);
		if (data == null) {
			data = new StatisticalDoubleVector(statsSize, statsSize);
			byCall.put(searchName, data);
		}
		data.add(endMs-startMs-sumChildren);
		
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.addStatsChild(parentNamePlusNameSeparator+name+"|", byCall, statsSize);
		}
		
	}

	public void addStats(OmfScenarioDataElementOrdered byCall, String scenarioName, ArrayList<String> allServices) {
		
		long sumChildren = 0;
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			sumChildren += child.perfMs;
		}
		byCall.addStats(server, name, perfMs-sumChildren, scenarioName);
		if (!allServices.contains(name)) {
			allServices.add(name);
		}

		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.addStatsChild(name+"|", byCall, scenarioName, allServices);
		}
	}
	
	private void addStatsChild(String parentNamePlusNameSeparator, OmfScenarioDataElementOrdered byCall, String scenarioName, ArrayList<String> allServices) {
		
		long sumChildren = 0;
		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			sumChildren += child.perfMs;
		}

		String searchName = parentNamePlusNameSeparator+name;
		if (parallelCount > 0 && name.indexOf(';') < 0) {
			searchName = parentNamePlusNameSeparator+(parallelCount+1) + 'x' + name;
		}
		
		byCall.addStats(server, searchName, perfMs-sumChildren, scenarioName);
		if (!allServices.contains(searchName)) {
			allServices.add(searchName);
		}

		for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
			TimingHierarchy child = iterator.next();
			child.addStatsChild(parentNamePlusNameSeparator+name+"|", byCall, scenarioName, allServices);
		}
		
	}

	public static void main(String[] args) {
		
		TimingHierarchy top = TimingHierarchy.createTop(null, "Servlet", 10, 2000);
		
		top.addItem(null, "P2", 500, 1850);  //1350
		top.addItem(null, "P2", 200, 1500);  //1300
		top.addItem(null, "CP2", 250, 1400);  //1150
		top.addItem(null, "CP2", 600, 1700);  //1100
		top.addItem(null, "P2", 250, 1000);  //750
		top.addItem(null, "CP2", 300, 900);  //600
		top.addItem(null, "P1", 20, 100);    //80
		top.addItem(null, "P3", 80, 150);    //70
		top.addItem(null, "CP1", 25, 90);    //65
		
		System.out.println("FindParent: " + top.findParent(610, 1000));
		
		TimingHierarchy.setComparator(2);
		top.sortChildren();
		System.out.println(top.toString());
		
		String data = top.toColumn("|", true);
		System.out.println(data);
		
		TimingHierarchy top2 = TimingHierarchy.parseText("|", data);
		System.out.println(top2.toString());
		String data2 = top2.toColumn("|", true);
		System.out.println(data2);
		
		if (top2.toString().equals(top.toString())) {
			System.out.println("toString OK");
		} else {
			System.err.println("ERROR with toString");
		}
		if (data.equals(data2)) {
			System.out.println("toColumn OK");
		} else {
			System.err.println("ERROR with toColumn");
		}
	}

	public void addOmItemStats(String scenarioName, HashSet<String> allOmHierarchyChildren, OmfScenarioDataElementOrdered dataElement, ArrayList<String> allServices, String hoi, StringWriter writerTransaction) {
		
		//Use builder for less object creation
		StringBuilder searchName = new StringBuilder(scenarioName);
		searchName.append('~');
		StringBuilder parent = new StringBuilder("OM:");
		addOmItemStats(parent, searchName, scenarioName, allOmHierarchyChildren, dataElement, allServices, hoi, writerTransaction);
	}

	private void addOmItemStats(StringBuilder parent, StringBuilder searchName, String scenarioName, HashSet<String> allOmHierarchyChildren, OmfScenarioDataElementOrdered dataElement, ArrayList<String> allServices, String hoi, StringWriter writerTransaction) {

		int l = parent.length();
		int l2 = searchName.length();
		
		if (parallelCount > 0 && name.indexOf(';') < 0) {
			parent.append((parallelCount+1));
			parent.append('x');
			parent.append(name);
			searchName.append((parallelCount+1));
			searchName.append('x');
			searchName.append(name);
		} else {
			parent.append(name);
			searchName.append(name);
		}
		
		if (allOmHierarchyChildren.contains(searchName.toString())) {
			String name = parent.toString();
			allServices.add(name);

			if (writerTransaction != null) {
				writerTransaction.writeLine(hoi + " " + searchName);
				writerTransaction.write(toPrint());
				writerTransaction.writeLine("________________________________________________________\r\n");
			}
			
			long sumChildren = 0;
			for (Iterator<TimingHierarchy> iterator = children.iterator(); iterator.hasNext();) {
				TimingHierarchy child = iterator.next();
				sumChildren += child.perfMs;
			}

			if (zeroPerformance) {
				String txn = "Network+OM("+name.substring(3)+")";

				if (perfMs < sumChildren) {
//					System.out.println("Negative: " + hoi + ": " + toPrint());
					sumChildren = calculatePerfConsideringParallel();
//					System.out.println("    Fixed sum: " + sumChildren);
				}
				
				dataElement.addStats(server, txn, perfMs-sumChildren, scenarioName);
				if (!allServices.contains(txn)) {
					allServices.add(txn);
				}

				dataElement.addStats(server, name, 0, scenarioName);
				
			} else {
				dataElement.addStats(server, name, perfMs-sumChildren, scenarioName);
			}
		} else {
			int dd = 0;
		}
		
		
		for (TimingHierarchy child : children) {
			int l3 = parent.length();
			int l4 = searchName.length();
			parent.append('|');
			searchName.append('|');
			
			child.addOmItemStats(parent, searchName, scenarioName, allOmHierarchyChildren, dataElement, allServices, hoi, writerTransaction);
			
			//Reset builder
			parent.setLength(l3);
			searchName.setLength(l4);
			
		}
		
		//Reset builder
		parent.setLength(l);
		searchName.setLength(l2);
		
	}

	private long calculatePerfConsideringParallel() {

		long sumChildren = 0;
		ArrayList<TimingHierarchy> finalChildren = new ArrayList<TimingHierarchy>();
		
		setComparator(1);
		sortChildren();
		
		TimingHierarchy child = children.get(0);
		finalChildren.add((TimingHierarchy) new TimingHierarchy(child.server, child.name, child.startMs, child.endMs));
		
		for (int i = 1; i < children.size(); i++) {
			child = children.get(i);
			
			for (int j = 1; j < finalChildren.size(); j++) {
				TimingHierarchy child2 = finalChildren.get(j);
				
				if (child.overlapsTime(child2.startMs, child2.endMs)) {
					child.startMs = Math.min(child.startMs, child2.startMs);
					child.endMs = Math.max(child.endMs, child2.endMs);
					child.perfMs = child.endMs - child.startMs;
					
				} else {
					finalChildren.add((TimingHierarchy) new TimingHierarchy(child.server, child.name, child.startMs, child.endMs));
					
				}

			}

		}
		
		for (Iterator<TimingHierarchy> iterator = finalChildren.iterator(); iterator.hasNext();) {
			child = iterator.next();
			sumChildren += child.perfMs;
		}

		return sumChildren;
	}

}

class TimingHierarchyInfo {

	long startMs;
	long endMs;
	long perfMs;
	String server;
	String name;
	
	public TimingHierarchyInfo(String server2, String name2, long startMs2, long endMs2, long perfMs2) {
		
		server = server2;
		name = name2;
		startMs = startMs2;
		endMs = endMs2;
		perfMs = perfMs2;
	}

	@Override
	public String toString() {
		return "[name=" + name + ", time=" + Utility.longTo24HourMilli(startMs)
				+ "-" + Utility.longTo24HourMilli(endMs) + "(" + perfMs + ")" + ", server=" + server + "]";
	}
}
