import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;

class BellOmfPerformanceLogsHoiProcessor extends LineProcessorWithData {

	static private Pattern NUM_DASH_PATTERN = Pattern.compile("[0-9]-- ");
	public static int STATS_SIZE = 100;

	private File currentFile;

	private String startPath = "";
	Hashtable<String, HoiPerfData> perfData = new Hashtable<String, HoiPerfData>();
	private ArrayListNoDuplicates<String> services = new ArrayListNoDuplicates<String>();

	private static ArrayList<String> detailService = new ArrayList<String>();
	private static ArrayList<String> detailSubServiceName = new ArrayList<String>();
	private static ArrayList<Pattern> detailSubServiceExp = new ArrayList<Pattern>();

	String fileStartsWith = "*";
	String dir;
	String outDir;

	private WordString words = new WordString("");

	static Pattern yifPattern = Pattern.compile("\\[YIFWebService\\]");
	static Pattern datePattern = Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}");
	static Pattern hoiPattern = Pattern
			.compile("[A-Z][0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]");

	static FileProcessorWithData fp = null;
	static BellOmfPerformanceLogsHoiProcessor line = null;

	public static boolean LOG_DATA = false;

	public BellOmfPerformanceLogsHoiProcessor(String dir, String outDir,
			String fileStartsWith) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;

		words.setDelimiters(new char[] { ' ', '[', ']' });

	}

	public void print(OmfParameters data) {

		Collections.sort(services);

		StringWriter writer2 = new StringWriter(outDir + File.separator
				+ "services-performance.tab");
		writer2.open();

		writer2.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write(services.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("");
		writer2.write("HOI\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("");

		Set hois = perfData.keySet();
		ArrayList<String> hoiList = new ArrayList<String>();
		hoiList.addAll(hois);

		Collections.sort(hoiList);

		for (int j = 0; j < hoiList.size(); j++) {
			String hoi = hoiList.get(j);
			writer2.write(hoi + "\t");
			HoiPerfData hdata = perfData.get(hoi);

			for (int i = 0; i < services.size(); i++) {
				String service = services.get(i);
				StatisticalDoubleVector stats = hdata.perfDataByTxn
						.get(service);

				if (stats != null) {
					writer2.write(stats.size() + "\t" + stats.getAverage()
							+ "\t" + stats.getPercentile(.9) + "\t"
							+ stats.getPercentile(.95) + "\t"
							+ stats.getMaximum() + "\t");
				} else {
					writer2.write("\t\t\t\t\t");
				}
			}
			writer2.writeLine("");
		}

		writer2.close();

	}

	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50 && str.charAt(4) == '-'
				&& str.charAt(7) == '-') {

			str = Utility.replaceString(str, "- Target ", "- ");
			str = Utility.replaceString(str, " (self-tuning)'", "");

			words.setString(str);

			String date = words.getWord(0);
			String time = words.getWord(1);
			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);

			// System.out.println(str);
			// for (int i = 0; i < words.getWordCount(); i++) {
			// System.out.println(i + " -> " + words.getWord(i));
			// }
			if (parms.use(date, timeMs)) {

				str = str.replaceAll("\\[ +", "[");
				words.setString(str);
				if (str.indexOf("CACHE_") > 0) {
					Matcher matcher = NUM_DASH_PATTERN.matcher(str);
					if (matcher.find()) {
						int p = matcher.start();
						str = str.substring(0, p + 1);
					}
					words.setString(str);
				}

				String txn = words.getWord(6);

				txn = txn.replace("OMF.", "");
				int p = str.indexOf(" PERFORMANCE-");
				String txn2 = words.getWord(16);
				if (txn2 != null)
					txn2 = txn2.replace("OMF.", "");
				String srvTxn2 = txn2;
				if (p > 0) {
					txn2 = str.substring(p + 13).trim();
				}

				String channel = words.getWord(8);
				String hoi = words.getWord(10);
				String stxnPerf = words.getWord(words.getWordCount() - 1);
				p = stxnPerf.lastIndexOf(':');
				if (p > 0) {
					stxnPerf = stxnPerf.substring(p + 1);
				}

				if (Utility.isNumber(stxnPerf) && hoi != null
						&& hoi.length() == 8 && hoiPattern.matcher(hoi).find()) {
					long txnPerf = Long.parseLong(stxnPerf);

					String txnId = words.getWord(4);
					String txnSrvcName = null;
					if (txnId.length() == 0) {
						txnId = hoi;
					} else {
					}
					if (txnId.length() == 0 && hoi.length() == 0) {
						txnId = channel + '-' + txn;
					}

					p = txn.indexOf('.');
					txnSrvcName = txn;
					if (p > 0) {
						txnSrvcName = txn.substring(0, p);
					}

					if (srvTxn2 != null
							&& srvTxn2.indexOf(txnSrvcName + '.') >= 0) {
						srvTxn2 = txnSrvcName;
					}

					if (txnPerf > 0) {

						String txn3 = matchSubTransation(txn, txn2);

						boolean subTxn = false;
						if (txn3 != null) {
							txn = txn + '.' + txn3;
							txn2 = txn;
							srvTxn2 = txn;
							subTxn = true;
						}

						if (yifPattern.matcher(txn2).find()) { // Only works if
																// no sub
																// transaction
																// on OCS and
																// OES
							txn = txn + ".CPQ";
							txn2 = txn;
							srvTxn2 = txn;
							txnSrvcName = txn;
						}

						if (txn != null && txn.length() > 0
								&& txnSrvcName.equals(srvTxn2)  || subTxn) {

							if (txn.trim().length() == 0) {
								// System.out.println("ERROR: Blank Transaction: "+str);
								return true;
							}

							HoiPerfData dataElement = perfData.get(hoi);
							if (dataElement == null) {
								dataElement = new HoiPerfData(hoi);
								perfData.put(hoi, dataElement);
							}

							dataElement.addStats(txn, txnPerf);
							services.add(txn);

						}
					} else if (txnSrvcName.equals(txn2)) {
						System.err.println("Zero Time: " + str);
					}
				} else if (txn.equals(txn2)) {
					System.err.println("ERR in: " + str);
				}
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data, long start) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();

		// Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				files.add(getStartTime(child.getAbsolutePath()) + "|"
						+ child.getName());
			}
		}

		Collections.sort(files);

		for (i = 0; i < files.size(); i++) {

			String fileName1 = files.get(i);
			int pos = fileName1.indexOf('|');
			String fileName = fileName1.substring(pos + 1);

			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {

				long time = 0;
				if (i > 0) {
					long msPer = ((System.currentTimeMillis() - start) / (i));
					time = (files.size() - i) * msPer;
					System.out.println("Processing: " + fileName1
							+ " approximately "
							+ Utility.longTo24DayHour((time + 500) / 1000L)
							+ " - each: " + Utility.longTo24HourMilli(msPer));
				} else {
					System.out.println("Processing: " + fileName1);

				}

				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(),
							line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: "
							+ child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();

			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data, start);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	private String getStartTime(String absoluteFile) {

		StringReader reader = new StringReader(absoluteFile);
		if (reader.open() == 1) {
			throw new RuntimeException("Cannot open file: " + absoluteFile);
		}

		String str = reader.readLine();
		int count = 5;

		while (count > 0
				&& (str == null || str.length() < 20 || str.charAt(4) != '-' || str
						.charAt(7) != '-')) {
			str = reader.readLine();
		}

		if (str != null && str.length() > 20 && str.charAt(4) == '-'
				&& str.charAt(7) == '-') {
			reader.close();
			return str.substring(0, 23);
		} else {
			throw new RuntimeException("Error in file (not date): "
					+ absoluteFile);
		}

	}

	public static void main(String[] args) {

		if (args.length != 7) {

			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name"); // 0
			System.err.println("         date yyyy-mm-dd"); // 1
			System.err.println("         file starts with"); // 2
			System.err.println("         start time (hh:mm:ss:ttt)"); // 3
			System.err.println("         end time (hh:mm:ss:ttt)"); // 4
			System.err.println("         out dir name"); // 5
			System.err.println("         config file"); // 6
			System.exit(-1);

		}

		parseCfg(args[6], args[0], args[5]);

		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-"
					+ date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0]
				+ "      Out Dir: " + args[5]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellOmfPerformanceLogsHoiProcessor(args[0], args[5],
					args[2]);
		}

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(date, 0);
		parms.date2 = null;
		parms.setStartEnd(args[3], args[4]);

		line.recurse(f, parms, System.currentTimeMillis());

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {
		}

		System.out.println("Done");

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * 
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}

	/**
	 * Sets the currentFile
	 * 
	 * @param currentFile
	 *            The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
	}

	/**
	 * Gets the startPath
	 * 
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}

	/**
	 * Sets the startPath
	 * 
	 * @param startPath
	 *            The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

	private String matchSubTransation(String txn, String txn2) {

		for (int i = 0; i < detailService.size(); i++) {

			if (detailService.get(i).equals(txn)) {
				if (((Pattern) detailSubServiceExp.get(i)).matcher(txn2).find()) {
					// return txn+"."+detailSubServiceName.get(i);
					return (String) detailSubServiceName.get(i);
				}
			}
		}
		return null;
	}

	private static void parseCfg(String fileName, String dir1, String dir2) {
		StringReader reader = new StringReader(fileName);

		if (reader.open() != 0) {
			System.out.println("Cannot open config file: " + fileName);
			throw new RuntimeException("Cannot open config file: " + fileName);
		}

		String lineStr = reader.readLine();
		String service = null;

		while (lineStr != null) {
			lineStr = lineStr.trim();

			if (lineStr.length() == 0 || lineStr.charAt(0) == '#') {
				// nop - comment line or blank line

			} else if (lineStr.charAt(0) == '[') {
				service = lineStr.substring(1, lineStr.length() - 1).trim();

			} else {
				int p = lineStr.indexOf('=');

				if (p > 0) {
					String name = lineStr.substring(0, p).trim();
					String value = lineStr.substring(p + 1).trim();

					detailService.add(service);
					detailSubServiceName.add(name);
					detailSubServiceExp.add(Pattern.compile(value));
				}
			}

			lineStr = reader.readLine();
		}

		reader.close();
	}

}

class HoiPerfData {

	String hoi;

	Hashtable<String, StatisticalDoubleVector> perfDataByTxn = new Hashtable<String, StatisticalDoubleVector>();

	public HoiPerfData(String hoi) {
		this.hoi = hoi;
	}

	public void addStats(String txn, double perfTimeMs) {

		StatisticalDoubleVector perfData;

		perfData = perfDataByTxn.get(txn);

		if (perfData == null) {
			perfData = new StatisticalDoubleVector(1000, 1000);
			perfDataByTxn.put(txn, perfData);
		}

		perfData.add(perfTimeMs);
	}

}
