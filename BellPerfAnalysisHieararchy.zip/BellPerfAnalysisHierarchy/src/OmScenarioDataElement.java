import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.StatisticalDoubleVector;

/*
 * Created on Aug 22, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */


public class OmScenarioDataElement {
	String name;
	public static int STATS_SIZE = 100;
	
	StatisticalDoubleVector servletStats = new StatisticalDoubleVector(STATS_SIZE, STATS_SIZE);
	Hashtable<String, StatisticalDoubleVector> byCall = new Hashtable<String, StatisticalDoubleVector>();

	public OmScenarioDataElement(String scenarioName) {
		name = scenarioName;
	}
	
	void addStats(ScenarioData scenData) {
		
		if (scenData.timingHiearchy == null) scenData.cleanScenario();
		
		scenData.timingHiearchy.addStats(byCall, STATS_SIZE);
		
		servletStats.add(scenData.timesMs.get(scenData.calls.size()-1).doubleValue());
		
	}

}
