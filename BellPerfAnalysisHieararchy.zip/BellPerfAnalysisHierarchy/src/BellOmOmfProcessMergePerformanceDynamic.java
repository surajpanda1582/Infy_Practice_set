import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;

import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;


/*
 * Created on Jan 21, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class BellOmOmfProcessMergePerformanceDynamic {

	private static final String OMF = "OMF";
	private static final String OM = "OM";
	private static final String FILE_START_OM  = "scenario-";
	private static final String FILE_START_OMF = "services-";
	private static HashMap<String, MergeNameScenario> namesByScenario = new HashMap<String, MergeNameScenario>();
	public static int maxNameId = 0;
	private static PreparedStatement insertStatementTrans;
	private static PreparedStatement insertStatementName;
	private static ArrayList<String> detailReports = new ArrayList<String>();
	

	public static void main(String[] args) {
		
		if (args.length > 2) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         in/out dir (optional)");
			System.err.println("         perf/prod (optional)");
			System.exit(-1);
		}

		String dir = "."+File.separatorChar;
		if (args.length > 0) {
			dir = args[0];
		}
		String perfProd = "PROD";
		if (args.length > 1) {
			perfProd = args[1].toUpperCase();
		}
		
		if (dir.charAt(dir.length()-1) != File.separatorChar) {
			dir = dir + File.separatorChar;
		}
		System.out.println("Directory: "+ dir);

		String date = StringReader.readLine(dir + "date.txt");
		
		processServicesFiles(date, dir, perfProd);
	
	}
	
	private static void processServicesFiles(String date, String dir, String perfProd) {
		
		Connection connection = null;
		if (perfProd.equals("PROD")) {
			connection = createOpenDb(dir, date);
		}
		
		File dirFile = new File(dir);
		String[] list;
		list = dirFile.list();
		Arrays.sort(list);
		
		ArrayList<File> filelist = new ArrayList<File>();

		for (int i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(FILE_START_OM)) {
				filelist.add(child);
			}
		}
		
		Collections.sort(filelist);
		
		StringWriter writer = null;
		if (!perfProd.equals("PROD")) {
			writer = new StringWriter(dir + "OM_OMF_Performance_details.tab");
			writer.open();
			writer.writeLine("\t" + date);
			writer.writeLine("Component\t# Calls\tAvg(ms)\t90%(ms)\t95%(ms)\tMax(ms)");
		}

		for (int i = 0; i < filelist.size(); i++) {
			File child = filelist.get(i);
			String omFileName = child.getPath();
			int p = omFileName.indexOf(FILE_START_OM);
			int p2 = omFileName.lastIndexOf('.');
			int l = FILE_START_OM.length();
			String omfFileName = omFileName.substring(0, p) + FILE_START_OMF + omFileName.substring(p+l);
			String scenario = omFileName.substring(p+l, p2);
			
			MergedPerfData servlet = new MergedPerfData(scenario);
			parseTabFile(omFileName, OM, servlet);
			parseTabFile(omfFileName, OMF, servlet);
			
			
			MergeNameScenario mns = namesByScenario.get(scenario);
			if (mns == null) {
				mns = new MergeNameScenario(scenario);
				namesByScenario.put(scenario, mns);
			}
			if (perfProd.equals("PROD")) {
				servlet.writeToDB(insertStatementTrans, insertStatementName, mns, date);
			} else {
				printDetails(writer, servlet);
			}
		}

		
		
		if (connection != null) {
			BellCreateChartPng.createDetailTabSpreadsheet(connection, dir, 14);

			createCharts(connection, dir);
			try {
				connection.close();
			} catch (SQLException ignored) {
			}
		}

		if (!perfProd.equals("PROD")) {
			writer.close();
		}


		System.out.println("Done");
		
	}

	private static void createCharts(Connection transactionDbConn, String dir) {

		
		BellCreateChartPng.createSummaryChart(transactionDbConn, dir, "Chart1", 30*3);
		BellCreateChartPng.createSummaryChart(transactionDbConn, dir, "Chart2", 30*3);

		getDetailCharts(transactionDbConn);
		
		for (Iterator<String> iterator = detailReports.iterator(); iterator.hasNext();) {
			String report = iterator.next();
			
			BellCreateChartPng.createDetailChart(transactionDbConn, dir, report, 30*3);
		}
	}

	private static void getDetailCharts(Connection transactionDbConn) {
		
		Statement stmt;
		
		try {
			stmt = transactionDbConn.createStatement();
			
			System.out.println("Getting Detail Chart Names");
			ResultSet rs = stmt.executeQuery("select SCENARIO from trans_name where detail='Y';");
			
			while (rs.next()) {
				String scenarioName = rs.getString("SCENARIO");
				detailReports.add(scenarioName);
			}
			rs.close();
			stmt.close();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				transactionDbConn.close();
			} catch (SQLException ignored) {
				ignored.printStackTrace();
			}
			System.exit(-1);
		}

		
	}

	public static Shape createDiamond(final float s) {
		final GeneralPath p0 = new GeneralPath();
		p0.moveTo(0.0f, -s);
		p0.lineTo(s, 0.0f);
		p0.lineTo(0.0f, s);
		p0.lineTo(-s, 0.0f);
		p0.closePath();
		return p0;
	}
	  
	public static Shape createStar(final int s) {
        int xPoints[] = {s*3, s*5, 0, s*6, s};
        int yPoints[] = {0, s*6, s*2, s*2, s*6};

        GeneralPath star = new GeneralPath();

        star.moveTo(xPoints[0]-(s*3), yPoints[0]-(s*3));
        for (int i = 1; i < xPoints.length; i++) {
            star.lineTo(xPoints[i]-(s*3), yPoints[i]-(s*3));
        }
        star.closePath();

        return star;
    }
    
	private static Connection createOpenDb(String outDir, String date) {
	    try {
	    	boolean readDB = true;
	    	
			Class.forName("org.sqlite.JDBC");
			String dbFileName = outDir + "OmOmfMergedData.db";
			File dbFile = new File(dbFileName);
			
			if (!dbFile.exists()) {
				System.out.println("DB is not found: "+dbFileName);
				readDB = false;
			}
			
			Connection transactionDbConn = DriverManager.getConnection("jdbc:sqlite:"+dbFileName);
			
			if (!readDB) {
				Statement stmt = transactionDbConn.createStatement();
				
				String sql = "CREATE TABLE TRANS_NAME "
							+ " (ID INTEGER PRIMARY KEY     NOT NULL, "
							+ " SCENARIO       TEXT    NOT NULL, "
							+ " RPT_NAME       TEXT, "
							+ " DETAIL	       TEXT, "
							+ " NAME           TEXT    NOT NULL) ";
				stmt.executeUpdate(sql);
	
				sql = "CREATE TABLE TRANS_PERF "
					+ " (NAME_ID     INTEGER    NOT NULL, "
					+ " DATE         TEXT    NOT NULL, "
					+ " NUM_CALLS    INTEGER    NOT NULL, "
					+ " AVG          REAL    NOT NULL, "
					+ " PCNT_90      REAL    NOT NULL, "
					+ " PCNT_95      REAL    NOT NULL, "
					+ " MAX          REAL    NOT NULL) ";
				stmt.executeUpdate(sql);
				stmt.close();
				
			}  else {
				Statement stmt = transactionDbConn.createStatement();
				
				System.out.println("Loading Names...");
				ResultSet rs = stmt.executeQuery("SELECT ID, SCENARIO, NAME FROM TRANS_NAME ORDER BY SCENARIO, NAME;");
				
				while (rs.next()) {
					int id = rs.getInt("ID");
					String scenarioName = rs.getString("SCENARIO");
					String name = rs.getString("NAME");
					
					if (id > maxNameId) {
						maxNameId = id;
					}
					
					MergeName mn = new MergeName(id, scenarioName, name);
					MergeNameScenario mns = namesByScenario.get(scenarioName);
					if (mns == null) {
						mns = new MergeNameScenario(scenarioName);
						namesByScenario.put(scenarioName, mns);
					}
					
					mns.namesByName.put(name, mn);
					mns.namesById.put(id, mn);
					
				}				
				
				String sql="PRAGMA journal_mode = MEMORY";
				stmt.execute(sql);
				
				sql = "delete from TRANS_PERF WHERE date='"+date+"'";
				stmt.executeUpdate(sql);
				stmt.close();

				System.out.println("Loading Names-done");
				
			}
			
			insertStatementTrans = transactionDbConn.prepareStatement("insert into TRANS_PERF (NAME_ID, DATE, NUM_CALLS, AVG, PCNT_90, PCNT_95, MAX) values (?, ?, ?, ?, ?, ?, ?)");
			insertStatementTrans.setQueryTimeout(30); // set timeout to 30 sec.
			insertStatementName = transactionDbConn.prepareStatement("insert into TRANS_NAME (ID, SCENARIO, NAME, RPT_NAME) values (?, ?, ?, ?)");
			insertStatementName.setQueryTimeout(30); // set timeout to 30 sec.

			return transactionDbConn;
			
	    } catch ( Exception e ) {
			e.printStackTrace();
			System.exit(-1);
	    }
	    
		return null;
		
	}

	private static void printDetails(StringWriter writer, MergedPerfData servlet) {
		
		servlet.print(writer);
		writer.writeLine("");
		
	}

	public static DecimalFormat formatter = new DecimalFormat("#,###");
	public static DecimalFormat formatter2= new DecimalFormat("#.#");
	
	private static int parseTabFile(String fileName, String type, MergedPerfData servlet) {
		
		System.out.println("Reading " + fileName);
		StringReader reader = new StringReader(fileName);
		int count = 0;
		
		if (reader.open() != 0) {
			System.err.println("Cannot open file: "+fileName);
			//throw new RuntimeException("Cannot open file: "+fileName);
			return -1;
		}
		
		String lineStr = reader.readLine();
		String[] headers = null;
		if (lineStr != null) {
			headers = lineStr.split("\\t");
			lineStr = reader.readLine();  // Skip header
			lineStr = reader.readLine();  // Skip header 2
			
		} else {
			reader.close();
			System.out.println("Empty file: "+fileName);
			return -1;
		}

		if (OMF.equals(type)) {
			for (int i = 1; i < headers.length; i++) {
				if (headers[i].length() > 0 && headers[i].startsWith("OM:")) {
					
					
					headers[i] = headers[i].substring(3);
					MergedPerfData child = findItem(headers[i], servlet);
					
					child.count = 0;
					child.totalAvg = 0;
					child.total90 = 0;
					child.total95 = 0;
				}
			}
	
		}
		
		int maxCols = 0;
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length() > 0) {
				String[] data = lineStr.split("\\t");
				
				maxCols = Math.max(maxCols, data.length);
				
				parseRecord(headers, data, type, servlet);
				
				count++;
				
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
		System.out.println("Read " + count);
		
		if (maxCols < 3) {
			System.err.println("Empty file: "+fileName);
			return - 1;
		}
		
		return 0;
		
	}

	private static void parseRecord(String[] headers, String[] data, String type, MergedPerfData topServlet) {

		int i, start = 1;
		for (i = 2; i < headers.length; i++) {
			if (headers[i].length() > 0) {
				break;
			}
		}
		
		int l = i - start;

		if (OM.equals(type)) {
			if (data.length < 2 || data[1].length() == 0) return;
			
			start = 6;
			int count = Integer.parseInt(data[1]);
			topServlet.count += count;
			topServlet.totalAvg += count * Double.parseDouble(data[2]);
			topServlet.total90 += count * Double.parseDouble(data[3]);
			if (l > 4) {
				topServlet.total95 += count * Double.parseDouble(data[4]);
				topServlet.maximum = Math.max(topServlet.maximum, (int)Double.parseDouble(data[5]));
			} else {
				topServlet.maximum = Math.max(topServlet.maximum, (int)Double.parseDouble(data[4]));
			}
		}
		
		
		for (i = start; i < headers.length; i++) {
			if (headers[i].length() > 0 && !headers[i].equals("All")) {
				
				MergedPerfData child = findItem(headers[i], topServlet);
				
				if (i < data.length && data[i].length() > 0) {
					int count = Integer.parseInt(data[i]);
					child.count += count;
					child.totalAvg += count * Double.parseDouble(data[i+1]);
					child.total90 += count * Double.parseDouble(data[i+2]);
					if (l > 4) {
						child.total95 += count * Double.parseDouble(data[i+3]);
						child.maximum = Math.max(child.maximum, (int)Double.parseDouble(data[i+4]));
					} else {
						child.maximum = Math.max(child.maximum, (int)Double.parseDouble(data[i+3]));						
					}
				}
			}
		}
		
	}

	private static MergedPerfData findItem(String header, MergedPerfData topServlet) {
		
		int p1 = header.indexOf('(');
		int p2 = header.indexOf(')');
		int p3 = header.indexOf('|', p2);
		int p4 = header.indexOf('|');

		/* Find initial name in
		 * name
		 * name|child|child
		 * name(parent)
		 * name(parent)|child|child 
		 */
		String name = header;
		String parent = "";
		if (p1 > 0) {
			name = header.substring(0, p1);
			parent = header.substring(p1+1, p2);
			header = header.substring(p2+1);
		
		} else if (p4 > 0) {
			name = header.substring(0, p4);
			header = header.substring(p4);
			
		}
		
		/* process remainder children
		 * |child|child
		 */
		p3 = header.indexOf('|');
		p4 = header.lastIndexOf('|');
		
		if (p4 >= 0 && p3 == p4) {  // One name
			if (parent.length() > 0) {
				parent = parent + "|" + name;
			} else {
				parent = name;
			}
			name = header.substring(p4+1);
			
		} else if (p4 >= 0) {  // multiple
			if (parent.length() > 0) {
				parent = parent + "|" + name + header.substring(0, p4);
			} else {
				parent = name + header.substring(0, p4);
			}
			name = header.substring(p4+1);
		}
		
		return topServlet.find(parent, name);
	}

}

class MergedPerfData {
	String name;
	
	int    count;
	double totalAvg;
	double total90;
	double total95;
	int    maximum;
	
	ArrayList<MergedPerfData> children = new ArrayList<MergedPerfData>();

	private MergedPerfData() {
		name = "";
	}

	public void print(StringWriter writer) {
		print(writer, "");
		
	}

	private void print(StringWriter writer, String indent) {
		
		writer.writeLine(indent + name +'\t'+ count +'\t'+ Math.round(totalAvg/count) +'\t'+ Math.round(total90/count) +'\t'+ Math.round(total95/count) +'\t'+ maximum);
		
		indent = indent+"| ";
		for (Iterator<MergedPerfData> iterator = children.iterator(); iterator.hasNext();) {
			MergedPerfData child = iterator.next();
			
			child.print(writer, indent);
		}
		
	}

	public void writeToDB(PreparedStatement insertStatementTrans, PreparedStatement insertStatementTransName, MergeNameScenario mns, String date) {
		try {
			
			String rName = "Servlet";
			MergeName mn = mns.namesByName.get(rName);
			
			if (mn == null) {
				BellOmOmfProcessMergePerformanceDynamic.maxNameId++;
				mn = new MergeName(BellOmOmfProcessMergePerformanceDynamic.maxNameId, mns.name, rName);
				insertStatementTransName.setInt(1, BellOmOmfProcessMergePerformanceDynamic.maxNameId);
				insertStatementTransName.setString(2, mns.name);
				insertStatementTransName.setString(3, rName);
				insertStatementTransName.setString(4, "Scenario");
				insertStatementTransName.executeUpdate();
			}
			
			insertStatementTrans.setInt(1, mn.id);
			insertStatementTrans.setString(2, date);
			if (count == 0) {
				insertStatementTrans.setInt(3, 0);
				insertStatementTrans.setDouble(4, 0);
				insertStatementTrans.setDouble(5, 0);
				insertStatementTrans.setDouble(6, 0);
				insertStatementTrans.setDouble(7, 0);
				
			}else {
				insertStatementTrans.setInt(3, count);
				insertStatementTrans.setDouble(4, totalAvg/count);
				insertStatementTrans.setDouble(5, total90/count);
				insertStatementTrans.setDouble(6, total95/count);
				insertStatementTrans.setDouble(7, maximum);
			}
			
			insertStatementTrans.executeUpdate();
			
			for (Iterator<MergedPerfData> iterator = children.iterator(); iterator.hasNext();) {
				MergedPerfData child = iterator.next();
				
				child.writeToDB(insertStatementTrans, insertStatementTransName, mns, date, "", 1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(-1);
		}
		
	}

	//prepareStatement("insert into TRANS_PERF (NAME_ID, DATE, NUM_CALLS, AVG, PCNT_90, PCNT_95, MAX) values (?, ?, ?, ?, ?, ?, ?)");
	//prepareStatement("insert into TRANS_NAME (ID, SCENARIO, NAME) values (?, ?, ?)");

	private void writeToDB(PreparedStatement insertStatementTrans, PreparedStatement insertStatementTransName, MergeNameScenario mns, String date, String parent, int level) throws SQLException {
		
		
		if (parent != null && parent.length() > 0) {
			parent = parent+"|"+name;
		} else {
			parent = name;
		}
		MergeName mn = mns.namesByName.get(parent);
		if (mn == null) {
			BellOmOmfProcessMergePerformanceDynamic.maxNameId++;
			mn = new MergeName(BellOmOmfProcessMergePerformanceDynamic.maxNameId, mns.name, parent);
			insertStatementTransName.setInt(1, BellOmOmfProcessMergePerformanceDynamic.maxNameId);
			insertStatementTransName.setString(2, mns.name);
			insertStatementTransName.setString(3, parent);
			switch (level) {
				case 1:
					insertStatementTransName.setString(4, "Servlet");
					break;
					
				case 2:
					insertStatementTransName.setString(4, "Action");
					break;
					
				case 3:
					insertStatementTransName.setString(4, "OM Service");
					break;
					
				case 4:
					insertStatementTransName.setString(4, "OMF Service");
					break;
					
				default:
					if (name.endsWith("CPQ")) {
						insertStatementTransName.setString(4, "CPQ");
					} else if (name.equals("Network+OM")) {
						insertStatementTransName.setString(4, "Network+OM");
					}else {
						insertStatementTransName.setString(4, "Child");
					}
					break;
			}
			insertStatementTransName.executeUpdate();
		}
		
		insertStatementTrans.setInt(1, mn.id);
		insertStatementTrans.setString(2, date);
		if (count == 0) {
			insertStatementTrans.setInt(3, 0);
			insertStatementTrans.setDouble(4, 0);
			insertStatementTrans.setDouble(5, 0);
			insertStatementTrans.setDouble(6, 0);
			insertStatementTrans.setDouble(7, 0);
			
		}else {
			insertStatementTrans.setInt(3, count);
			insertStatementTrans.setDouble(4, totalAvg/count);
			insertStatementTrans.setDouble(5, total90/count);
			insertStatementTrans.setDouble(6, total95/count);
			insertStatementTrans.setDouble(7, maximum);
		}
		
		insertStatementTrans.executeUpdate();
		
		for (Iterator<MergedPerfData> iterator = children.iterator(); iterator.hasNext();) {
			MergedPerfData child = iterator.next();
			
			child.writeToDB(insertStatementTrans, insertStatementTransName, mns, date, parent, level+1);
		}
		
	}

	public MergedPerfData(String name2) {
		name = name2;
	}

	public MergedPerfData find(String parent, String name2) {
		
		MergedPerfData rChild = null;
		
		if (parent != null && parent.length() > 0) {
			
			int p = parent.indexOf('|');
			
			String cParent = parent;
			if (p > 0) {
				cParent = parent.substring(0, p);
				parent = parent.substring(p+1);
				
			} else {
				parent = "";
			}
			
			for (Iterator<MergedPerfData> iterator = children.iterator(); iterator.hasNext();) {
				MergedPerfData child = iterator.next();
				
				if (child.name.equals(cParent)) {
					return child.find(parent, name2);
				}
			}
			
			rChild = new MergedPerfData(cParent);
			children.add(rChild);
			return rChild.find(parent, name2);
			
		} else {
			for (Iterator<MergedPerfData> iterator = children.iterator(); iterator.hasNext();) {
				MergedPerfData child = iterator.next();
				
				if (child.name.equals(name2)) {
					return child;
				}
			}
			
			rChild = new MergedPerfData(name2);
			children.add(rChild);
			return rChild;
			
		}
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MergedPerfData other = (MergedPerfData) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		
		if (children.size() > 0) {
			return name + "->" + children;
		} else {
			return name;
		}
	}
	
}

class MergeName {
	public Integer id;
	public String scenarioName;
	public String name;
	
	public MergeName(Integer id, String scenarioName, String name) {
		super();
		this.id = id;
		this.scenarioName = scenarioName;
		this.name = name;
	}
}

class MergeNameScenario {
	public String name;
	
	HashMap<String, MergeName> namesByName = new HashMap<String, MergeName>();
	HashMap<Integer, MergeName> namesById = new HashMap<Integer, MergeName>();
	
	public MergeNameScenario(String name) {
		this.name = name;
		
	}
}
