import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import javax.net.ssl.HttpsURLConnection;

public final class SelecticaBO {

	String orderNumber;
	ArrayList startTime = new ArrayList();  //Date
	ArrayList endTime = new ArrayList();  //Date
	Date lastTxnTime;
	long length = -1;

	
	public ArrayList getEndTime() {
		return endTime;
	}
	public void addEndTime(Date endTime) {
		this.endTime.add(endTime);
	}
	
	public Date getLastTxnTime() {
		return lastTxnTime;
	}
	public void setLastTxnTime(Date lastTxnTime) {
		this.lastTxnTime = lastTxnTime;
	}
	
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	public ArrayList getStartTime() {
		return startTime;
	}
	public void addStartTime(Date startTime) {
		this.startTime.add(startTime);
	}
	
	public void sort() {
		Collections.sort(startTime);
		Collections.sort(endTime);
	}
	
	public long getLength() {
		if (length == -1 && startTime.size() == 1 && endTime.size() == 1) {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date startDate = (Date)startTime.get(0);
			Date endDate = (Date)endTime.get(0);
			
			length = endDate.getTime() - startDate.getTime();
			length /= 1000;
				
			if (length < 60) length = 0;
		}

		return length;
	}

}
