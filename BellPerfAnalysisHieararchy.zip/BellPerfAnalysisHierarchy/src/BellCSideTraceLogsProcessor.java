import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellCSideTraceLogsProcessor extends LineProcessorWithData {

	static BellCSideTraceLogsProcessor line = null;
	List<String> dirs;
	String outDir;
	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	static FileProcessorWithData fp = null;

	private static ArrayList<String> detailService = new ArrayList<String>();

	Hashtable<Integer, OmfServicesDataElement> omfPerfData = new Hashtable<Integer, OmfServicesDataElement>();
	Hashtable<String, Hashtable<String, String>> mostRecentService = new Hashtable<String, Hashtable<String, String>>();
	ArrayListNoDuplicates<String> omfServices = new ArrayListNoDuplicates<String>();


	String fileStartsWith = "*";

	public StringWriter writer;
	private WordString words = new WordString("");

	static private Pattern OMF_OUTBOUND_PATTERN = Pattern
			.compile("LOGOMF  - ((?!JDBC).)*Outbound");
	static private Pattern OMF_INBOUND_PATTERN = Pattern
			.compile("LOGOMF  - ((?!JDBC).)*Inbound");

	public BellCSideTraceLogsProcessor(String dirs, String outDir,
			String fileStartsWith, String minMs, String maxMs) {
		this.dirs = Arrays.asList(dirs.split(","));
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);
		words.setDelimiters(new char[] { ' ', '[', ']' });

		writer = new StringWriter(outDir + File.separator
				+ "services-cside-omf.tab");
		writer.open();
	}

	@Override
	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;

		if (str != null && str.length() > 24 && str.charAt(4) == '-'
				&& str.charAt(7) == '-') {

			words.setString(str);

			String date = words.getWord(0);
			String time = words.getWord(1);
			String container = words.getWord(3) + words.getWord(4)
					+ words.getWord(5);

			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);

			if (parms.use(date, timeMs)) {

				Integer interval = new Integer((int) (timeMs / parms.interval));

				Matcher matcher = OMF_OUTBOUND_PATTERN.matcher(str);

				if (matcher.find()) {
					words.setString(matcher.group());
					String serviceName = words.getWord(2);
					serviceName = serviceName.replace(":", ".");
					serviceName = serviceName.replace("OMF.Digitek.GetOrder",
							"OMF.DigiTekService.GetOrder");
					processOMFCalls(interval, container, serviceName, date,
							time, null);
				} else {
					matcher = OMF_INBOUND_PATTERN.matcher(str);

					if (matcher.find()) {
						words.setString(matcher.group());
						String serviceName = words.getWord(2);
						serviceName = serviceName.replace(":", ".");
						serviceName = serviceName.replace(
								"OMF.Digitek.GetOrder",
								"OMF.DigiTekService.GetOrder");

						processOMFCalls(interval, container, serviceName, date,
								null, time);
					}
				}

			}

		}

		return true;
	}

	private void processOMFCalls(Integer interval, String container,
			String serviceName, String date, String startTime, String endTime) {

		OmfServicesDataElement dataElement = omfPerfData.get(interval);
		if (dataElement == null) {
			dataElement = new OmfServicesDataElement(interval);
			omfPerfData.put(interval, dataElement);
		}

		if (startTime != null && endTime == null) {
			Hashtable<String, String> lastServiceMap = mostRecentService
					.get(container);

			if (lastServiceMap == null) {
				lastServiceMap = new Hashtable<String, String>();
				mostRecentService.put(container, lastServiceMap);
			}
			lastServiceMap.put(serviceName, startTime);
			return;

		} else if (startTime == null && endTime != null) {
			Hashtable<String, String> lastServiceMap = mostRecentService
					.get(container);

			if (lastServiceMap == null)
				return;

			startTime = lastServiceMap.get(serviceName);
		}

		if (startTime == null) {
			System.out.println("No start time found for: " + serviceName);
			
		} else {
			long startT = Utility.time24HourMilliToLong(startTime);
			long endT = Utility.time24HourMilliToLong(endTime);
	
			omfServices.add(serviceName);
			dataElement.addData(serviceName, endT - startT);
		}
	}

	public static void main(String[] args) {

		if (args.length < 7) {
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir names delimited by comma");
			System.err.println("         date yyyy-mm-dd");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			//System.err.println("         config file");
			System.exit(-1);
		}

		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-"
					+ date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dirs: " + args[0]
				+ "      Out Dir: " + args[6]);

		line = new BellCSideTraceLogsProcessor(args[0], args[6], args[3],
				args[4], args[5]);

		//parseCfg(args[7], args[6]);

		OmfParameters parms = new OmfParameters(date, Integer.parseInt(args[2]));
		parms.setStartEnd(args[4], args[5]);

		line.recurse(parms);

		line.print(parms);

		exit(0);
	}

	public void print(OmfParameters data) {
		Collections.sort(omfServices);
		writeServiceData(data, minMs, maxMs);
	}

	private void writeServiceData(OmfParameters cdata, long tMinMs, long tMaxMs) {
		minMs = tMinMs;
		maxMs = cdata.maxMs;

		boolean headerWritten = false;

		Integer interval = new Integer((int) (minMs / cdata.interval));
		int maxInterval = (int) (maxMs / cdata.interval);

		while (interval.doubleValue() <= maxInterval) {
			OmfServicesDataElement intervalDataElement = (OmfServicesDataElement) omfPerfData
					.get(interval);

			if (intervalDataElement != null) {

				if (headerWritten == false) {
					writeServicesHeader(writer);
					headerWritten = true;
				}
				writer.write(Utility.longTo24Hour(interval.intValue()
						* cdata.interval / 1000)
						+ "\t");

				for (int i = 0; i < omfServices.size(); i++) {
					StatisticalDoubleVector stats = (StatisticalDoubleVector) intervalDataElement.servicesCategory
							.get(omfServices.get(i));

					if (stats != null) {
						writer.write(stats.size() + "\t" + stats.getAverage()
								+ "\t" + stats.getPercentile(.9) + "\t");
					} else {
						writer.write("\t\t\t");
					}
				}

				writer.writeLine("");
			}

			interval = new Integer(interval.intValue() + 1);
		}

		writer.close();
	}

	/**
	 * 
	 */
	private void writeServicesHeader(StringWriter writer) {

		if (omfServices == null) {
			return;
		}

		writer.write("\t");

		for (Iterator<String> iterator = omfServices.iterator(); iterator.hasNext();) {
			String call = iterator.next();

			writer.write(call + "\t\t\t");
		}

		writer.writeLine("");
		writer.write("Interval\t");
		for (int i = 0; i < omfServices.size(); i++) {
			writer.write("Num\tAvg\t90%\t");
		}
		writer.writeLine("");
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {
		}

		System.exit(num);
	}

	private static List<File> getAllFiles(List<String> dirs, String fileStartsWith) {
		List<File> files = new ArrayList<File>();
		
		for (String dir : dirs) {
			File inputDirFile = new File(dir);

			if (inputDirFile.exists())
				files.addAll(Arrays.asList(inputDirFile.listFiles()));

		}
		
		List<String> filenames = new ArrayList<String>();
		
		for (File file : files) {
			if (file.getName().startsWith(fileStartsWith)) {
				filenames.add(getStartTime(file.getAbsolutePath()) + "|" + file.getAbsolutePath());
			}
		}
		
		Collections.sort(filenames);
		files.clear();
		
		for (String filename : filenames) {
			int p = filename.indexOf('|');
			files.add(new File(filename.substring(p+1)));
		}
		

		return files;
	}

	private static String getStartTime(String absoluteFile) {

		StringReader reader = new StringReader(absoluteFile);
		if (reader.open() == 1) {
			throw new RuntimeException("Cannot open file: " + absoluteFile);
		}
		
		String str = reader.readLine();
		int count = 5;
		
		while (count > 0 && (str == null || str.length() < 20 || str.charAt(4) != '-' || str.charAt(7) != '-')) {
			str = reader.readLine();
		}
		
		if (str != null && str.length() > 20 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			reader.close();
			return str.substring(0, 23);
		} else {
			throw new RuntimeException("Error in file (not date): " + absoluteFile);
		}
		
	}

	public boolean recurse(Object data) {

		List<File> files = getAllFiles(dirs, fileStartsWith);

		for (File file : files) {

			if (file.isFile() && file.getName().startsWith(fileStartsWith)) {
				System.out.println("Processing: " + file);

				try {

					fp = new FileProcessorWithData(file.getAbsolutePath(),
							line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: "
							+ file.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
			}
		}
		return true;
	}

	private static void parseCfg(String fileName, String dir2) {
		StringReader reader = new StringReader(fileName);

		if (reader.open() != 0) {
			System.out.println("Cannot open config file: " + fileName);
			throw new RuntimeException("Cannot open config file: " + fileName);
		}

		String lineStr = reader.readLine();
		String service = null;

		while (lineStr != null) {
			lineStr = lineStr.trim();

			if (lineStr.length() == 0 || lineStr.charAt(0) == '#') {
				// nop - comment line or blank line

			} else if (lineStr.charAt(0) == '[') {
				service = lineStr.substring(1, lineStr.length() - 1).trim();
				detailService.add(service);
			}
			lineStr = reader.readLine();
		}

		reader.close();
	}

}

class OmfServicesDataElement {

	Integer interval;
	Hashtable<String, StatisticalDoubleVector> servicesCategory = new Hashtable<String, StatisticalDoubleVector>();

	OmfServicesDataElement(Integer interval) {
		this.interval = interval;
	}

	void addData(String service, double value) {
		StatisticalDoubleVector data;

		data = servicesCategory.get(service);
		if (data == null) {
			data = new StatisticalDoubleVector(
					BellOmfPerformanceLogsProcessor.STATS_SIZE,
					BellOmfPerformanceLogsProcessor.STATS_SIZE);
			servicesCategory.put(service, data);
		}

		data.add(value);

	}

}
