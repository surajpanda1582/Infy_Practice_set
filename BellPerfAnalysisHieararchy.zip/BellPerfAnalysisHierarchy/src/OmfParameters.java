import java.util.Date;

import ca.bell.reporting.utilities.Utility;

/*
 * Created on 31-May-10
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

class OmfParameters {
	
	String date;
	String date2;
	int interval;
	long timeout1, timeout2;
	Date startTm, endTm;
	long minMs, maxMs;
	static final long MAXMS = Utility.time24HourMilliToLong("23:59:59:999");

	OmfParameters(String date, int interval) {
		this.date = date;
		this.interval = interval;
	}

	OmfParameters(String date, int interval, long timeout1) {
		this.date = date;
		this.interval = interval;
		this.timeout1 = timeout1;
	}

	OmfParameters(String date, int interval, long timeout1, long timeout2) {
		this.date = date;
		this.interval = interval;
		this.timeout1 = timeout1;
		this.timeout2 = timeout2;
	}
	
	public void setStartEnd(String minMs, String maxMs) {
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);
	}
	public boolean use (String pdate, long timeMs) {
		
		if (date2 == null) {
			return timeMs >= minMs && timeMs <= (maxMs) && date.equals(pdate);
			
		} else if (date.equals(pdate)) {
			return timeMs >= minMs && timeMs <= (MAXMS);
			
		} else if (date2.equals(pdate)) {
			return timeMs >= 0 && timeMs <= (maxMs);
			
		} else {
			return false;
		}
	}

	public boolean before (String pdate, long timeMs) {
		
		if (date2 == null) {
			return (timeMs < minMs && date.equals(pdate)) || pdate.compareTo(date) < 0;
			
		} else if (date.equals(pdate) || date2.equals(pdate)) {
			return timeMs < minMs;
			
		} else if (pdate.compareTo(date) < 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean after (String pdate, long timeMs) {
		
		if (date2 == null) {
			return (timeMs > maxMs && date.equals(pdate)) || pdate.compareTo(date) > 0;
			
		} else if (date.equals(pdate) || date2.equals(pdate)) {
			return timeMs > maxMs;
			
		} else if (pdate.compareTo(date2) > 0) {
			return true; 
		} else {
			return false;
		}
	}

}
