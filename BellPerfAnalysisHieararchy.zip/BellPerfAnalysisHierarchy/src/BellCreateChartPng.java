import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;

import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.DateUtility;


/*
 * Build detail charts
 */

public class BellCreateChartPng {

	private static HashMap<String, MergeNameScenario> namesByScenario = new HashMap<String, MergeNameScenario>();
	public static int maxNameId = 0;
	

	public static void main(String[] args) {
		
		if (args.length != 3) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         DB file");
			System.err.println("         Scenario Name or Summ:Chart name or TAB (for spreadsheet)");
			System.err.println("         Report Days");
			System.exit(-1);
		}

		Connection connection = createOpenDb(args[0]);

		int p = args[0].lastIndexOf(File.separatorChar);
		String dir = "." + File.separatorChar;
		if (p > 0) {
			dir = args[0].substring(0, p+1);
		}
		
		if (args[1].toUpperCase().startsWith("SUMM:")) {
			args[1] = args[1].substring(5);
			createSummaryChart(connection, dir, args[1], Integer.parseInt(args[2]));
			
		} else if (args[1].toUpperCase().startsWith("TAB")) {
			createDetailTabSpreadsheet(connection, dir, Integer.parseInt(args[2]));
			
		} else {
			createDetailChart(connection, dir, args[1], Integer.parseInt(args[2]));
		}
	
	}
	
	public static void createDetailChart(Connection transactionDbConn, String dir, String scenarioName, int reportDays) {

		
		Statement stmt;
		DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
		try {
			stmt = transactionDbConn.createStatement();
			
			GregorianCalendar gc = (GregorianCalendar)GregorianCalendar.getInstance();
			gc.add(Calendar.DAY_OF_MONTH, (-1) * reportDays);
			DateUtility du = new DateUtility(gc);
			String earliest = du.toDateString('-');
			
			System.out.println("Building Detail Chart: "+scenarioName);
			ResultSet rs = stmt.executeQuery("select a.scenario, a.rpt_name, a.name, b.* from TRANS_NAME A, TRANS_PERF B where a.id = b.name_id and a.scenario = '"+scenarioName+"' and date >= '" + earliest + "' order by b.date;");
			
			while (rs.next()) {
				String name = rs.getString("NAME");
//				String reportName = rs.getString("RPT_NAME");
				
				if (name.equals("Servlet")) {
					name = "Overall";
				} else {
					int p = name.lastIndexOf('|');
					if (p > 0) {
						name = name.substring(p+1);
					}
					String date = rs.getString("DATE");
					double avg = rs.getDouble("AVG")/1000;
	//				double pcnt90 = rs.getDouble("PCNT_90");
	//				double pcnt95 = rs.getDouble("PCNT_95");
	//				double max = rs.getDouble("maX");
					
					dataset.addValue( avg , name , date );
				}
			}
			rs.close();
			stmt.close();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				transactionDbConn.close();
			} catch (SQLException ignored) {
				ignored.printStackTrace();
			}
			System.exit(-1);
		}

		JFreeChart lineChart = ChartFactory.createLineChart(scenarioName,
   	         "Date", "Seconds", dataset, PlotOrientation.VERTICAL, true,true,false);
		
		lineChart.setTitle(new TextTitle(scenarioName, new Font("SansSerif", Font.BOLD, 20)));
		
		Font plain = new Font("SansSerif", Font.PLAIN, 12);
		Font bold = new Font("SansSerif", Font.BOLD, 12);
		lineChart.getLegend().setItemFont(plain);	

		lineChart.getCategoryPlot().getDomainAxis().setTickLabelFont(plain);
		lineChart.getCategoryPlot().getRangeAxis().setTickLabelFont(plain);
		lineChart.getCategoryPlot().getDomainAxis().setLabelFont(bold);
		lineChart.getCategoryPlot().getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_90);
		lineChart.getCategoryPlot().getRangeAxis().setLabelFont(bold);
		
		CategoryPlot plot = lineChart.getCategoryPlot();
		
		LineAndShapeRenderer renderer = new LineAndShapeRenderer();
		Shape circle = new Ellipse2D.Double(-8, -8, 16, 16);
		Shape square = new Rectangle2D.Double(-8, -8, 16, 16);
		Shape diamond = createDiamond(10);
		Shape smallCircle = new Ellipse2D.Double(-5, -5, 10, 10);
		Shape smallSquare = new Rectangle2D.Double(-5, -5, 10, 10);
		Shape smallDiamond = createDiamond(10);
		Shape star = createStar(3);
		 
		int shapeDiff = (dataset.getRowCount()+2)/4;
		if (dataset.getRowCount() > 24) {
			shapeDiff = (dataset.getRowCount()+4)/8;
		}
		//System.out.println(dataset.getRowCount() + "-" + shapeDiff);
		for (int i = 0; i < dataset.getRowCount(); i++) {
			 
			// sets thickness for series (using strokes)
			renderer.setSeriesStroke(i, new BasicStroke(5.0f));
			
			if (i < shapeDiff) {
				renderer.setSeriesShape(i, null);
			} else if (i < shapeDiff*2) {
				renderer.setSeriesShape(i, smallSquare);
			} else if (i < shapeDiff*3) {
				renderer.setSeriesShape(i, smallCircle);
			} else if (i < shapeDiff*4) {
				renderer.setSeriesShape(i, smallDiamond);
			} else if (i < shapeDiff*5) {
				renderer.setSeriesShape(i, circle);
			} else if (i < shapeDiff*6) {
				renderer.setSeriesShape(i, square);
			} else if (i < shapeDiff*7) {
				renderer.setSeriesShape(i, star);
			} else {
				renderer.setSeriesShape(i, diamond);
			}
			
		}
		
		plot.setRenderer(renderer);
		
		plot.setBackgroundPaint(Color.WHITE);
		plot.setDomainGridlinesVisible(true);
		plot.setDomainGridlinePaint(Color.BLACK);
		plot.setRangeGridlinesVisible(true);
		plot.setRangeGridlinePaint(Color.BLACK);
		plot.setRangeMinorGridlinesVisible(false);
		
		File file = new File(dir + scenarioName+".png");
		try {
			ChartUtilities.saveChartAsPNG(file, lineChart, 1500, 1000);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Shape createDiamond(final float s) {
		final GeneralPath p0 = new GeneralPath();
		p0.moveTo(0.0f, -s);
		p0.lineTo(s, 0.0f);
		p0.lineTo(0.0f, s);
		p0.lineTo(-s, 0.0f);
		p0.closePath();
		return p0;
	}
	  
	public static Shape createStar(final int s) {
        int xPoints[] = {s*3, s*5, 0, s*6, s};
        int yPoints[] = {0, s*6, s*2, s*2, s*6};

        GeneralPath star = new GeneralPath();

        star.moveTo(xPoints[0]-(s*3), yPoints[0]-(s*3));
        for (int i = 1; i < xPoints.length; i++) {
            star.lineTo(xPoints[i]-(s*3), yPoints[i]-(s*3));
        }
        star.closePath();

        return star;
    }
    
	private static Connection createOpenDb(String dbFileName) {
	    try {
	    	boolean readDB = true;
	    	
			Class.forName("org.sqlite.JDBC");
			File dbFile = new File(dbFileName);
			
			if (!dbFile.exists()) {
				System.out.println("DB is not found: "+dbFileName);
				readDB = false;
			}
			
			Connection transactionDbConn = DriverManager.getConnection("jdbc:sqlite:"+dbFileName);
			
			if (!readDB) {
				
				System.out.println("ERROR: DB does not exist");
				System.exit(-1);
				
			}  else {
				Statement stmt = transactionDbConn.createStatement();
				
				System.out.println("Loading Names...");
				ResultSet rs = stmt.executeQuery("SELECT ID, SCENARIO, NAME FROM TRANS_NAME ORDER BY SCENARIO, NAME;");
				
				while (rs.next()) {
					int id = rs.getInt("ID");
					String scenarioName = rs.getString("SCENARIO");
					String name = rs.getString("NAME");
					
					if (id > maxNameId) {
						maxNameId = id;
					}
					
					MergeName mn = new MergeName(id, scenarioName, name);
					MergeNameScenario mns = namesByScenario.get(scenarioName);
					if (mns == null) {
						mns = new MergeNameScenario(scenarioName);
						namesByScenario.put(scenarioName, mns);
					}
					
					mns.namesByName.put(name, mn);
					mns.namesById.put(id, mn);
					
				}				
				
				String sql="PRAGMA journal_mode = MEMORY";
				stmt.execute(sql);
				
				System.out.println("Loading Names-done");
				
			}
			
			return transactionDbConn;
			
	    } catch ( Exception e ) {
			e.printStackTrace();
			System.exit(-1);
	    }
	    
		return null;
		
	}

	public static void createSummaryChart(Connection transactionDbConn, String dir, String chartName, int reportDays) {
			Statement stmt;
			
			GregorianCalendar gc = (GregorianCalendar)GregorianCalendar.getInstance();
			gc.add(Calendar.DAY_OF_MONTH, (-1) * reportDays);
			DateUtility du = new DateUtility(gc);
			String earliest = du.toDateString('-');

			DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
			int count = 0;
			try {
				stmt = transactionDbConn.createStatement();
				
				System.out.println("Building Summary Chart");
				ResultSet rs = stmt.executeQuery("select a.scenario, a.rpt_name, b.* from TRANS_NAME A, TRANS_PERF B where a.id = b.name_id and a.RPT_NAME like '"+ chartName +"-Scenario-%' and date >= '" + earliest + "' order by b.date, a.rpt_name;");
				//ResultSet rs = stmt.executeQuery("select a.scenario, a.rpt_name, b.* from TRANS_NAME A, TRANS_PERF B where a.id = b.name_id and date >= '" + earliest + "' order by b.date;");
				
				while (rs.next()) {
					count++;
					String scenarioName = rs.getString("SCENARIO");
					String reportName = rs.getString("RPT_NAME");
					String name = reportName.substring(16) +'-'+ scenarioName;
					
					String date = rs.getString("DATE");
					double avg = rs.getDouble("AVG")/1000;
	//				double pcnt90 = rs.getDouble("PCNT_90");
	//				double pcnt95 = rs.getDouble("PCNT_95");
	//				double max = rs.getDouble("maX");
					
					dataset.addValue( avg , name , date );
				}
				rs.close();
				stmt.close();
				
				
			} catch (SQLException e) {
				e.printStackTrace();
				try {
					transactionDbConn.close();
				} catch (SQLException ignored) {
					ignored.printStackTrace();
				}
				System.exit(-1);
			}
	
			JFreeChart lineChart = ChartFactory.createLineChart("Daily Performance "+chartName,
	   	         "Date", "Seconds", dataset, PlotOrientation.VERTICAL, true,true,false);
			
			lineChart.setTitle(new TextTitle("Daily Performance "+chartName, new Font("SansSerif", Font.BOLD, 20)));
			
			Font plain = new Font("SansSerif", Font.PLAIN, 12);
			Font bold = new Font("SansSerif", Font.BOLD, 12);
			lineChart.getLegend().setItemFont(plain);	
	
			lineChart.getCategoryPlot().getDomainAxis().setTickLabelFont(plain);
			lineChart.getCategoryPlot().getRangeAxis().setTickLabelFont(plain);
			lineChart.getCategoryPlot().getDomainAxis().setLabelFont(bold);
			lineChart.getCategoryPlot().getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_90);
			lineChart.getCategoryPlot().getRangeAxis().setLabelFont(bold);
			
			CategoryPlot plot = lineChart.getCategoryPlot();
			
			LineAndShapeRenderer renderer = new LineAndShapeRenderer();
			Shape circle = new Ellipse2D.Double(-8, -8, 16, 16);
			 
			for (int i = 0; i < count; i++) {
				 
				// sets thickness for series (using strokes)
				renderer.setSeriesStroke(i, new BasicStroke(5.0f));
				
				if (i < 6) {
					renderer.setSeriesShape(i, null);
				} else {
					renderer.setSeriesShape(i, circle);
				}
				
			}
			
			plot.setRenderer(renderer);
			
			plot.setBackgroundPaint(Color.WHITE);
			plot.setDomainGridlinesVisible(true);
			plot.setDomainGridlinePaint(Color.BLACK);
			plot.setRangeGridlinesVisible(true);
			plot.setRangeGridlinePaint(Color.BLACK);
			plot.setRangeMinorGridlinesVisible(false);
			
			File file = new File(dir + "_Summary"+chartName+".png");
			try {
				ChartUtilities.saveChartAsPNG(file, lineChart, 1500, 1000);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	public static void createDetailTabSpreadsheet(Connection transactionDbConn, String dir, int reportDays) {
		Statement stmt;
		
		GregorianCalendar gc = (GregorianCalendar)GregorianCalendar.getInstance();
		gc.add(Calendar.DAY_OF_MONTH, (-1) * reportDays);
		DateUtility du = new DateUtility(gc);
		String earliest = du.toDateString('-');

		StringWriter writer = new StringWriter(dir + "OM_OMF_Performance_Details.tab");
		writer.open();
		StringWriter writer2 = new StringWriter(dir + "OM_OMF_Performance_Avg.tab");
		writer2.open();
		
		StringBuilder top = new StringBuilder();
		StringBuilder second = new StringBuilder();
		top.append('\t');
		second.append('\t');
		StringBuilder top2 = new StringBuilder();
		StringBuilder second2 = new StringBuilder();
		top2.append('\t');
		second2.append('\t');
		
		try {
			stmt = transactionDbConn.createStatement();
			
			System.out.println("Building Summary Chart");
			ResultSet rs = stmt.executeQuery("select distinct date from TRANS_PERF where date >= '" + earliest + "' order by date;");
			HashMap<String, Integer> dates = new HashMap<String, Integer>();

			int count = 0;
			while (rs.next()) {
				String date = rs.getString("DATE");
				
				dates.put(date, count);
				count++;
				top.append(date +"\t\t\t\t\t");
				second.append("#Calls\tAvg(ms)\t90%(ms)\t95%(ms)\tMax(ms)\t");
				top2.append(date +"\t");
				second2.append("Avg(ms)\t");
				
			}
			rs.close();	
			System.out.println(dates);
			
			writer.writeLine(top.toString());
			writer.write(second.toString());
			writer2.writeLine(top2.toString());
			writer2.write(second2.toString());

			String lastScenario = null;
			String lastChild = null;
			
			String[] data = new String[dates.size()*5];
			String[] data2 = new String[dates.size()];
			
			rs = stmt.executeQuery("select a.scenario, a.name, b.* from TRANS_NAME A, TRANS_PERF B where a.id = b.name_id and date >= '" + earliest + "' order by scenario, name, date;");
			
			while (rs.next()) {
				String scenarioName = rs.getString("SCENARIO");
				String childName = rs.getString("NAME");
				
				String date = rs.getString("DATE");
				
				int calls = rs.getInt("NUM_CALLS");
				double avg = rs.getDouble("AVG");
				double pcnt90 = rs.getDouble("PCNT_90");
				double pcnt95 = rs.getDouble("PCNT_95");
				double max = rs.getDouble("MAX");
				
				if (lastChild == null || lastScenario == null || !scenarioName.equals(lastScenario) || !childName.equals(lastChild)) {
					
					if (lastScenario != null) {
						writeData(writer, writer2, lastScenario, lastChild, data, data2);
					}
					
					for (int i = 0; i < dates.size(); i++) {
						for (int j = 0; j < 5; j++) {
							data[(i*5)+j] = "";	
						}
						data2[i] = "";
					}
				}
				
				lastScenario = scenarioName;
				lastChild = childName;
				
				int i = dates.get(date);
				int k = i*5;
				data2[i] = String.valueOf(Math.round(avg));
				
				data[k] = String.valueOf(calls); 
				data[k+1] = String.valueOf(Math.round(avg)); 
				data[k+2] = String.valueOf(Math.round(pcnt90)); 
				data[k+3] = String.valueOf(Math.round(pcnt95)); 
				data[k+4] = String.valueOf(Math.round(max)); 

			}
			
			if (lastScenario != null) {
				writeData(writer, writer2, lastScenario, lastChild, data, data2);
			}
			
			rs.close();
			stmt.close();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				transactionDbConn.close();
			} catch (SQLException ignored) {
				ignored.printStackTrace();
			}
			
			System.exit(-1);
			
		} finally {
			writer.close();
			writer2.close();
		}

	}

	private static void writeData(StringWriter writer, StringWriter writer2, String scenario, String childName, String[] data, String[] data2) {
		
		
		String name = buildName(childName, scenario);
		if (name.equals(scenario)){
			writer.writeLine("");
			writer2.writeLine("");
		}
		writer.write(name+'\t');
		writer2.write(name+'\t');
		
		for (int i = 0; i < data2.length; i++) {
			for (int j = 0; j < 5; j++) {
				writer.write(data[(i*5)+j]+'\t');
			}
			writer2.write(data2[i]+'\t');
		}
		writer.writeLine("");
		writer2.writeLine("");
		
	}

	private static String buildName(String name, String scenario) {

		if (name.equals("Servlet")) {
			return scenario;
		}
		
		int p = name.indexOf('|');
		StringBuilder name2 = new StringBuilder();
		name2.append('|');
		while (p > 0) {
			name2.append('|');
			name = name.substring(p+1);
			p = name.indexOf('|');
		}
		
		name2.append(name);
		return name2.toString();
	}

}
