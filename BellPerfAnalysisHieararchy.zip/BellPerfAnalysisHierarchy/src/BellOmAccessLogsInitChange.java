import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellOmAccessLogsInitChange extends LineProcessorWithData {

	
	private File currentFile;
	private String currentServer;
	private String dir;
	private String outDir = "./";
	
	private StringWriter mismatchWriter;

	@SuppressWarnings("rawtypes")

	Hashtable<String, BellOmAccessInitEntry> accessEntries = new Hashtable<String, BellOmAccessInitEntry>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String accessFileStartsWith = "omaccess_";
	
	private WordString words = new WordString("");
	private WordString words2 = new WordString("");
	

	public BellOmAccessLogsInitChange(String dir, String accessFileStartsWith, String minMs, String maxMs) {

		this.dir = dir;
		this.outDir = outDir;
		this.accessFileStartsWith = accessFileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { '|' });
		words2.setDelimiters(new char[] { ' ' });
		
		System.out.println("Output to: " + outDir);
		
		mismatchWriter = new StringWriter(outDir + "mismatch.txt");
		mismatchWriter.open();
		
		mismatchWriter.writeLine("User\tLogin parms\tInit Change Parms");

	}


	public void print(OmParameters data) {
		
		mismatchWriter.close();
		System.out.println("Matched "+BellOmAccessInitEntry.getMatchCount()+" of "+BellOmAccessInitEntry.getTotalCount());
	}

	public boolean processLine(String str, Object data) {
		
		return processLineAccess(str, data);
			
	}
	
	@SuppressWarnings("unchecked")
	public boolean processLineAccess(String str, Object data) {


		OmParameters parms = (OmParameters) data;
		if (str != null && str.length() > 40 && str.charAt(4) == '-' && str.charAt(7) == '-' && str.charAt(10) == ' ') {
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			String hoi = "";
			String user = "";
			if (parms.use(date, timeMs)) {
				
				String txn = null;
				String txnData = null;
				
		    	if (words.getWordCount() >= 5) {
					hoi = words.getWord(1);
					user = words.getWord(2);
					txn = words.getWord(3);
					txnData = words.getWord(4);
					
					
					//2017-02-15 19:08:37,023 DEBUG access- ||BELL\don_dennis.centeno|/OrderMax/login.do|MIN=,ONEBL=102250928,B1=b1wtiq91,NAME=,PTN=6136349168,SEGMENT=,EXVUBAN=8455100621476895,BBE=,
					//2017-02-15 19:53:01,883 DEBUG access- ||BELL\bccs.cd6036182|/OrderMax/login.do|testMode=LDAP,ORDERID=K62G69E9,B1=,RECOMMENDATIONID=503e9.2350.ffffffffa3edb63d.7c18562d,CLICKTOORDER=YES,loginId=bccs.cd6036182,EXPVUBAN=,area=OR,PTN=4165900299,PROMOCODE=SPAON179,
					//2017-02-15 19:53:49,130 DEBUG access- ||BELL\bccs.cd6065664|/OrderMax/login.do|PTN=8192422163,SEGMENT=,MIN=,B1=b1vscs47,EXVUBAN=8455100503345341,ONEBL=246496699,NAME=,BBE=,
					//2017-02-15 19:53:52,054 DEBUG access- |K62G74Q4|BELL\bccs.cd6065664|/OrderMax/initiateOrderSubmitChange.do|LANGUAGE_CHANGE=,changeExpressVuAccountNumber=8455100503345341,change=,changeSympaticoB1Number=b1vscs47,userPeinOverride=,displayUserGroup=,changeMobilityTelelphoneNumber=,changeTelephoneNumber=819-242-2163,

					if (user.length() == 0) {
						int p = str.indexOf("loginId=");
						if (p > 0) {
							int p2 = str.indexOf(',', p);
							if (p2 < 0) {
								p2 = str.length();
							}
							
							user = str.substring(p+8, p2);
						}
					}
					
					if ("/OrderMax/login.do".equals(txn)) {
						BellOmAccessInitEntry entry = accessEntries.get(user);
						
						if (entry == null) {
							entry = new BellOmAccessInitEntry(user, txnData);
							accessEntries.put(user, entry);
						}
						
						
					} else if ("/OrderMax/initiateOrderSubmitChange.do".equals(txn)) {
						BellOmAccessInitEntry entry = accessEntries.get(user);
						
						if (entry != null) {
							entry.compareTxnData(txnData, mismatchWriter);
							accessEntries.remove(user);
						}
					}
		    	}
		    	
			}
		}

		return true;
	}


	public boolean recurseAccess(File dirFile, Object data) {
		int i;

		System.out.println("Reading files : "+accessFileStartsWith);

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(accessFileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(accessFileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurseAccess(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}
	
	static FileProcessorWithData fp = null;
	static BellOmAccessLogsInitChange line = null;
	private static boolean readHoiFile;

	public static void main(String[] args) {

		if (args.length != 5) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");							//0
			System.err.println("         date (yyyy-mm-dd)");					//1
			System.err.println("         access file starts with");				//2
			System.err.println("         start time (hh:mm:ss:ttt)");			//3
			System.err.println("         end time (hh:mm:ss:ttt)");				//4
			System.exit(-1);
				
		}
		
		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start this one is invalid: "+args[0]);
			System.exit(0);
		}

		line = new BellOmAccessLogsInitChange(args[0], args[2], args[3], args[4]);

		OmParameters parms = new OmParameters(date, 0, line.minMs, line.maxMs);
		
		line.recurseAccess(f, parms);
		
		line.print(parms);

		System.out.println("Done");
		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName().substring(7, 18);
		
	}

}

//2017-02-15 19:08:37,023 DEBUG access- ||BELL\don_dennis.centeno|/OrderMax/login.do|MIN=,ONEBL=102250928,B1=b1wtiq91,NAME=,PTN=6136349168,SEGMENT=,EXVUBAN=8455100621476895,BBE=,
//2017-02-15 19:53:01,883 DEBUG access- ||BELL\bccs.cd6036182|/OrderMax/login.do|testMode=LDAP,ORDERID=K62G69E9,B1=,RECOMMENDATIONID=503e9.2350.ffffffffa3edb63d.7c18562d,CLICKTOORDER=YES,loginId=bccs.cd6036182,EXPVUBAN=,area=OR,PTN=4165900299,PROMOCODE=SPAON179,
//2017-02-15 19:53:49,130 DEBUG access- ||BELL\bccs.cd6065664|/OrderMax/login.do|PTN=8192422163,SEGMENT=,MIN=,B1=b1vscs47,EXVUBAN=8455100503345341,ONEBL=246496699,NAME=,BBE=,
//2017-02-15 19:53:52,054 DEBUG access- |K62G74Q4|BELL\bccs.cd6065664|/OrderMax/initiateOrderSubmitChange.do|LANGUAGE_CHANGE=,changeExpressVuAccountNumber=8455100503345341,change=,changeSympaticoB1Number=b1vscs47,userPeinOverride=,displayUserGroup=,changeMobilityTelelphoneNumber=,changeTelephoneNumber=819-242-2163,

class BellOmAccessInitEntry {
	private String user;
	private HashMap<String, String> txnData;
	private static int mismatchCount;
	private static int totalCount;
	private static int matchCount;
	
	public BellOmAccessInitEntry(String user, String txnData) {
		this.user = user;
		loadTxnData(txnData);
	}

	private void loadTxnData(String txnData2) {
		this.txnData = parseTxnData(txnData2);
		
	}

	public static HashMap<String, String> parseTxnData(String txnData2) {
		HashMap<String, String> ret = new HashMap<String, String>();
		
		String[] data = txnData2.split(",");
		
		for (int i = 0; i < data.length; i++) {
		
			String[] entry = data[i].split("=");
			
			if (entry.length > 1 && entry[1].length() > 0) {
				ret.put(entry[0], entry[1].replaceAll("[-]", ""));
			}
		}
		 
		return ret;
	}

	//PTN=8192422163,SEGMENT=,MIN=,B1=b1vscs47,EXVUBAN=8455100503345341,ONEBL=246496699,NAME=,BBE=,
	//LANGUAGE_CHANGE=,changeExpressVuAccountNumber=8455100503345341,change=,changeSympaticoB1Number=b1vscs47,userPeinOverride=,displayUserGroup=,changeMobilityTelelphoneNumber=,changeTelephoneNumber=819-242-2163,

	public void compareTxnData(String txnData2, StringWriter mismatchWriter) {
		totalCount++;
		
		HashMap<String, String> txnDataIn = parseTxnData(txnData2);
		
		ArrayList<String> keys = new ArrayList<String>();
		keys.addAll(txnData.keySet());
		
		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
			String key = iterator.next();
			
			if (key.equals("PTN")) {
				if (! compareEntry(txnData.get(key), txnDataIn.get("changeTelephoneNumber"))) {
					mismatchWriter.writeLine("PTN\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("MIN")) {
				if (! compareEntry(txnData.get(key), txnDataIn.get("changeMobilityTelelphoneNumber"))) {
					mismatchWriter.writeLine("MIN\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("B1")) {
				if (! compareEntry(txnData.get(key), txnDataIn.get("changeSympaticoB1Number"))) {
					mismatchWriter.writeLine("B1\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("EXVUBAN")) {
				if (! compareEntry(txnData.get(key), txnDataIn.get("changeExpressVuAccountNumber"))) {
					mismatchWriter.writeLine("EXVUBAN\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			}

		}
		
		keys.clear();
		keys.addAll(txnDataIn.keySet());

		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
			String key = iterator.next();
			
			if (key.equals("changeTelephoneNumber")) {
				if (! compareEntry(txnDataIn.get(key), txnData.get("PTN"))) {
					mismatchWriter.writeLine("PTN\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("changeMobilityTelelphoneNumber")) {
				if (! compareEntry(txnDataIn.get(key), txnData.get("MIN"))) {
					mismatchWriter.writeLine("changeMobilityTelelphoneNumber\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("changeSympaticoB1Number")) {
				if (! compareEntry(txnDataIn.get(key), txnData.get("B1"))) {
					mismatchWriter.writeLine("changeSympaticoB1Number\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			} else if (key.equals("changeExpressVuAccountNumber")) {
				if (! compareEntry(txnDataIn.get(key), txnData.get("EXVUBAN"))) {
					mismatchWriter.writeLine("changeExpressVuAccountNumber\t"+txnData + "\t" + txnDataIn);
					return;
				}
				
			}

		}

		matchCount++;
	}

	private boolean compareEntry(String value1, String value2) {
		
		if ((value2 != null && value1 == null && value2.length() > 0) || (value2 == null && value1 != null && value1.length() > 0)) {
			mismatchCount++;
			return false;
		}
		
		if (!value1.equals(value2)) {
			mismatchCount++;
			return false;
		}
		
		return true;
	}

	public String getUser() {
		return user;
	}

	public HashMap<String, String> getTxnData() {
		return txnData;
	}

	public static int getMismatchCount() {
		return mismatchCount;
	}

	public static int getTotalCount() {
		return totalCount;
	}

	public static int getMatchCount() {
		return matchCount;
	}
	
}
