import java.util.ArrayList;
import java.util.Collections;

import ca.bell.reporting.utilities.Utility;

/*
 * Created on Jan 7, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class ScenarioData {

	String hoi;
	String scenarioName;
	ArrayList<String> servers = new ArrayList<String>();
	ArrayList<String> calls = new ArrayList<String>();
	ArrayList<Integer> timesMs = new ArrayList<Integer>();
	ArrayList<Long> endTimes = new ArrayList<Long>();
	long startTime = 0;
	String lastPcsAction = "";
	TimingHierarchy timingHiearchy;
	
	public ScenarioData(String hoi, String serverName, String call, long endTime, int timeMs) {
		this.hoi = hoi;
		
		if (call != null) {
			addCall(serverName, call, endTime, timeMs);
		
			this.startTime = endTime-timeMs;
		}
	}
	
	public ScenarioData(String hoi, String serverName, String call, long endTime, int timeMs, String scenarioName) {
		
		this(hoi, serverName, call, endTime, timeMs);
		this.scenarioName = scenarioName;
		
	}
	
	public void addCall(String serverName, String call, long endTime, int timeMs) {
		
		if (calls.size() == 0) {
			this.startTime = endTime-timeMs;
		}
		
		if (serverName != null) servers.add(serverName);
		calls.add(call);
		timesMs.add(timeMs);
		this.endTimes.add(endTime);
	}

	public String getScenario() {
		if (timingHiearchy == null) cleanScenario();
		
		return timingHiearchy.toColumn("|", false);
		
	}
		
	public String getScenarioOld() {
		StringBuilder ret = new StringBuilder();
		ret.append(calls.get(calls.size()-1));
		ret.append(':');
		boolean first = true;
		
		for (int i = 0; i < calls.size()-1; i++) {
			if (! first) {
				ret.append(',');
				
			} else {
				first = false;
			}
			ret.append(calls.get(i));
		}
		
		return ret.toString();
	}
	
	public String getScenarioWithStartEnd() {
		
		if (timingHiearchy == null) cleanScenario();
		
		return timingHiearchy.toColumn("|", true);
	}
	
	public void cleanScenario() {
		
		ArrayList<String> sortArray = new ArrayList<String>();
		
		int last = calls.size()-1;  // Servlet
		long endTime = endTimes.get(last);
		long startTime = endTime - timesMs.get(last).longValue();
		
		// remove any not within the Servlet time
		for (int i = calls.size()-2; i >= 0; i--) {
			long end = endTimes.get(i);
			long start = end - timesMs.get(i).longValue();
			
			if (start < startTime || end > endTime) {
				if ((start+5) < startTime || (end-5) > endTime) {
					// Really not within
					calls.remove(i);
					endTimes.remove(i);
					timesMs.remove(i);
					
				} else if (start < startTime) {
					// Correct for minor write delays
					endTimes.remove(i);
					endTimes.add(i, end+startTime-start);
				}
			}
		}
		last = calls.size()-1;
		
		// Next code is building the call hierarchy (parallel and overlapping)
		// Sort by time as it is important to process the hierarchy using longest calls first
		for (int i = calls.size()-2; i >= 0; i--) {
			sortArray.add(Utility.zeroFill(timesMs.get(i), 6) + "-" + i);
		}
		
		Collections.sort(sortArray);
		timingHiearchy = TimingHierarchy.createTop(null, calls.get(last), startTime, endTime);

		//Process longest to shortest
		for (int j = sortArray.size()-1; j >= 0; j--) {
			String item = sortArray.get(j);
			int i = Integer.parseInt(item.substring(7));
			
			long end = endTimes.get(i);
			long start = end - timesMs.get(i).longValue();
			
			timingHiearchy.addItem(null, calls.get(i), start, end);
		}
		
		
	}

	public TimingHierarchy buildTimingHierarchy() {
		
		ArrayList<String> sortArray = new ArrayList<String>();
		long earliest = Long.MAX_VALUE;
		long latest = 0;
		
		for (int i = 0; i < calls.size(); i++) {
			long end = endTimes.get(i);
			long start = end - timesMs.get(i).longValue();
			if (earliest > start) earliest = start;
			if (latest < end) latest = end;
			
			sortArray.add(Utility.zeroFill(end-start, 6) + "-" + i);
		}
		
		Collections.sort(sortArray);
		TimingHierarchy timingHiearchy = TimingHierarchy.createTop(null, "TOP", earliest, latest);

		//Process longest to shortest
		for (int j = sortArray.size()-1; j >= 0; j--) {
			String item = sortArray.get(j);
			int i = Integer.parseInt(item.substring(7));
			
			if (i < 0) {
				System.out.println("ERROR index: " + i + " - '" + item + "'");
			}
			long end = endTimes.get(i);
			long start = end - timesMs.get(i).longValue();
			
			timingHiearchy.addItem(servers.size()>0?servers.get(i):null, calls.get(i), start, end);
		}
		
		return timingHiearchy;

	}

	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public long getStartTime() {
		return startTime;
	}

	public static ScenarioData processHoiScenario(String hoi, String scenData, String scenarioName, String action, long startMs) {
		
		ScenarioData hdata = null;
		
		String[] calls = scenData.split("[:,]");
			
		for (int i = 1; i < calls.length; i++) {
			
			if (calls[i].length() > 0){
				String[] callData = calls[i].split("~");
				int p = callData[0].lastIndexOf('|');
				String callName = callData[0];
				if (p > 0) {
					callName = callName.substring(p+1);
				}
				
				long timeMs = Long.parseLong(callData[2]);
				int txnPerf = Integer.parseInt(callData[3]);

				if (hdata == null) {
					hdata = new ScenarioData(hoi, null, callName, timeMs, txnPerf);
				} else {
					hdata.addCall(null, callName, timeMs, txnPerf);
				}
			}
		}
		
		//Servlet
		String[] callData = calls[0].split("~");  
		long timeMs = Long.parseLong(callData[2]);
		int txnPerf = Integer.parseInt(callData[3]);
		
		if (hdata == null) {
			hdata = new ScenarioData(hoi, null, callData[0], timeMs, txnPerf);
		} else {
			hdata.addCall(null, callData[0], timeMs, txnPerf);
		}
		
		hdata.scenarioName = scenarioName;
		if (action.length() > 0) {
			hdata.lastPcsAction = action;
		}
		hdata.startTime = startMs;
		
		hdata.cleanScenario();
		
		return hdata;
	}

}

