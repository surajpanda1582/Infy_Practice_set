import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringReader;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.ArrayListNoDuplicates;
import ca.bell.reporting.utilities.CSVReaderHeading;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;


class BellCPQRuleTraceLogsProcessor extends LineProcessorWithData {
	public static ArrayList<String> LOBS = new ArrayList<String>();
	static Pattern prodPattern = Pattern.compile("_[bwxis]");
	static Pattern attrPattern = Pattern.compile("_[bwxis][0-9]*a");

	
	static {
		LOBS.add("WL");
		LOBS.add("BB");
		LOBS.add("DSL");
		LOBS.add("DTH");
		LOBS.add("IPTV");
	}
	
	public class MutableDouble {
		double value;
	}
	
	public class Action {
		String name;
		String type;
		String search;
		
		Action(String line) {
			String[] items = line.split("\\|");
			
			name = items[0];
			type = items[1];
			if (items.length > 2) {
				search = items[2];
			}
		}
	}
	
	public class CpqData {
		String ruleName;
		Hashtable<String, StatisticalDoubleVector> fileData = new Hashtable<String, StatisticalDoubleVector>();
		Hashtable<String, StatisticalDoubleVector> fileTriggerData = new Hashtable<String, StatisticalDoubleVector>();
		
		CpqData(String ruleName2) {
			this.ruleName = ruleName2;
		}
		
		void addData(String fileName, long time, boolean triggered) {
			
			
			if (triggered) {
				StatisticalDoubleVector data2 = fileTriggerData.get(fileName);
				if (data2 == null) {
					data2 = new StatisticalDoubleVector(10, 10);
					fileTriggerData.put(fileName, data2);

				} 

				data2.add(time);
				
			} else {
				
				StatisticalDoubleVector data = fileData.get(fileName);
				if (data == null) {
					data = new StatisticalDoubleVector(10, 10);
					fileData.put(fileName, data);
				}
				
				data.add(time);
			}
		}
		
	}
	
	private File currentFile;
	String lastRule = null;
	private ArrayList<String> fileNames = new ArrayList<String>();
	

	private String startPath = "";
	Hashtable<String, CpqData> perfData = new Hashtable<String, CpqData>();
	private ArrayListNoDuplicates<String> configRules = new ArrayListNoDuplicates<String>();
	private ArrayListNoDuplicates<String> eligRules = new ArrayListNoDuplicates<String>();
	private ArrayListNoDuplicates<String> priceRules = new ArrayListNoDuplicates<String>();
	private ArrayListNoDuplicates<String> stopSold = new ArrayListNoDuplicates<String>();
	StringBuilder category = new StringBuilder();
	ArrayList<String> actions = new ArrayList<String>();
	Hashtable<String, MutableDouble> perfSummary = new Hashtable<String, MutableDouble>();
	Hashtable<String, MutableDouble> perfDetails = new Hashtable<String, MutableDouble>();
	
	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	static FileProcessorWithData fp = null;
	static BellCPQRuleTraceLogsProcessor line = null;
	
	private ArrayList<Action> actionList = new ArrayList<BellCPQRuleTraceLogsProcessor.Action>();
	StringWriter otherWriterDetails;
	private ArrayList<String> stepNames = new ArrayList<String>();

//	Hashtable<String, ArrayList<String>> ruleActions = new Hashtable<String, ArrayList<String>>();

	public BellCPQRuleTraceLogsProcessor(String dir, String outDir, String fileStartsWith, String stopSoldFile) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;

		if (stopSoldFile != null) {
			StringReader reader = new StringReader(dir + File.separatorChar + stopSoldFile);
			if (reader.open() >= 0) {
				
				String str;
				while ( (str = reader.readLine()) != null ) {
	
					int p = str.indexOf('\t');
					
					str = str.substring(p+1).trim();
					stopSold.add(str);
					
				}
				
				reader.close();
			}
		}

		StringReader reader = new StringReader(dir + File.separatorChar + "RequestSteps.txt");
		if (reader.open() >= 0) {
			
			String str;
			while ( (str = reader.readLine()) != null ) {

				int p = str.indexOf('\t');
				
				str = str.substring(p+1).trim();
				stepNames .add(str);
				
			}
			
			reader.close();
		}
		
//		CSVReaderHeading cReader = new CSVReaderHeading();
//		if (cReader.open("Z:\\HostF\\$Workspaces\\BellCanadaBRS36Rules.csv")) {
//			
//			String str;
//			while ( cReader.readRecord() ) {
//
//				String name = cReader.getColumn("Rule Name");
//				String actions = cReader.getColumn("Actions");
//				
//				String[] lines = actions.split("\n");
//				
//				ArrayList<String> aList = new ArrayList<String>();
//				
//				aList.add(name);
//				for (int i = 0; i < lines.length; i++) {
//					int p = lines[i].indexOf('=');
//					if (p < 0) {
//						p = lines[i].length();
//					}
//					aList.add(lines[i].substring(0, p));
//				}
//				
//				ruleActions.put(name, aList);
//			}
//			
//			cReader.close();
//		}
		
		otherWriterDetails = new StringWriter(outDir + File.separator + "CpqDataOther-"+fileStartsWith+".tab");
		otherWriterDetails.open();
		otherWriterDetails.writeLine("Request\tCategories\tTime\tActions");

	}

	StringWriter writerDetails;
	StringWriter writerSummary;
	int stepCount = 0;
	private void printPerFile() {
		
		if (writerSummary == null) {
			writerSummary = new StringWriter(outDir + File.separator + "CpqDataSummary-"+fileStartsWith+".tab");
			writerSummary.open();
			writerSummary.writeLine("Request#\tType\tTime (ms)");
		}
		
		if (writerDetails == null) {
			writerDetails = new StringWriter(outDir + File.separator + "CpqDataDetails-"+fileStartsWith+".tab");
			writerDetails.open();
			writerDetails.writeLine("Request#\tLoB\tCategory\tType\tTime (ms)");
		}

		ArrayList<String> keys = new ArrayList<String>(perfDetails.keySet());
		Collections.sort(keys);
		
		String req = currentFile.getName();
		if (stepCount < stepNames.size()) {
			req = Utility.zeroFill(stepCount+1, 2) + ": " + stepNames.get(stepCount);
		}

		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
			String key = iterator.next();
			
			MutableDouble mdata = perfDetails.get(key);
			String[] items = key.split("\\.");
			if (items.length < 3) {
				String[] oldItems = items;
				items = new String[3];
				
				int count = 2;
				for (int i = oldItems.length-1; i >= 0; i--) {
					items[count] = oldItems[i];
					count--;
				}
				for (; count >= 0; count--) {
					items[count] = "";
				}
			}
			
			writerDetails.writeLine(req + '\t' + items[0] + '\t' + items[1] + '\t' + items[2] + '\t' + mdata.value);
		}

		keys = new ArrayList<String>(perfSummary.keySet());
		Collections.sort(keys);
		
		req = currentFile.getName();
		if (stepCount < stepNames.size()) {
			req = Utility.zeroFill(stepCount+1, 2) + ": " + stepNames.get(stepCount);
		}

		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
			String key = iterator.next();
			
			MutableDouble mdata = perfSummary.get(key);
			
			writerSummary.writeLine(req + '\t' + key + '\t' + mdata.value);
		}

		stepCount++;
		
		perfDetails.clear();
		perfSummary.clear();
	}


	private void print(OmfParameters pdata) {

		writerDetails.close();
		writerSummary.close();
		otherWriterDetails.close();

		Collections.sort(fileNames);
		
		StringWriter writer2 = new StringWriter(outDir + File.separator + "CpqData-"+fileStartsWith+".tab");
		writer2.open();
		
		Set<String> keySet = perfData.keySet();
		ArrayList<String> keys = new ArrayList<String>();
		keys.addAll(keySet);
		Collections.sort(keys);

		writer2.write("Rule\tOES\tConfig\tPrice\tMin\tAvg\tMax\tNot Trigg\tTrigg\t");

		for (int j = 0; j < fileNames.size(); j++) {
			writer2.write(fileNames.get(j) + "\t\t\t\t\t");
		}
		writer2.writeLine("");
		
		writer2.write("\t\t\t\tms\tms\tms\t\t\t");

		for (int j = 0; j < fileNames.size(); j++) {
			writer2.write("Not Triggered\tms\tTriggered\tms\tTotal ms\t");
		}

		writer2.writeLine("");
		int count = 0;
		double sum = 0;
		double min = Integer.MAX_VALUE;
		double max = 0;
		StringBuilder outString = new StringBuilder();
		
		for (int i = 0; i < keys.size(); i++) {
			count = 0;
			sum = 0;
			min = Integer.MAX_VALUE;
			max = 0;
			outString.setLength(0);
			int tc1 = 0;
			int tc2 = 0;
			
			CpqData data = perfData.get(keys.get(i));
			writer2.write(keys.get(i) + "\t" + (eligRules.contains(keys.get(i))?'Y':'N') + "\t" + (configRules.contains(keys.get(i))?'Y':'N') + "\t" + (priceRules.contains(keys.get(i))?'Y':'N') + '\t');
			
			for (int j = 0; j < fileNames.size(); j++) {
				String fileName = fileNames.get(j);
				StatisticalDoubleVector data2 = data.fileData.get(fileName);
				StatisticalDoubleVector data3 = data.fileTriggerData.get(fileName);
				int c1 = data2 == null ? 0 : data2.size();
				double a1 = data2 == null ? 0 : data2.getAverage();
				double t1 = data2 == null ? 0 : data2.getTotal();
				int c2 = data3 == null ? 0 : data3.size();
				double a2 = data3 == null ? 0 : data3.getAverage();
				double t2 = data3 == null ? 0 : data3.getTotal();
				
				if (fileName.indexOf("-SS") < 0) {
					double total = t1+t2;
					tc1 += c1;
					tc2 += c2;
					if (max < total) {
						max = total;
					}
					if (min > total) {
						min = total;
					}
					count += 1;
					sum += total;
				}
				
				if (data2 == null && data3 == null) {
					outString.append("\t\t\t\t\t");
					
				} else {
					outString.append(c1 + "\t" + a1 + "\t" + c2 + "\t" + a2 + "\t" + (t1+t2) + "\t");
					
				}
			}
			
			writer2.writeLine(String.valueOf(min)+'\t'+Math.round(sum*10/count)/10+'\t'+max+'\t'+tc1+'\t'+tc2+'\t'+outString.toString());
		}
		
		writer2.close();
		
	}

	boolean triggered, stopSoldProduct;
	public boolean processLine(String str, Object pdata) {

		//OmfParameters parms = (OmfParameters) pdata;
		if (str != null && str.indexOf("<log message") >= 0) {
			
			str = str.trim();
			
			int p = str.indexOf("[phase:");
			if (p > 0) {	
				triggered = false;
				int p2 = str.indexOf("phase: *");
				p = str.indexOf("==> ");
				if (p < 0) {
					p = str.indexOf("- priority ");
				}
				lastRule = str.substring(14, p-1).trim();
				
				if (str.indexOf("Configuration") > 0 || p2 > 0) {
					configRules.add(lastRule);
				}
				if (str.indexOf("BasePrice") > 0 || p2 > 0) {
					priceRules.add(lastRule);
				}
				if (str.indexOf("Eligibility") > 0 || p2 > 0) {
					eligRules.add(lastRule);
				}
					
				actions.add(lastRule);
				
			}
			
			p = str.indexOf("\"took ");
			if (p > 0 && lastRule != null) {
				int p2 = str.indexOf("ms");
				String stime = str.substring(p+5, p2).trim();
				int time = Integer.parseInt(stime);
				
				CpqData data = perfData.get(lastRule);
				if (data == null) {
					data = new CpqData(lastRule);
					perfData.put(lastRule, data);
				}
				data.addData(currentFile.getName(), time, triggered);
				if (stopSoldProduct) {
					data.addData(currentFile.getName() + "-SS", time, triggered);
				}
				
				if (time > 0 && lastRule != null) {
					
//					ArrayList<String> last = null;
//					if (actions.size() ==1) {
//						last = ruleActions.get(lastRule);
//						if (last != null) {
//							actions = last;
//						}
//					}
					ArrayList<String> triggeredActions = findActions(actions);
					
					if (triggeredActions.size() == 0) {
						
						if (actions.size() == 1) {
							triggeredActions.add("Not Triggered");
						} else {
							triggeredActions.add("Other");
							otherWriterDetails.writeLine(currentFile.getName() + '\t' + category.toString() + '\t' + time + '\t' + actions);
						}
					}
					
					double timeD = ((double) time)/triggeredActions.size();
					for (Iterator<String> iterator = triggeredActions.iterator(); iterator.hasNext();) {
						String actionName = iterator.next();
						
						String key = category.toString() + '.' + actionName;
						MutableDouble mdata = perfDetails.get(key);
						
						if (mdata == null) {
							mdata = new MutableDouble();
							perfDetails.put(key, mdata);
						}
						
						mdata.value += timeD;
						
						mdata = perfSummary.get(actionName);
						
						if (mdata == null) {
							mdata = new MutableDouble();
							perfSummary.put(actionName, mdata);
						}
						
						mdata.value += timeD;

					}

				}				
				
				lastRule = null;
				triggered = false;
				actions.clear();
					
			}
			
			p = str.indexOf("\"          assigning ") + str.indexOf("\"          expansion ") + str.indexOf("\"          removing ") + str.indexOf("\"          produced ");
			if (p > 5) {
				triggered = true;
			}
			p = str.indexOf("\"          assigning ") + str.indexOf("\"          expansion ");
			if (p > 5) {
				actions.add(str);
			}
			p = str.indexOf("\"          produced ");
			if (p > 5) {
				actions.add("MESSAGE: " + str.substring(p+19));
			}
			
			String text = "Firing rules on ";
			int l = text.length();
			p = str.indexOf(text);
			if (p > 0) {
				category.setLength(0);
				
				int p2 = str.indexOf('"', p+l);
				str = str.substring(p+l, p2);
				
				boolean inLob = false;
				boolean shortName = false;
				
				String[] items = str.split("[ \\.\"]");
				String lastItem = null;
				for (int i = 0;  i < items.length; i++) {
					p = items[i].indexOf("_");
					if (p > 0) {
						
						if (prodPattern.matcher(items[i]).find()) {
							stopSoldProduct = stopSold.contains(items[i]);
							shortName = true;
							break;
						}
					}
					
					if (!shortName) {
						if (LOBS.contains(items[i])) {
							inLob = true;
						}
					}
					
					if (inLob && (lastItem == null || ! lastItem.equals(items[i]))) {
						if (category.length() > 0) {
							category.append('.');
						}
						category.append(items[i]);
						lastItem = items[i];
					}
				}
				
			}

		}

		return true;
	}

	private ArrayList<String> findActions(ArrayList<String> actions) {
		
		ArrayListNoDuplicates<String> ret = new ArrayListNoDuplicates<String>();
		
		for (Iterator<Action> iterator = actionList.iterator(); iterator.hasNext();) {
			Action action = iterator.next();
			
			if (action.type.equals("NAME")) {
				if (actions.get(0).contains(action.search)) {
					ret.add(action.name);
				}
				
			} else if (action.type.equals("ACTION")) {
				for (Iterator<String> iterator2 = actions.iterator(); iterator2.hasNext();) {
					String actionStr = iterator2.next();
					
					if (actionStr.contains(action.search)) {
						ret.add(action.name);
					}					
				}
				
			} else if (action.type.equals("MESSAGE")) {
				for (Iterator<String> iterator2 = actions.iterator(); iterator2.hasNext();) {
					String actionStr = iterator2.next();
					
					if (actionStr.contains("MESSAGE: ")) {
						ret.add(action.name);
					}					
				}
				
			} else if (action.type.equals("SELECTION_PROD")) {
				for (Iterator<String> iterator2 = actions.iterator(); iterator2.hasNext();) {
					String actionStr = iterator2.next();
					
					int p = actionStr.indexOf("\"          expansion ") + actionStr.indexOf("\"          removing ");
					if (p > 5 && prodPattern.matcher(actionStr).find() && !attrPattern.matcher(actionStr).find()) {
						
						ret.add(action.name);
					}					
				}
				
			} else if (action.type.equals("SELECTION_ATTR")) {
				for (Iterator<String> iterator2 = actions.iterator(); iterator2.hasNext();) {
					String actionStr = iterator2.next();
					
					int p = actionStr.indexOf("\"          expansion ") + actionStr.indexOf("\"          removing ");
					if (p > 5 && attrPattern.matcher(actionStr).find()) {
						
						ret.add(action.name);
					}					
				}
				
			} else {
				throw new RuntimeException("Invalid Action type: " + action.type);
			}
		}
		
		return ret;
	}


	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		for (i = 0; i < list.length; i++) {
			
			String fileName = list[i];
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);
					
				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				line.printPerFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}


	public static void main(String[] args) {

		if (args.length < 3 || args.length > 4) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         file starts with");
			System.err.println("         out dir name");
			System.err.println("         [Stop Sold Products List (TAB file)]");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(-1);
		}
		
		String ssFile = null;
		if (args.length > 3) {
			ssFile = args[3];
		}

		line = new BellCPQRuleTraceLogsProcessor(args[0],args[2], args[1], ssFile);
		line.readConfig(args[0] + File.separator + "CPQRuleTrace.cfg");

		line.setStartPath(f.getAbsolutePath());

		line.recurse(f, null);
		
		line.print(null);

		exit(0);
	}


	
	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		int p = currentFile.getName().indexOf('.');
		
		fileNames.add(currentFile.getName());
		if (stopSold.size() > 0) {
			fileNames.add(currentFile.getName()+"-SS");
		}
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}


	private void readConfig(String scenariosConfigFilename) {
	
		System.out.println("Reading " + scenariosConfigFilename);
		StringReader reader = new StringReader(scenariosConfigFilename);
		int count = 0;
		
		if (reader.open() < 0) {
			System.out.println("ERROR: cannot open: " + scenariosConfigFilename);
			System.exit(-1);
		}
		
		String line = reader.readLine();
		String lastName = null;
		
		while (line != null)  {
			
			line = line.trim();
			if (line.length() > 0) {
				actionList.add(new Action(line));
				count++;
			} 
			
			line = reader.readLine();
		}
		
		reader.close();
		
		System.out.println("Read " + count);
	
		
		//buildHeaders();
	}

}
