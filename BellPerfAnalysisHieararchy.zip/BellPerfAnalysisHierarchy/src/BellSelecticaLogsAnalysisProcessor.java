import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import ca.bell.reporting.io.FileProcessorWithData;
import ca.bell.reporting.io.LineProcessorWithData;
import ca.bell.reporting.io.StringWriter;
import ca.bell.reporting.utilities.DateUtility;
import ca.bell.reporting.utilities.StatisticalDoubleVector;
import ca.bell.reporting.utilities.Utility;
import ca.bell.reporting.utilities.WordString;


class BellSelecticaLogsAnalysisProcessor extends LineProcessorWithData {

	// Current Data
	private File currentFile;
	
	private StatisticalDoubleVector sessionLengthStats = new StatisticalDoubleVector(100000, 50000);

	//DateUtility calend;

	// Output Writer
	public StringWriter writer;

	// Log Path
	private String startPath = "";

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");

	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");

	String fileStartsWith = "";

	HashMap selecticaData = new HashMap();

	Date lastTransValue = null;

	String s = " ";

	// Word Parsing Utility
	private WordString words = new WordString("");

	public BellSelecticaLogsAnalysisProcessor(String dir, String fileStartsWith) {
		this.fileStartsWith = fileStartsWith;
		words.setDelimiters(new char[] { ' ', '|' });
		writer = new StringWriter(dir + File.separator + "output.tab");
		writer.open();
	}

	public BellSelecticaLogsAnalysisProcessor(String dir,
			String fileStartsWith, String minMs, String maxMs) {

		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);
		words.setDelimiters(new char[] { ' ', '|' });
		writer = new StringWriter(dir + File.separator + "output.tab");
		writer.open();
	}

	public void print(OmfParameters data) throws ParseException {
		String aLine = null;
		int interval = (int) (minMs / data.interval);
		int maxInterval = (int) (maxMs / data.interval);
		int lineNum = 0;
		writer.writeLine("Time" + "\t" + data.timeout1 + "\t" + data.timeout2 + "\tSess Starts");
		lineNum++;

		//Sort times
		for (Iterator i = selecticaData.keySet().iterator(); i.hasNext();) {
			String keyValue = (String) i.next();
			SelecticaBO timeCals = (SelecticaBO) selecticaData.get(keyValue);
			timeCals.sort();
			long length = timeCals.getLength();
			if (length > 0) {
				
				sessionLengthStats.add(length);
			}
		}
		
		while (interval <= maxInterval) {
			int sessionStartcount = 0;
			int sessioncount1 = 0;
			int sessioncount2 = 0;
			Date sessionStartDate = null;
			Date sessionEndDate1 = null;
			Date sessionEndDate2 = null;
			Date sessionLastTxnDate = null;
			lineNum++;
			writer.write(Utility.longTo24Hour(interval
					* data.interval / 1000)
					+ "\t");
			String startIntervel = Utility.longTo24Hour(interval
					* data.interval / 1000);
			startIntervel = data.date + s + startIntervel;
			
			interval = interval + 1;
			
			String endIntervel = Utility.longTo24Hour(interval
					* data.interval / 1000);
			endIntervel = data.date + s + endIntervel;
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date intervelStartDate = df.parse(startIntervel);
			Date intervelEndDate = df.parse(endIntervel);
			
			int debug = 0;
			if (Utility.longTo24Hour(interval * data.interval / 1000).equals("20:50:00")) {
				debug=1;
				System.out.println(startIntervel + " - " + endIntervel);
				System.out.println(Utility.longTo24HourTimeOnly(intervelStartDate.getTime()) + " - " + 
						Utility.longTo24HourTimeOnly(intervelEndDate.getTime()));
			}
			
			for (Iterator i = selecticaData.keySet().iterator(); i.hasNext();) {
				String keyValue = (String) i.next();
				SelecticaBO timeCals = (SelecticaBO) selecticaData
						.get(keyValue);
				
				ArrayList starts = timeCals.getStartTime();
				ArrayList ends = timeCals.getEndTime();
				
				for (int j = 0; j < starts.size(); j++) {
					
					sessionStartDate = (Date)starts.get(j);
					sessionEndDate1 = null;
					sessionEndDate2 = null;
					
					if (j < ends.size()) {
						sessionEndDate1 = (Date)ends.get(j);
						sessionEndDate2 = (Date)ends.get(j);
					}
					
					sessionLastTxnDate = timeCals.getLastTxnTime();
	
					if (sessionEndDate1 == null || sessionEndDate1.equals("")) {
						if (sessionLastTxnDate != null) {
							long timeinMs = sessionLastTxnDate.getTime();
							sessionEndDate1 = new Date(timeinMs + data.timeout1);
							sessionEndDate2 = new Date(timeinMs + data.timeout2);
						}
					}
					
					if (sessionStartDate != null && sessionEndDate1 != null) {
						
						if (intervelStartDate.before(sessionStartDate)
								&& intervelEndDate.after(sessionStartDate)) {
							sessionStartcount++;
							if (debug == 1) {
							System.out.println(Utility.longTo24HourTimeOnly(sessionStartDate.getTime()) + " - " + 
									Utility.longTo24HourTimeOnly(sessionEndDate1.getTime()));
							}
		
						}
						
						if (intervelStartDate.before(sessionEndDate1)
								&& intervelEndDate
										.after(sessionStartDate)) {
							sessioncount1++;
//							if (debug == 1) {
//								System.out.println(Utility.longTo24HourTimeOnly(sessionStartDate.getTime()) + " - " + 
//										Utility.longTo24HourTimeOnly(sessionEndDate1.getTime()));
//							}
		
						}
						
						if (intervelStartDate.before(sessionEndDate2)
								&& intervelEndDate
										.after(sessionStartDate)) {
							sessioncount2++;
						}	
					}
				}
			}
			writer.writeLine(sessioncount1 + "\t" + sessioncount2 + "\t" + sessionStartcount);
		}

		writer.writeLine("");
		writer.writeLine("");
		writer.writeLine("Duplicate Sessions:");
		int count = 0;
		
		for (Iterator i = selecticaData.keySet().iterator(); i.hasNext();) {
			String keyValue = (String) i.next();
			SelecticaBO timeCals = (SelecticaBO) selecticaData
					.get(keyValue);
			
			if (timeCals.getStartTime().size() > 1) {
				
				StringBuffer buffer = new StringBuffer();
				buffer.append(timeCals.getOrderNumber() + '\t' + timeCals.getStartTime().size());
				
				for (int j = 0; j < timeCals.getStartTime().size(); j++) {
					//System.out.println(j + " " + timeCals.getStartTime().size() + " " + timeCals.getEndTime().size());
					buffer.append('\t' + Utility.longTo24HourNoDate(((Date)timeCals.getStartTime().get(j)).getTime()) + '\t' + 
							(j >= timeCals.getEndTime().size() ? "" : Utility.longTo24HourNoDate(((Date)timeCals.getEndTime().get(j)).getTime())));
					count++;
					//System.out.println("6");
				}
				
				writer.writeLine( buffer.toString());

			}
		}
		writer.writeLine("");
		writer.writeLine("Duplicate Session\tTotal Sessions");
		writer.writeLine(count + "\t" + selecticaData.size());

		writer.writeLine("");
		writer.writeLine("Session");
		writer.writeLine("Min\tAvg\t90%\t80%\tMax");
		writer.writeLine(sessionLengthStats.getMinimum() + "\t" + sessionLengthStats.getAverage() + "\t" + 
				sessionLengthStats.getPercentile(.9) + "\t" + sessionLengthStats.getPercentile(.8) + "\t" + 
				sessionLengthStats.getMaximum());

	}

	public boolean processLine(String str, Object omfParameters) {

		if (str != null && str.length() > 50) {
			if (str.indexOf("beginSession ==") > 0) {
				processLineSeletica(str, omfParameters);
			} else if (str.indexOf("endSession ==") > 0) {
				processLineSeletica(str, omfParameters);
			} else if (str.indexOf("--submitToEngine") > 0) {
				processLineSeletica(str, omfParameters);
			}
		}

		return true;
	}

	protected void processLineSeletica(String aLine, Object omfParameters) {
		// use a second Scanner to parse the content of each line
		OmfParameters parms = (OmfParameters)omfParameters;
		
		words.setString(aLine);
		if (words.getWordCount() > 6) {
			String w1 = words.getWord(0);
			
			if (w1.startsWith(parms.date)) {  //Only process requested Date

				String time = words.getWord(1);
				time = Utility.replaceString(time, ",", ":");
				String orderId = words.getWord(5);
				if (orderId.length() != 8) {
					throw new RuntimeException("Invalid Order Id");
				}
				DateUtility du = new DateUtility(w1);   // parse date
				du.setTime24HourMillis(time);  			// parse time
				Date dt = du.getCalendar().getTime();
				
				if (aLine.indexOf("beginSession ==") > 0) {
					
					if (dt.after(parms.startTm) && dt.before(parms.endTm)) { 
						
						SelecticaBO timeCals = (SelecticaBO) selecticaData.get(orderId);
						if (timeCals != null) { 
							
							//If started then add one to count
							timeCals.addStartTime(dt);
						
						} else {
							SelecticaBO logstimecal = new SelecticaBO();
							logstimecal.setOrderNumber(orderId);
							logstimecal.addStartTime(dt);
							selecticaData.put(orderId, logstimecal);
						}
					}
					
				} else if (aLine.indexOf("endSession ==") > 0) {
					
					if (dt.after(parms.startTm) && dt.before(parms.endTm)) { 
						SelecticaBO timeCals = (SelecticaBO) selecticaData.get(orderId);
						if (timeCals == null) {
							SelecticaBO logstimecal = new SelecticaBO();
							logstimecal.setOrderNumber(orderId);
							logstimecal.addEndTime(dt);
							selecticaData.put(orderId, logstimecal);
							
						} else {
							timeCals.addEndTime(dt);
						}
					}
					
				} else if (aLine.indexOf("--submitToEngine") > 0) {
					
					if (dt.after(parms.startTm) && dt.before(parms.endTm)) { 
						SelecticaBO timeCals = (SelecticaBO) selecticaData.get(orderId);
						if (timeCals == null) {
							SelecticaBO logstimecal = new SelecticaBO();
							logstimecal.setOrderNumber(orderId);
							logstimecal.setLastTxnTime(dt);
							selecticaData.put(orderId, logstimecal);
						} else {
							timeCals.setLastTxnTime(dt);
						}
					}
					
				} 
			}
		}
		

		return;
	}


	public boolean recurse(File dirFile, Object data) {
		int i;
		String[] list;
		list = dirFile.list();
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				System.out.println("Processing: " + child.getName());
				try {
					setCurrentFile(child);
					fp = new FileProcessorWithData(child.getAbsolutePath(),
							line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: "
							+ child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();

			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;

	static BellSelecticaLogsAnalysisProcessor line = null;

	public static void main(String[] args) throws ParseException {
		if (args.length < 6 || args.length == 7) {

			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         session timeout1 (ms)");
			System.err.println("         session timeout2 (ms)");
			System.err.println("         start time (hh:mm:ss)");
			System.err.println("         end time (hh:mm:ss)");
			System.exit(-1);

		}
		
		OmfParameters parms = new OmfParameters(args[1], Integer
				.parseInt(args[2]), Long.parseLong(args[4]), Long.parseLong(args[5]));
		DateUtility du1 = new DateUtility(args[1]);
		DateUtility du2 = new DateUtility(args[1]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}
		if (args.length > 7) {
			line = new BellSelecticaLogsAnalysisProcessor(args[0], args[3],
					args[6], args[7]);
			du1.setTime24HourMillis(args[6]);
			parms.startTm = du1.getCalendar().getTime();
			du2.setTime24HourMillis(args[7]);
			parms.endTm = du2.getCalendar().getTime();

		} else {
			// System.out.println("args[0]"+args[0]+"args[3]"+args[1]);
			line = new BellSelecticaLogsAnalysisProcessor(args[0], args[3]);
			du1.setTime24HourMillis("00:00:00:000");
			parms.startTm = du1.getCalendar().getTime();
			du2.setTime24HourMillis("23:59:59:999");
			parms.endTm = du2.getCalendar().getTime();
		}
		
		line.setStartPath(f.getAbsolutePath());
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {
		}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * 
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}

	/**
	 * Sets the currentFile
	 * 
	 * @param currentFile
	 *            The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		// System.out.println("currentFile.getName()******"+currentFile);
		// this.currentServer = currentFile.getName().substring(1,3);
		// System.out.println("currentServer&&&&&&&"+currentServer);
	}

	/**
	 * Gets the startPath
	 * 
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}

	/**
	 * Sets the startPath
	 * 
	 * @param startPath
	 *            The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}
