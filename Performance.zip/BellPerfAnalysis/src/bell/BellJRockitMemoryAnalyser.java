package bell;
import com.followme.abastien.utilities.WordString;
import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.DateUtility;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.CopyFile;

import java.io.File;
import java.util.*;

class BellJRockitMemoryAnalyser extends LineProcessorWithData {

	private File currentFile;
	private boolean search1Found = false;
	private String extendsStr = null;
	private String startPath = "";
	private boolean search2Found = false;

	private ArrayList<String> data = new ArrayList<String>(100000);
	private String startsWith = "";
	private String dir = "";
	private DateUtility start = null;
	private long interval;

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");

	public BellJRockitMemoryAnalyser(String dir, String startsWith, int interval, String start, String end) {
		this.dir = dir;
		this.startsWith = startsWith.toUpperCase();
		this.interval = interval;
		this.minMs = Utility.time24HourMilliToLong(start);
		this.maxMs = Utility.time24HourMilliToLong(end);

	}

	public void print() {
		
		Integer iInterval = new Integer((int)(minMs / interval));
		int maxInterval = (int)(maxMs / interval);

		Collections.sort(data);
		
		StringWriter writer = new StringWriter(dir + File.separator + "gcSummary.tab");
		writer.open();
		

		int pos = 0;
		while (iInterval.intValue() <= maxInterval) {
			long msStart = iInterval.longValue()* interval;
			long msEnd = msStart + interval - 1;
			
			long ms = msEnd+100;
			String[] sTempData = null;
			DateUtility date;
			
			if (pos < data.size()) {
				sTempData = data.get(pos).split("<tab>");
				date = new DateUtility(sTempData[0]);
				ms = date.toLongTimeOnly();
			}
			while (ms < msStart) {
				pos++;
				if (pos < data.size()) {
					sTempData = data.get(pos).split("<tab>");
					date = new DateUtility(sTempData[0]);
					ms = date.toLongTimeOnly();
				} else {
					ms = msEnd+100;
				}
			}
		
			long sleepY = 0, sleepO = 0;
			while (ms <= msEnd) {
				
				String[] lineData = sTempData[1].split("\t");
				
				if (lineData.length > 3) {
					
					if (lineData[0].charAt(0) == 'Y') {
						sleepY += Long.parseLong(lineData[1]);
					} else {
						sleepO += Long.parseLong(lineData[2]);
					}
				}
				
				pos++;
				if (pos < data.size()) {
					sTempData = data.get(pos).split("<tab>");
					date = new DateUtility(sTempData[0]);
					ms = date.toLongTimeOnly();
				} else {
					ms = msEnd+100;
				}
			}

			writer.writeLine(Utility.longTo24Hour(iInterval.intValue()*interval/1000) + "\t" + sleepY + "\t" + sleepO);

			iInterval = new Integer(iInterval.intValue()+1);
		}

		writer.close();
		

		writer = new StringWriter(dir + File.separator + "gcData.tab");
		writer.open();
		
		for (int i = 0; i < data.size(); i++) {
			
			writer.writeLine(data.get(i).replaceAll("<tab>", "\t"));
			
		}
		
		writer.close();
		
	}

	public boolean processLine(String str, Object sessionData) {

		if (str.startsWith("[INFO ]")) {
			String[] lineData = str.split(": |\\[|\\] |\\]|, ");
//			for (int i = 0; i < lineData.length; i++) {
//				System.out.println(i + ":" + lineData[i]);
//			}
			
			if (lineData.length == 11) {
				String sTemp = lineData[6].split("-")[0];
				long timeMs = (long)(Float.parseFloat(sTemp) * 1000.0);
				
				if (start == null) {
					start = new DateUtility();
					start.zeroTime();
				}

				timeMs += start.toLong();
				DateUtility time = new DateUtility(timeMs);
				
				sTemp = lineData[8].split(" ")[0];
				long lengthMs = (long)(Float.parseFloat(sTemp) * 1000.0);
				
				String[] sTempData = lineData[7].split(" |KB->|KB|\\(");
				float before = Float.parseFloat(sTempData[1])/1024.0f;
				float after = Float.parseFloat(sTempData[2])/1024.0f;
				
				String type = lineData[5].substring(0, 2);
				
				if (type.charAt(0) == 'Y') {
					data.add(time.toTimeStringMillis() + "<tab>" + type + "\t" + lengthMs + "\t\t" + before + "\t" + after);
				} else {
					data.add(time.toTimeStringMillis() + "<tab>" + type + "\t\t" + lengthMs + "\t" + before + "\t" + after);
				}
			}
			
		} else {
			String[] lineData = str.split("<|> |>");
//			for (int i = 0; i < lineData.length; i++) {
//				System.out.println(i + ":" + lineData[i]);
//			}
			
			if (start == null && lineData.length == 8 && lineData[5].equals("NodeManager")) {
				String[] sTempData = lineData[1].split(" ");
				
				if (sTempData.length >= 5) {
					String sTemp = sTempData[3] + ' ' + sTempData[4];
					if (sTemp.length() == 10) {
						sTemp = "0" + sTemp;
					}
					start = new DateUtility(sTemp);
					data.add(start.toTimeStringMillis() + "<tab>SERVER START");
				}
				
			}
			
			if (lineData.length > 11) {
				int i = 10;
				String sDate = lineData[0];
				if (lineData[0].equals("####")) {
					
					i = 11;
					sDate = lineData[1];
					
				}
					
				if (lineData[i].equals("weblogic.GCMonitor")) {
					
					String sTemp = lineData[i+14].split(" ")[0];
					
					String[] sTempData = sDate.split(" ");
					
					if (sTempData.length >= 5) {
						String sTemp2 = sTempData[3] + ' ' + sTempData[4];
						if (sTemp2.length() == 10) {
							sTemp2 = "0" + sTemp2;
						}
						DateUtility time = new DateUtility(sTemp2);
						
						//data.add(time.toTimeStringMillis() + "<tab>PRCNT\t\t\t\t" + sTemp);
					}
					
				}
			}
			
		}


		return true;
	}

	private String buildTitle(String fileName) {
	
		String ret = fileName.substring(startPath.length()+1, fileName.length()-5);

		ret = Utility.replaceString(ret, File.separator, ".");
		
		int l = ret.lastIndexOf(".");
		
		String pkg = ret.substring(0, l);
		String cls = ret.substring(l+1);
		
		ret = pkg + "\t" + cls;
		
		if (extendsStr != null) {
			
			ret = ret + "\t" + extendsStr;
			
		}
		
		return ret;
		
	}
	
	public boolean printIfNeeded() {
		
		if (search1Found || search2Found) {
			
			String prt = buildTitle(currentFile.getAbsolutePath());
			
			if (search1Found) prt = prt + "\tRecComms";
			else prt = prt + "\t";
			
			if (search2Found) prt = prt + "\tSndComms";
			else prt = prt + "\t";

			System.out.println(prt);
			
			return true;
		}
		
		return false;
	}


	public boolean recurse(File dirFile) {
		int i;

		String[] list;
		list = dirFile.list();

		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);

			if (child.isFile()
				&& child.getName().toUpperCase().startsWith(startsWith)) {

				try {
					System.out.println(child.getName());
					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, null);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					return false;
				}

				fp.processFile();
				fp.close();
				
				if (line.printIfNeeded()) {
					
					//CopyFile.copy(child, copyToDir.getAbsoluteFile().getAbsolutePath(), null);
				}

			} else if (child.isDirectory()) {

				boolean ret = recurse(child);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;
	static BellJRockitMemoryAnalyser line = null;

	public static void main(String[] args) {

		
		if (args.length != 5) {
			System.out.println("You must specify:");
			System.out.println("\tdirectory");
			System.out.println("\tfile starts with");
			System.out.println("\tInterval");
			System.out.println("\tStart (HH:MM:SS:mmm)");
			System.out.println("\tEnd (HH:MM:SS:mmm)");
			System.exit(0);
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		line = new BellJRockitMemoryAnalyser(args[0], args[1], Integer.parseInt(args[2]), args[3], args[4]);
		
		line.setStartPath(f.getAbsolutePath());

		line.recurse(f);

		line.print();

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.search1Found = false;
		this.extendsStr = null;
		this.search2Found = false;
		this.currentFile = currentFile;
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}