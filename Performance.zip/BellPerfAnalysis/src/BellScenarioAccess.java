import java.util.ArrayList;
import java.util.Iterator;

import com.followme.abastien.utilities.Utility;

/*
 * Created on Jan 19, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class BellScenarioAccess {

	private String hoi;
	private ArrayList<Long> times = new ArrayList<Long>();
	private ArrayList<String> names = new ArrayList<String>();
	private String url;
	private String user;
	
	public BellScenarioAccess(String hoi) {
		this.hoi = hoi;
	}

	//BRS 34 Example:
	//  endTimeMs:   22:36:19,369
	//  Access Time: 22:36:19,367
	// BRS 35 will move access log to before first transaction Example:
	//  startTimeMs: 22:36:19,368
	//  Access Time: 22:36:19,365
	public String findRemoveScenarioName(long startTimeMs, long endTimeMs) {
		
		int count = -1;
		for (Iterator<Long> iterator = times.iterator(); iterator.hasNext();) {
			long time = iterator.next();
			count++;
			
//			if (endTimeMs >= time && endTimeMs <= (time+100)) {	//BRS 34.2-
			if (startTimeMs >= time && startTimeMs <= (time+100)) {	//BRS 35+
				
//			if ((endTimeMs >= time && endTimeMs <= (time+100)) ||			//BRS 34.2-
//					(startTimeMs >= time && startTimeMs <= (time+100))) {	//BRS 35+

						//				if (endTimeMs != time) {
//					String times = Utility.longTo24HourMilli(time);
//					String timesE = Utility.longTo24HourMilli(endTimeMs);
//					String timesS = Utility.longTo24HourMilli(startTimeMs);
//					int dd=0;
//					if (dd == 0) {}
//				}
				String name = names.get(count);
//				if (name.equals("Order Retrieve")) {
//					System.out.println("Order Retrieve TXN: "+time);
//				}
				names.remove(count);
				times.remove(count);
				
				return name;
			}
		}
		
		return null;
	}

	public void addScenario(String name, long timeMs) {

		names.add(name);
		times.add(timeMs);
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUser(String user) {
		
		if (user != null && user.length() > 0) {
			this.user = user;
		}
		
	}

	public String getUser() {
		return user;
	}
}
