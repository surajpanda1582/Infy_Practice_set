package com.followme.abastien.io;

import java.io.*;

public class StringWriterUTF8 {
	String ivFile;
	BufferedWriter ivBuff;
	PrintWriter ivPrint;

	public StringWriterUTF8(File file) {
		ivFile = file.getAbsolutePath();
	}
	
	public StringWriterUTF8(String name) {
		ivFile = name;
	}
	
	public PrintWriter getPrintWriter() {
		
		if (ivPrint == null) ivPrint = new PrintWriter(ivBuff);
		
		return ivPrint;
		
	}
	
	public void close() {
		try {
			if (ivPrint != null) ivPrint.close();
			ivBuff.close();
		} catch (IOException e) {}
	}
	
	public int open() {
		try {
			ivBuff = new BufferedWriter(new OutputStreamWriter( new FileOutputStream(ivFile), "UTF-8")); 
		} catch (IOException e) {
			System.err.println("Cannot open file:"+ivFile+" - "+e);
			return -1;
		}
		return 0;
	}
	
	public int openAppend() {
		try {
			ivBuff = new BufferedWriter(new OutputStreamWriter( new FileOutputStream(ivFile, true), "UTF-8")); 
		} catch (IOException e) {
			System.err.println("Cannot open file:"+ivFile+" - "+e);
			return -1;
		}
		return 0;
	}
	
	public void write(String data) {
		try {
			ivBuff.write(data);
		} catch (IOException e) {}
	}
	
	public void writeLine(String data) {
		try {
			ivBuff.write(data + "\r\n");
		} catch (IOException e) {}
	}
	
	public void flush() {
		try {
			ivBuff.flush();
		} catch (IOException e) {}
	}
}