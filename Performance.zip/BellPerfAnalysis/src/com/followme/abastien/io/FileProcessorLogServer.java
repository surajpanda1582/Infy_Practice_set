package com.followme.abastien.io;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.followme.abastien.utilities.DateUtility;
import com.followme.abastien.utilities.Utility;
//import com.ibm.jvm.dtfjview.commands.ExitCommand;

public class FileProcessorLogServer {
	
	private ArrayList<String> filenames = new ArrayList<String>();
	private String currentFile;
	private String nextLine;
	private FileReader fileIn;
	private BufferedReader dataIn;
	private String name;
	private int lineNumber;
	private boolean checkEndOfFile;
	private LineProcessorWithData ivLineProcessor;
	private Object data;
	private long openTime;

	public FileProcessorLogServer(String name) {
		this.name = name;
	}
	
	public void initialize(boolean checkEndOfFile, LineProcessorWithData ivLineProcessor, Object data) {
		this.checkEndOfFile = checkEndOfFile;
		this.ivLineProcessor = ivLineProcessor;
		this.data = data;

		readLine();
		
	}

	public String readLine() {
		
		String response = nextLine;
		boolean printTime = false;
		
		try {
			if (dataIn == null) {
				
				if (filenames.size() > 0) {
					
					boolean skip = false;
					
					File file = null;
					do {
						skip = false;
						currentFile = filenames.get(0);
						filenames.remove(0);
						lineNumber = 0;
						file = new File(currentFile);
						int p = currentFile.lastIndexOf(File.separator);
						if (p >= 0) {
							currentFile = currentFile.substring(p+1);
						}
						if (checkEndOfFile) {
							
							String[] lastFiveLines = Utility.tailFile(file, 5);
							for (int i = lastFiveLines.length-1; i >= 0; i--) {
								if (!ivLineProcessor.checkLastLines(lastFiveLines[i], data)) {
									skip = true;
									System.out.println("Skipping: " + currentFile);
									currentFile = null;
									break;
								}
							}
							
						}						
					} while (filenames.size() > 0 && skip);

					if (currentFile == null) {
						nextLine = null;
						return response;
					}
					
					System.out.print("Openning: " + currentFile);
					printTime = true;
					openTime = System.currentTimeMillis();
					
					fileIn = new FileReader(file);
					dataIn = new BufferedReader(fileIn);
					lineNumber = 0;
					
				} else {
					nextLine = null;
					return response;
				}
			}
			
			nextLine = dataIn.readLine();
			if (printTime && nextLine != null && nextLine.length() > 23) {
				System.out.println("\t" + nextLine.substring(0, 23));
			}
			
			if (nextLine == null) {
				nextLine = response;
				close();
				return readLine();
			}
			
		} catch (IOException e) {
			throw new RuntimeException("ERROR: Reading from file: " + currentFile, e);
		}
		
		//if (response != null && (response.indexOf("5-09-03 01:16:13") > 0 || response.indexOf("5-09-03 01:16:14") > 0) && response.indexOf("TranID-[L82L22V3]") > 0) {
		//	int dd = 0;
		//}
		
		lineNumber++;
		return response;
	}
	
	public void close() {
		
		try {
			if (dataIn != null) {
				if (openTime > 0) {
					System.out.println("     Finished: " + currentFile + " time: " + Utility.longTo24HourMilli(System.currentTimeMillis()-openTime));
				}
				dataIn.close();
				fileIn.close();
				dataIn = null;
				fileIn = null;
			}
		} catch (IOException ignored) {
			
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrentFile() {
		return currentFile;
	}
	
	public String getNextLine() {
		
		return nextLine;
	}
	
	public void addFile(String filename) {
		filenames.add(filename);
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public void skipFile() {
		int lines = getLineNumber();
		close();
		readLine();
		System.out.println("     Skipping Remainder: " + currentFile + " time: " + Utility.longTo24HourMilli(System.currentTimeMillis()-openTime) + " lines: " + lines);
		
	}

}
