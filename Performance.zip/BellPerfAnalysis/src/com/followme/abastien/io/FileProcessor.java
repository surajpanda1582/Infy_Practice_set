package com.followme.abastien.io;
import java.io.*;
import com.followme.abastien.utilities.DateUtility;

public class FileProcessor {
	FileReader ivFileIn;
	BufferedReader ivDataIn;
	LineProcessor ivLineProcessor;
	int ivLineCounter = 0;
	long ivLength, ivCurrent = 0l;

	public FileProcessor(String file, LineProcessor lineProcessor)
		throws IOException {
		ivLineProcessor = lineProcessor;

		ivLength = (new File(file)).length();
		
		ivFileIn = new FileReader(file);
		ivDataIn = new BufferedReader(ivFileIn);

		lineProcessor.ivFP = this;
	}

	public void processFile() {
		String str;
		
		long start = new DateUtility().getSecondsFromMidnight();

		while (true) {
			try {
				str = ivDataIn.readLine();
				if (str != null) {
					ivCurrent += str.length()+2;
					ivLineCounter++;
				}

//				if (ivLineCounter % 5000 == 0) {
//					
//					long percent = ivCurrent*1000/ivLength;
//					long decimal = percent - percent/10*10;
//					percent = percent/10;
//					
//					long current = new DateUtility().getSecondsFromMidnight();
//					long remaining = ((current - start) * ivLength / ivCurrent) - 
//							(current - start);
//					System.out.println(percent+"."+decimal+" "+Utility.longTo24Hour(remaining));
//					
//					ivLineCounter = 0;
//				}
				
			} catch (IOException e) {
//				System.out.println("");
				return;
			}

			if (str == null) {
//				System.out.println("");
				return;
			}

			try {
				if (!ivLineProcessor.processLine(str)) {
//					System.out.println("");
					return;
				}
			} catch (Exception e) {
				
				System.err.println("Exception at line "+ivLineCounter+":");
				System.err.println("str: '"+str+"'");
				e.printStackTrace();
				return;
			}
		}
	}

	public String readLine() {
		String str;

		try {
			str = ivDataIn.readLine();
		} catch (IOException e) {
			return "";
		}
		if (str == null)
			return "";

		return str;
	}

	public void close() {
		try {
			ivDataIn.close();
			ivFileIn.close();
		} catch (IOException e) {
			System.out.println("ERROR closing:" + e);
		}
	}

	//public String readLineByte() throws IOException
	//  {
	//  int i;
	//  byte b;
	//  StringBuffer rStr = new StringBuffer();
	//
	//  i = ivFileIn.read();
	//  b = (byte)i;
	//  while (b != '\n' && b != '\r' && i!=-1)
	//    {
	//    rStr.append(i);
	//    //rStr.append((char)b);
	//    rStr.append(new Character((char)i).charValue());
	//    rStr.append(' ');
	//    i = ivFileIn.read();
	//    b = (byte)i;
	//    }
	//
	//  i = ivFileIn.read();  //Reads newline char
	//
	//  return new String(rStr);
	//  }
}