
package com.followme.abastien.io;
public abstract class LineProcessor
{
  public FileProcessor ivFP;

  public abstract boolean processLine(String str);

  
}
