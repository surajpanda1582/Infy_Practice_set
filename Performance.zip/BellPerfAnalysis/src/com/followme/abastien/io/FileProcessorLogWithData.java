package com.followme.abastien.io;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.followme.abastien.utilities.DateUtility;

public class FileProcessorLogWithData extends FileProcessorWithData {
	
	ArrayList<FileProcessorLogServer> fileData = new ArrayList<FileProcessorLogServer>();
	HashMap<String, FileProcessorLogServer> servers;
	FileProcessorLogServer currentServer;

	public FileProcessorLogWithData(ArrayList<String> filenames, LineProcessorWithData lineProcessor, Object data) 
		throws IOException {
		
		this(filenames, lineProcessor, data, false); 
	}
	
	public FileProcessorLogWithData(ArrayList<String> filenames, LineProcessorWithData lineProcessor, Object data, boolean checkEndOfFile)
		throws IOException {
		
		super(filenames.get(0), lineProcessor, data, checkEndOfFile);
		
		initializeFiles(filenames);
	}

	/**
	 * processFile
	 * 
	 * @return Returns true if at least one line was processed correctly.
	 */
	public boolean processFile() {
		String str;
		int countLines = 0;
		
		while (true) {
			str = readLine();
				
			if (str != null) {
				countLines++;
				//System.out.println(getCurrentServer() + " - " + getCurrentFile() + " - " + getCurrentLine() + " - " + str.substring(0, 24));
			}
			
			if (str == null) {
//				System.out.println("");
				return countLines != 0;
			}

			try {
				if (!ivLineProcessor.processLine(str, data)) {
//					System.out.println("");
					currentServer.skipFile();
				} else {
					countLines++;
				}
			} catch (Exception e) {
				
				System.out.println("Exception at line "+getCurrentLine()+":");
				System.out.println("str: '"+str+"'");
				e.printStackTrace();
				return countLines != 0;
			}
		}
	}

	protected String readLine() {
		
		currentServer = null;
		
		for (String name : servers.keySet()) {
			FileProcessorLogServer server = servers.get(name);
			if (currentServer == null) {
				if (server.getNextLine() != null) {
					currentServer = server;
				}
			} else {
				
				if (server.getNextLine() != null && server.getNextLine().compareTo(currentServer.getNextLine()) < 0) {
					currentServer = server;
				}
			}
		}
		
		if (currentServer == null) {
			return null;
		}
		
		String response = currentServer.getNextLine();
		//if (response != null && (response.indexOf("5-09-03 01:16:13") > 0 || response.indexOf("5-09-03 01:16:14") > 0) && response.indexOf("TranID-[L82L22V3]") > 0) {
		//	int dd = 0;
		//}

		response =  currentServer.readLine();
		return response;
	}
	
	private void initializeFiles(ArrayList<String> filenames) {

		servers = new HashMap<String, FileProcessorLogServer>();
		int counter = 1;
		
		for (Iterator<String> iterator = filenames.iterator(); iterator.hasNext();) {
			String fileName = iterator.next();
			
			String serverEnd = null;
			if (fileName.charAt(0) == '*') {
				fileName = fileName.substring(1);
				serverEnd = String.valueOf(counter);
				counter++;
			}
			int p1 = fileName.lastIndexOf(File.separator);
			int p2 = fileName.lastIndexOf(".log");
			String serverName = fileName.substring(p1+1, p2);
			p1 = serverName.indexOf("_");
			if (p1 > 0) {
				serverName = serverName.substring(p1+1);
			}
			if (serverEnd != null) {
				serverName = serverName + "-" + serverEnd;
			}
			
			FileProcessorLogServer info = servers.get(serverName);
			if (info == null) {
				info = new FileProcessorLogServer(serverName);
				servers.put(serverName, info);
			}
				
			info.addFile(fileName);
				
		}
		
		for (String serverName : servers.keySet()) {
			FileProcessorLogServer server = servers.get(serverName);
			
			server.initialize(checkEndOfFile, ivLineProcessor, data);
		}
	}

	public String getCurrentFile() {
		if (currentServer != null) {
			return currentServer.getCurrentFile();
		} else {
			return null;
		}
	}
	
	public String getCurrentServer() {
		if (currentServer != null) {
			return currentServer.getName();
		} else {
			return null;
		}
	}
	
	public int getCurrentLine() {
		if (currentServer != null) {
			return currentServer.getLineNumber();
		} else {
			return 0;
		}
	}
	


}
