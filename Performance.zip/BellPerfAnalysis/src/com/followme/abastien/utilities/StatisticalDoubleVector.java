package com.followme.abastien.utilities;

import java.util.Vector;
import java.util.Collection;
import java.util.Collections;

public class StatisticalDoubleVector extends Vector {

	boolean sorted = false;
	Double average = null;
	Double total = null;
	
	public StatisticalDoubleVector (int i, int j) {
		
		super(i,j);
	}
	
	public boolean add(Object o) {
		
		if (o instanceof Double) {
			
			sorted = false;
			average = null;
			return super.add(o);
			
		} else {
			
			throw new RuntimeException("Wrong Object type for StatisticalDoubleVector");
		}
	}
	
	public void addElement(Object o) {
		
		if (o instanceof Double) {
			
			sorted = false;
			average = null;
			super.addElement(o);
			
		} else {
			
			throw new RuntimeException("Wrong Object type for StatisticalDoubleVector");
		}
	}
	
	public void add(int i, Object o) {
		
		if (o instanceof Double) {
			
			sorted = false;
			average = null;
			super.add(i, o);
			
		} else {
			
			throw new RuntimeException("Wrong Object type for StatisticalDoubleVector");
		}
	}
	
	public boolean addAll(Collection c) {
		
		sorted = false;
		average = null;
		return super.addAll(c);
	}
	
	public boolean add(double val) {
		
//		if (size() >= (capacity()-1)) {
//			throw new RuntimeException("Overflow: " + capacity());
//		}
		sorted = false;
		average = null;
		return super.add(new Double(val));
	}

	public double getMinimum() {

		int l = this.size();
		if (l == 0) return 0.0;
		
		sort();
		return ((Double)this.get(0)).doubleValue();
	}
	
	public double getMaximum() {

		int l = this.size();
		if (l == 0) return 0.0;
		
		sort();
		return ((Double)this.get(this.size()-1)).doubleValue();
	}
	
	public double getAverage() {

		if (average != null) return average.doubleValue();

		int l = this.size();
		if (l == 0) return 0.0;

		double total = 0.0;
		
		for (int i = 0; i < l; i++) 
			total += ((Double)this.get(i)).doubleValue();

		average = new Double(total/l);
		this.total = new Double(total);
				
		return total/l;
	}
	
	public double getTotal() {

		if (total != null && average != null) return total.doubleValue();

		int l = this.size();
		if (l == 0) return 0.0;

		double total = 0.0;
		
		for (int i = 0; i < l; i++) 
			total += ((Double)this.get(i)).doubleValue();

		this.total = new Double(total);
		average = new Double(total/l);
				
		return total;
	}
	
	public double getAverageOf90Percent() {

		int l = this.size();

		l = (int)Math.round(l * 0.9);
		
		if (l == 0) return 0.0;

		double total = 0.0;
		
		for (int i = 0; i < l; i++) { 
			total += ((Double)this.get(i)).doubleValue();
		}
		
		return total/l;
	}
	
	public double getStandardDeviationWholePopulation() {

		int l = this.size();
		if (l == 0) return 0.0;
		
		double total = 0.0;
		double value = 0.0;
		
		double average = getAverage();
		
		for (int i = 0; i < l; i++) {
			
			
			value = ((Double)this.get(i)).doubleValue()-average;
			value *= value;
			total += value;

		}
		
		total /= l;
		
		return Math.sqrt(total);
	}
	
	public double getStandardDeviationSample() {

		int l = this.size();
		if (l < 2) return 0.0;
		
		double total = 0.0;
		double value = 0.0;
		
		double average = getAverage();
		
		for (int i = 0; i < l; i++) {
			
			
			value = ((Double)this.get(i)).doubleValue()-average;
			value *= value;
			total += value;

		}
		
		total /= l-1;
		
		return Math.sqrt(total);
	}
	
	public double getMedian() {

		return getPercentile(.5);
	}
	
	public double getPercentile(double percentile) {
		
		int l = this.size();
		if (l < 1) return 0.0;
		if (l < 2) return ((Double)this.get(0)).doubleValue();
		
		sort();
		
		if (percentile < 0 || percentile > 1) 
			throw new RuntimeException("Invalid percentile in StatisticalDoubleVector");
		
		
		double i = ((l-1)*percentile);
		
		double val = 0;
		
		if ((int)i == i) {
			
			int ii = (int)i;
			val = ((Double)this.get(ii)).doubleValue();
			
		} else {
			
			int ii = (int)i;
			
			i -= ii;
			
			double v1 = ((Double)this.get(ii)).doubleValue();
			double v2 = ((Double)this.get(ii+1)).doubleValue();
			
			val = v1 + ((v2-v1)*i);
			
			
		}
		
		return val;
		
	}
	
	public double[][] getHistogram(double min, double max, int numValues) {
		
		int l = this.size();
		if (l < 2) return null;
		
		sort();
		
		int minLoc = 0;
		int maxLoc = l;
		double lastvalue = ((Double)get(0)).doubleValue();
		
		for (int i = 1; i < l; i++) {
			
			double thisvalue = ((Double)get(i)).doubleValue();

			if (lastvalue <= min && thisvalue > min) {
				
				minLoc = i-1;
			}

			if (lastvalue <= max && thisvalue > max) {
				
				maxLoc = i-1;
				break;
			}
			
			lastvalue = thisvalue;
		}
		
		double diff = (max-min)/(numValues-1);
		
		double[][] ret = new double[numValues+2][2];
		
		for (int i = 0; i < numValues+2; i++) {

			ret[i][0] = min + (diff * (i-1.0));
			ret[1][1] = 0;
		}				
		ret[numValues+1][0] = Double.MAX_VALUE;
		
		double currValue = ret[0][0]+(diff/2);
		int loc = 0;
		int count = 0;

		for (int i = 0; i < l; i++) {

			double thisvalue = ((Double)get(i)).doubleValue();

			if (thisvalue < currValue || loc == numValues+1) {
				
				count++;
				
			} else {
				
				ret[loc][1] = count;

				for (int j = loc+1; j < numValues+2; j++) {
					
					if (j < numValues+1) {
						
						currValue = ret[j][0]+(diff/2);

					}
										
					if (thisvalue < currValue || j == numValues+1) {
						
						count = 1;
						loc = j;
						break;
					}
				}

			}
			
		}

		ret[loc][1] = count;

		return ret;
	}	
	
	public void sort() {
		
		if (sorted) return;
		
		Collections.sort(this);
		sorted = true;
		
	}

	public static void main(String[] args) {
		
		StatisticalDoubleVector values = new StatisticalDoubleVector(100, 100);
		
		values.add(1);
		values.add(2);
		values.add(8);
		values.add(9);
		values.add(10);
		values.add(15);
		values.add(16);
		values.add(7);
		values.add(20);
		values.add(4);
		values.add(11);
		
		double percentile = .1;
		System.out.println(percentile + " -> "+values.getPercentile(percentile));

		System.out.println("Median -> "+values.getMedian());

		percentile = .80;
		System.out.println(percentile + " -> "+values.getPercentile(percentile));

		percentile = .90;
		System.out.println(percentile + " -> "+values.getPercentile(percentile));

		System.out.println("Minimum -> "+values.getMinimum());
		System.out.println("Maximum -> "+values.getMaximum());
		System.out.println("Average -> "+values.getAverage());
		System.out.println("Std Dev whole -> "+values.getStandardDeviationWholePopulation());
		System.out.println("Std Dev sample -> "+values.getStandardDeviationSample());

		double[][] hist = values.getHistogram(5, 15, 3);
		
		System.out.println("Histogram");
		for (int i = 0; i < hist.length; i++) {
			
			System.out.println(hist[i][0]+"    "+hist[i][1]);
			
		}
	}

}

