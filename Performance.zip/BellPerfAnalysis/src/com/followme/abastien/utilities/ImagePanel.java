package com.followme.abastien.utilities;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Dimension;
import java.awt.Color;

/**
 * This type was created in VisualAge.
 * @modelguid {721DE95A-7703-4F69-8F41-EA810C6AB423}
 */
public class ImagePanel extends java.awt.Panel {
	/** @modelguid {BD8F1154-A192-4DF9-BC0C-51636077C1CB} */
	private java.awt.Image image = null;

	/** @modelguid {168D1382-509D-4718-B770-C2C0A3331893} */
	private java.awt.Image scaledImage = null;

	/** @modelguid {F0F3712B-A1B4-428A-8764-C741BED634B4} */
	private String filename;

	/** @modelguid {B9895898-0445-48B6-8275-5986BB99622E} */
	private Dimension preferredSize = null;
	/**
	 * ImagePanel constructor comment.
	 * @modelguid {6A3E0424-B201-4BEE-95C1-2321812280AE}
	 */
	public ImagePanel() {
		super();
	}

	/** @modelguid {2D997EA8-D4B7-40A6-9DF8-B74843BC1DC3} */
	public ImagePanel(Image image) {
		super();
		this.setImage(image);
	}

	/** @modelguid {04DCC860-D499-4CCA-A972-D59D029A4DBC} */
	public ImagePanel(String filename, Image image, int width, int height) {
		super();
		this.setImage(image);
		preferredSize = new Dimension(width, height);
		this.filename = filename;
	}

	/** @modelguid {F6F54889-C25B-40F0-BD7E-7239088AB67E} */
	public Dimension getPreferredSize() {

		if (preferredSize == null) {

			return super.getPreferredSize();
			
		} else {

			return preferredSize;
		}
	}

	/** @modelguid {D170421D-4A84-475F-BED1-55E6B376D153} */
	public void setColour(Color colour) {

		this.setBackground(colour);
	}

	/**
	 * ImagePanel constructor comment.
	 * @param layout java.awt.LayoutManager
	 * @modelguid {28861C29-3863-48C2-B3DC-C11D63525145}
	 */
	public ImagePanel(java.awt.LayoutManager layout) {
		super(layout);
	}
	/**
	 * This method was created in VisualAge.
	 * @return java.awt.Image
	 * @modelguid {7B8CC431-42FB-4200-8D1E-D3990B7D5547}
	 */
	public java.awt.Image getImage() {
		return image;
	}
	
	public boolean equals(Object o) {

		if (getFilename() == null) return this == o;
		
		if (o instanceof ImagePanel) {
		
			return getFilename().equals(((ImagePanel)o).getFilename());
		} 
		
		return false;
		
	}
	
	/**
	 * This method was created in VisualAge.
	 * @param g Graphics
	 * @modelguid {08550AB2-6F96-4FE5-BB77-4D7ED79EFB5E}
	 */
	public void paint(Graphics g) {
		int h, w, h2, w2;
		float ratioI, ratioS;
		java.awt.Rectangle rect = getBounds();
		g.setColor(java.awt.Color.white);
		g.clearRect(rect.x, rect.y, rect.width, rect.height);
		
		if (scaledImage != null) {
			int counter = 0;
			
			while ((w = scaledImage.getWidth(this)) < 0 && counter < 500) {
				
				try {
					
					counter++;
					Thread.sleep(10);
					
				} catch (InterruptedException ignored) {}
				
			}
			
			while ((h = scaledImage.getHeight(this)) < 0);
			//needs scaling up or down
			if (w != rect.width && h != rect.height) {
				while ((w2 = image.getWidth(this)) < 0);
				while ((h2 = image.getHeight(this)) < 0);
				ratioI = (float) h2 / (float) w2;
				ratioS = (float) rect.height / (float) rect.width;
				if (ratioI < ratioS)
					scaledImage = image.getScaledInstance(rect.width, -1, Image.SCALE_FAST);
				else
					scaledImage = image.getScaledInstance(-1, rect.height, Image.SCALE_FAST);
			}
			g.drawImage(scaledImage, -1, -1, this);
		}
	}
	/**
	 * This method was created in VisualAge.
	 * @param newValue java.awt.Image
	 * @modelguid {259F5F48-D11A-4056-B671-BCD768DCC7DC}
	 */
	public void setImage(java.awt.Image newValue) {
		this.image = newValue;
		this.scaledImage = newValue;
	}
	/**
	 * Gets the filename
	 * @return Returns a String
	 * @modelguid {64779922-3C26-47AF-BA99-B0A3A243D2F6}
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * Sets the filename
	 * @param filename The filename to set
	 * @modelguid {3DF01CD7-DAB5-402F-9CCB-694FA4FF0DA4}
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

}