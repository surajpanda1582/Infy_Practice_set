package com.followme.abastien.utilities;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.GregorianCalendar;

public class CSVReader {
	// Attributes
	private String fileName;

	private FileReader reader;

	private BufferedReader input;

	private String[] columns;

	private int numColumns;

	private boolean isOpen = false;

	private String line;
	
	private char separaterCh = ',';
	
	public String getLine() {
		return line;
	}
	// Constructors
	public CSVReader(char separator) {

		separaterCh = separator;

		columns = new String[500];
	}

	// Constructors
	public CSVReader() {

		columns = new String[500];
	}

	public CSVReader(long l) {
		if (l != 96847764743L) throw new RuntimeException("Invalid Usage Code");

		columns = new String[500];
	}
	public void close() {
		try {
			input.close();
			reader.close();
		} catch (IOException e) {
		}
	}

	public String getColumn(int num) {
		return columns[num];
	}

	public GregorianCalendar getColumnAsCalendar(int num) {

		return new DateUtility(columns[num]).getCalendar();
	}

	public int getColumnAsInt(int num) {
		return Integer.parseInt(columns[num]);
	}

	public int[] getColumnAsIntArray(int num) {
		int i, l, j;
		int[] cols, ret;
		String sRecord = columns[num];
		StringBuffer column;
		cols = new int[500];
		column = new StringBuffer();
		j = 0;
		l = sRecord.length();
		if (l > 0) {
			for (i = 0; i < l; i++) {
				if (sRecord.charAt(i) == separaterCh) {
					cols[j] = Integer.parseInt(column.toString());
					j++;
					column.setLength(0);
				} else {
					column.append(sRecord.charAt(i));
				}
			}
			if (column.length() > 0) {
				cols[j] = Integer.parseInt(column.toString());
				j++;
			}
		}
		if (j == 0)
			return null;
		ret = new int[j];
		for (i = 0; i < j; i++)
			ret[i] = cols[i];
		return ret;
	}

	public int getNumberOfColumns() {
		return numColumns;
	}

	/**
	 * This method was created in VisualAge.
	 * 
	 * @param args
	 *            java.lang.String[]
	 */
	public static void main(String args[]) {
		int i;
		int[] ia;
		GregorianCalendar gc;

		CSVReader cs = new CSVReader();
		if (cs.open("c:\\temp\\test2.csv")) {
			while (cs.readRecord()) {
				System.out.println("--------");
				System.out.println(cs.getNumberOfColumns());
				System.out.println(cs.getColumnAsInt(0));
				ia = cs.getColumnAsIntArray(1);
				for (i = 0; i < ia.length; i++)
					System.out.println(ia[i]);
				System.out.println(cs.getColumn(2));
				gc = cs.getColumnAsCalendar(3);
				System.out.println(gc.get(GregorianCalendar.YEAR));
				System.out.println(gc.get(GregorianCalendar.MONTH) + 1);
				System.out.println(gc.get(GregorianCalendar.DATE));
				System.out.println("--------");
			}
			cs.close();
		}
	}

	// Methods
	public boolean open(String name) {
		if (isOpen) {
			close();
			isOpen = false;
		}
		try {
			reader = new FileReader(name);
			input = new BufferedReader(reader);
		} catch (IOException e) {
			return false;
		}
		isOpen = true;
		return true;
	}

	private String readLine() {
		String ret;
		try {
			ret = input.readLine();
			line = line + "|" + ret;
		} catch (IOException e) {
			return null;
		}

		return ret;
	}

	public boolean readRecord() {
		int i, l;
		boolean inQuote;
		boolean inComma;
		StringBuffer column;
		String sRecord;
		boolean done;
		done = false;

		sRecord = readLine();
		line = sRecord;
		if (sRecord == null)
			return false;

		// Blank record is skipped
		while (sRecord.trim().length() == 0) {
			sRecord = readLine();
			if (sRecord == null)
				return false;
		}

		column = new StringBuffer(255);
		inQuote = false;
		inComma = true;
		numColumns = 0;
		char ch;
		while (!done) {
			l = sRecord.length();
			for (i = 0; i < l; i++) {
				ch = sRecord.charAt(i);
				if (ch == '\"') {
					if (l > i + 1 && sRecord.charAt(i + 1) == '\"') {
						column.append(ch);
						i++;
					} else
						inQuote = !inQuote;
				} else if (ch == separaterCh) {
					if (inQuote) {
						column.append(ch);
					} else {
						inComma = true;
						if (column.length() == 1 && column.charAt(0) == '\"')
							column.setLength(0);
						columns[numColumns] = column.toString();
						numColumns++;
						column.setLength(0);
					}
				} else {
					inComma = false;
					column.append(ch);
				}
			}
			if (inQuote) {
				sRecord = readLine();
				column.append('\n');
			} else {
				done = true;
				if (column.length() > 0 || inComma) {
					if (column.length() == 1 && column.charAt(0) == '\"')
						column.setLength(0);
					columns[numColumns] = column.toString();
					numColumns++;
				}
			}
		}
		return true;
	}

	public boolean getColumnAsBoolean(int num) {

		if ("TRUE".equalsIgnoreCase(columns[num]))
			return true;
		if ("FALSE".equalsIgnoreCase(columns[num]))
			return false;

		System.out.println("Warning: unknown text in boolean column: "
				+ columns[num]);
		return false;

	}

	public DateUtility getColumnAsDate(int num) {
		return new DateUtility(columns[num]);
	}

	public long getColumnAsLong(int num) {
		return Long.parseLong(columns[num]);
	}

	public int getNumColumns() {
		return numColumns;
	}

	public String[] getRecords() {

		String[] ret = new String[numColumns];

		for (int i = 0; i < numColumns; i++) {
			ret[i] = columns[i];
		}

		return ret;
	}
}