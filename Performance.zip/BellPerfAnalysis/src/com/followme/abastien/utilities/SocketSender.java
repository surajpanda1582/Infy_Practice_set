package com.followme.abastien.utilities;

import java.io.*;
import java.net.*;

public class SocketSender {

	private int port;
	private String address;
	
	public SocketSender( String address, int port ) {
	
		this.port = port;
		this.address = address;
	
	}
	

	public byte[] send( byte[] data ) throws IOException {

		StringBuffer sb = new StringBuffer();
		ServerSocket ser = null;
		byte[] buffer = new byte[1024];

		Socket soc = new Socket(address, port);

		InputStream is = soc.getInputStream();
		
		OutputStream os = soc.getOutputStream();

		os.write(data);

		int num = 0;
		sb.setLength(0);
		
		do {
			
			num = is.read(buffer);
			for (int i=0; i<num; i++) {
				sb.append((char)buffer[i]);
			}
			
		} while (num > 0);
		
		//os.close();
		//is.close();
		soc.close();
		
		return (sb.toString().getBytes());
	}
	

	public static void main(String args[]) {
	
		SocketSender sender = new SocketSender("localhost", 5555);
		
		System.out.println("Sending...");
		try {
			//System.out.println("Reply:"+Utility.toString(sender.send("sendplc a1 on".getBytes())));
			System.out.println("Reply:"+Utility.toString(sender.send("CMD_FC A1 OFF".getBytes())));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.exit(0);
	}
	
}



