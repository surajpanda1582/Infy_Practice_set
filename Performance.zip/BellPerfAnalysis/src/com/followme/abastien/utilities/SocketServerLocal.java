package com.followme.abastien.utilities;

import java.io.*;
import java.net.*;


public class SocketServerLocal extends Thread {

	private int port;
	private int readPort;
	private SocketListener listener;
	
	public SocketServerLocal( SocketListener listener, int port, int readPort ) {
	
		this.port = port;
		this.readPort = readPort;
		this.listener = listener;
	
	}
	public void run() {

		ServerSocket ser = null;
		Socket soc = null;
		StringBuffer sb = new StringBuffer();
		byte[] buffer = new byte[1024];
   
    try {
		
			ser = new ServerSocket(readPort);

			while (true) {

				soc = ser.accept();
				
				InetAddress replyAddr = soc.getInetAddress();
				
				InputStream is = soc.getInputStream();
				
				int num = 0;
				sb.setLength(0);
				
				do {
					
					num = is.read(buffer);
					for (int i=0; i<num; i++) {
						sb.append((char)buffer[i]);
					}
					
				} while (num > 0);

				
				byte[] reply = listener.processData(sb.toString().getBytes());
				
				is.close();
				soc.close();

				soc = new Socket(replyAddr, port);
	
				OutputStream os = soc.getOutputStream();
	
				os.write(reply);
				os.close();
				soc.close();
				

			}
			
		} catch (Exception e) {

     	System.out.println(e);
			System.exit(1);

		}
  }
}
