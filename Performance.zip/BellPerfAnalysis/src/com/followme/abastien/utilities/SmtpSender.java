/*
package com.followme.abastien.utilities;
import java.util.Properties;
import java.util.Date;

import javax.mail.*;
import javax.mail.internet.*;

public class SmtpSender {

	public static void main(String[] argv) {

		String ret = send("ajbastien@rogers.com", "ajbastien@rogers.com",
				"smtp.mtmk.phub.net.cable.rogers.com", "user", "password", "subject", "body");

		if (ret == null) 
			System.out.println("Message Sent");
		else 
			System.out.println("Error: "+ret);

	}

	public static String send(String to, String from, String host, 
			String user, String password, String subject, 
			String body) {

		String mailer = "JX10HMON";

		boolean debug = false;

		try {

			if (debug) System.out.println("To: " + to);
			if (debug) System.out.println("Subject: " + subject);

			Properties props = System.getProperties();
			props.put("mail.smtp.host", host);
			if (password == null || password.length() == 0) {
				
				props.put("mail.smtp.ehlo", "false");
				props.put("mail.smtp.auth", "false");
				
			} else {
				
				props.put("mail.smtp.ehlo", "true");
				props.put("mail.smtp.auth", "true");
				
			}
			
			// Get a Session object
			Session session = Session.getDefaultInstance(props, null);
			if (debug)
				session.setDebug(true);

			// construct the message
			Message msg = new MimeMessage(session);
			if (from != null)
				msg.setFrom(new InternetAddress(from));
			else
				msg.setFrom();

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));

			msg.setSubject(subject);

			msg.setText(body);

			msg.setHeader("X-Mailer", mailer);
			msg.setSentDate(new Date());

			Transport tr = session.getTransport("smtp");
			tr.connect(host, user, password);

			tr.sendMessage(msg, msg.getAllRecipients());
			
			tr.close();

			if (debug) System.out.println("\nMail was sent successfully.");

		} catch (Exception e) {
			
			if (debug) e.printStackTrace();
			
			return e.toString();
		}
		
		return null;
	}

}*/