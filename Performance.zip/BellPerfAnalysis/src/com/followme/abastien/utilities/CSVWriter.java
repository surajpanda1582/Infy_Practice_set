package com.followme.abastien.utilities;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.GregorianCalendar;

public class CSVWriter
{
  // Attributes
  private String                    fileName;
  private FileWriter                writer;
  private BufferedWriter            output;
  private String[]                  columns;
  private int                       numColumns;
  private boolean                   isOpen = false;

// Constructors
public CSVWriter(long usageCode) {
	if (usageCode != 96847764743L) throw new RuntimeException("Invalid Usage Code");

	columns = new String[500];
}

public CSVWriter() {

	columns = new String[500];
}

public void add(int[] values)
{
	int i;
	StringBuffer sb = new StringBuffer(30);
	if (values == null || values.length == 0)
	{
		columns[numColumns] = "";
	}
	else
	{
		sb.append('\"');
		for (i = 0; i < values.length; i++)
		{
			if (i > 0)
				sb.append(',');
			sb.append(values[i]);
		}
		sb.append('\"');
		columns[numColumns] = sb.toString();
	}
	numColumns++;
}
public void add(int value)
{
	columns[numColumns] = String.valueOf(value);
	numColumns++;
}
public void add(String value)
{
	int i;
	if (value == null) value = new String("");
	if (value.indexOf("\"") >= 0 || value.indexOf("\n") >= 0 || value.indexOf("\r") >= 0)
	{
		StringBuffer sb = new StringBuffer(50);
		for (i = 0; i < value.length(); i++)
		{
			sb.append(value.charAt(i));
			if (value.charAt(i) == '\"')
				sb.append('\"');
		}
		value = sb.toString();
	}
	if (value.length()>0) value = "\"" + value + "\"";
	columns[numColumns] = value;
	numColumns++;
}
public void add(GregorianCalendar value)
{
	DateUtility du = new DateUtility(value);
	columns[numColumns] = du.toString();
	numColumns++;
}
public void close()
{
	try
	{
		output.close();
		writer.close();
	}
	catch (IOException e)
	{
	}
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[]) 
{
	int i;
	int ia[] = new int[5];
	CSVWriter cs = new CSVWriter(96847764743L);
	if (cs.open("c:\\temp\\test2.csv"))
	{
		for(i=0; i<3; i++)
		{
			ia[i] = i+1;
			cs.add(i);
			cs.add(ia);
			cs.add("line1\nline2");
			cs.add(new GregorianCalendar());
			cs.writeRecord();
		}
	cs.close();
	}
}
// Constructors

// Methods
public boolean open(String name)
{
	if (isOpen)
	{
		close();
		isOpen = false;
	}
	try
	{
		writer = new FileWriter(name);
		output = new BufferedWriter(writer);
	}
	catch (IOException e)
	{
		try
		{
			if (writer != null) writer.close();
			return false;
		}
		catch (IOException e2)
		{
		}
	}
	isOpen = true;
	return true;
}

public boolean writeRecord()
{
	int i;

	if (output == null) throw new RuntimeException("Cannot write to CSV");
	
	StringBuffer sb = new StringBuffer(255);
	for (i = 0; i < numColumns; i++)
	{
		if (i > 0)
			sb.append(',');
		sb.append(columns[i]);
	}
	sb.append("\r\n");
	numColumns = 0;
	try
	{
		output.write(sb.toString());
	}
	catch (IOException e)
	{
		throw new RuntimeException("Cannot write to CSV");
	}
	return true;
}

public boolean writeHeader(String header)
{
	int i;

	if (output == null) return false;
	
	try {
		output.write(header+"\r\n");

	}
	catch (IOException e)
	{
		return false;
	}

	return true;
}

public void emptyRecord()
{
	numColumns = 0;
}

public void add(long value)
{
	columns[numColumns] = String.valueOf(value);
	numColumns++;
}

public void add(double value)
{
	columns[numColumns] = String.valueOf(value);
	numColumns++;
}

public void add(DateUtility value)
{

	if (value == null)
		columns[numColumns] = "null";
	else
		columns[numColumns] = value.toString();
		
	numColumns++;
	
}

public void add(boolean value)
{
	columns[numColumns] = String.valueOf(value);
	numColumns++;
}
}