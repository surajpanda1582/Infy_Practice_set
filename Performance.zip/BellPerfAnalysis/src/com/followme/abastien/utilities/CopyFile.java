package com.followme.abastien.utilities;

import java.io.*;
/**
 * This type was created in VisualAge.
 */
public class CopyFile {
	static private FileWriter writer;
	static private BufferedWriter bwriter;
	static private FileOutputStream output;
	static private BufferedOutputStream boutput;
	static private FileInputStream input;
	static private BufferedInputStream binput;
	
	public static boolean move(File file, String toLoc) {

		if (file == null) return false;
		
		String parent = file.getParent();
		if (parent == null) return false;
		
		if (parent.equals(toLoc)) return true;

		if (copy(file, toLoc, null)) {
		
			if (!file.delete()) {
			
				System.err.println("Cannot delete file: "+file.getAbsoluteFile());
				
				return false;
					
			}
		}
		
		return true;
	}

	/**
	 * Copies files and subdirectories to a new location
	 * @param file java.io.File is the file or directory to copy
	 * @param toLoc java.lang.String the location to copy to
	 */
	public static boolean copy(File file, String toLoc, String outFileName) {
		String outfile;

		if (!file.exists()) {
			
				System.err.println("File does not exist: "+file.getAbsoluteFile());
				
				return false;

		}
		
		if (outFileName == null) outFileName = file.getName();
		
		if (file.getAbsoluteFile().getParent().equals(toLoc)) return true;

		if (file.isDirectory()) {
			int i;
			String[] list;
			String nToLoc = "";
			list = file.list();
			for (i = 0; i < list.length; i++) {
				File child = new File(file, list[i]);
				nToLoc = toLoc;
				if (child.isDirectory()) {
					if (toLoc.endsWith(File.separator))
						nToLoc = toLoc + list[i];
					else
						nToLoc = toLoc + File.separator + list[i];
				}
				copy(child, nToLoc, outFileName);
			}
		} else {
			File toFile = new File(toLoc);
			toFile.mkdirs();
			if (toLoc.endsWith(File.separator))
				outfile = toLoc + outFileName;
			else
				outfile = toLoc + File.separator + outFileName;
			try {
				int sz = (int) file.length();
				input = new FileInputStream(file);
				binput = new BufferedInputStream(input, 1024);
				output = new FileOutputStream(outfile);
				boutput = new BufferedOutputStream(output, 1024);
				byte[] buf = new byte[1024];
				int ln = 0;
				while (sz > 0
					&& (ln = binput.read(buf, 0, Math.min(1024, sz))) != -1) {
					boutput.write(buf, 0, ln);
					sz -= ln;
				}
				binput.close();
				input.close();
				boutput.close();
				output.close();
			} catch (Exception e) {
				System.out.println(e);
				return false;
			}
		}
		return true;
	}
	/**
	 * This method was created in VisualAge.
	 * @param args java.lang.String[]
	 */
	public static void copyThumbs(String args[]) {
		File fl = new File("D:\\");
		try {
			writer =
				new FileWriter("c:\\personal\\com\\followme\\abastien\\photo_organizer\\copyfiles.bat");
			bwriter = new BufferedWriter(writer);
		} catch (IOException e) {
		}
		process(
			fl,
			"c:\\personal\\com\\followme\\abastien\\photo_organizer\\Thumbs\\VACATIONS");
		try {
			output.close();
			writer.close();
		} catch (IOException e) {
		}
	}
	/**
	 * This method was created in VisualAge.
	 * @param dir java.lang.String
	 * @param dirName java.lang.String
	 */
	static public void copyThumbs(File dirFile, String dirName) {
		int i;
		String[] list;
		list = dirFile.list();
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			if (child.isFile()) {
				try {
					bwriter.write(
						"xcopy \""
							+ child.toString()
							+ "\" \""
							+ dirName
							+ "\\\"\r\n");
				} catch (IOException e) {
				}
			}
		}
	}
	/**
	 * This method was created in VisualAge.
	 * @param args java.lang.String[]
	 */
	public static void main(String args[]) {
		boolean brc;
		File fl = new File("C:\\temp\\todos.txt");
		String toLoc = "C:\\temp2\\temp";
		brc = copy(fl, toLoc, null);
		System.out.println(brc);
	}
	/**
	 * This method was created in VisualAge.
	 * @param dir java.lang.String
	 * @param dirName java.lang.String
	 */
	static public void process(File dirFile, String dirName) {
		int i;
		String[] list;
		list = dirFile.list();
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			if (child.isDirectory()) {
				String nDir = dirName + "\\" + list[i];
				process(child, nDir);
				if (list[i].toUpperCase().equals("THUMBS")) {
					copyThumbs(child, dirName);
				}
			}
		}
	}
}