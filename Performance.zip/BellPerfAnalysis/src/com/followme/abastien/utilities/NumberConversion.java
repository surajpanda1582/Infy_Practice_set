/*
 * Created on May 18, 2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.followme.abastien.utilities;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/**
 * @author ABastien
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class NumberConversion {

	public static final void swapEndianness(byte abyte0[], int i, int j) {
		int k = 0;
		int l = j - 1;
		int i1 = j / 2;
		int j1 = i1;
		for (; k < i; k++) {
			byte byte0 = abyte0[k];
			abyte0[k] = abyte0[l];
			abyte0[l] = byte0;
			l--;
			if (--j1 <= 0) {
				j1 = i1;
				k += i1;
				l = k + j;
			}
		}
	}

	private static final String dump(byte abyte0[]) {
		return HexDump.dump(abyte0);
	}

	public static void main(String args[]) {
		int ai[] = { 1, 2, 4, 8 };
		byte abyte0[] =
			{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
		for (int i = 0; i < ai.length; i++) {
			int j = ai[i];
			System.out.println("swapEndianness: wordLength = " + j);
			System.out.print("Before: " + dump(abyte0));
			swapEndianness(abyte0, abyte0.length, j);
			System.out.print("After:  " + dump(abyte0));
			swapEndianness(abyte0, abyte0.length, j);
			System.out.print("Back:   " + dump(abyte0));
			System.out.println();
		}
		
		double db = 44.93128333333333;
		
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream(8);
		DataOutputStream dataByteOut = new DataOutputStream(byteOut);

		try {
			dataByteOut.writeDouble(db);
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte[] bytes = byteOut.toByteArray();

//		  byte b;
//
//		  for (int i = 0; i<4; i++)
//			{
//			b = bytes[i];
//			bytes[i] = bytes[8-i-1];
//			bytes[8-i-1] = b;
//			}
	
		swapEndianness(bytes, 8, 8);

		ByteArrayInputStream byteIn = new ByteArrayInputStream(bytes);
		DataInputStream dataByteIn = new DataInputStream(byteIn);
		
		double db2 = 0;
		try {
			db2 = dataByteIn.readDouble();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		System.out.println(db + " -> " + db2);

	}
}
