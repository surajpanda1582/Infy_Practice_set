/*
 * Created on May 13, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.followme.abastien.utilities;

import java.util.HashMap;

public class CSVReaderHeading extends CSVReader {

	/**
	 * @param separator
	 */
	public CSVReaderHeading(char separator) {
		super(separator);
		
	}

	private HashMap headings = new HashMap();
	
	public CSVReaderHeading() {
		super();
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		CSVReaderHeading reader = new CSVReaderHeading();

		reader.open("C:\\temp\\t\\VC_PRODUCT_COMPLETE.csv");
		
		reader.readRecord();
		System.out.println(reader.getColumn("CATEGORY_NAME_ID"));
		
	}

	public boolean open(String name) {
		if (super.open(name)) {
			if (readRecord()) {
				
				for (int i = 0; i < getNumberOfColumns(); i++) {
					headings.put(getColumn(i).trim().toUpperCase(), new Integer(i));
				}
				
			} else {
				return false;
			}
			
			return true;
		} else {
			return false;
		}
	}
	
	public String getColumn(String name) {
		
		Integer col = (Integer)headings.get(name.toUpperCase());
		
		if (col == null) {
			return null;
		}
		
		return getColumn(col.intValue()).trim();
	}

	public int getColumnNumber(String name) {
		
		Integer col = (Integer)headings.get(name.toUpperCase());
		
		if (col == null) {
			return -1;
		}
		
		return col.intValue();
	}



}
