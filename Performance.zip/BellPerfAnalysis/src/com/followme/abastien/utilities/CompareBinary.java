package com.followme.abastien.utilities;

import java.io.*;

public class CompareBinary 
{

	public static void main(String args[]) 
	{
		File f, f2;
		DataInputStream is, is2;
		long pos = 0;
		boolean diff = false;
		
		try 
		{
			f = new File("C:\\PALM\\BastieA\\address\\address.dat");
			f = new File("C:\\PALM\\BastieA\\address\\SynchedAddress.dat");
			is = new DataInputStream(new FileInputStream(f));
			f2 = new File("C:\\PALM\\BastieA\\address\\copy of address.dat");
			f2 = new File("C:\\PALM\\BastieA\\address\\SynchedNsfAddress.dat");
			is2 = new DataInputStream(new FileInputStream(f2));
		} catch (Exception e)
		{
			System.out.println(e.toString());
			System.exit(-1);
			return;
		}
		
		byte line[] = new byte[16];
		StringBuffer sb;
		byte line2[] = new byte[16];
		StringBuffer sb2;
		
		try 
		{
			for (int j=1; j<(int)(f.length()/16)+1; j++)
			{
				is.read(line);
				is2.read(line2);
		
				pos += 16;

				diff = false;
				for (int i = 0; i<16; i++) {
					if (line[i] != line2[i]) {
						diff = true;
						break;
					}
				}
				
				for (int i = 0; i<16; i++) {
					
					sb = new StringBuffer(new Byte(line[i]).intValue()+"");

					switch (sb.length())
					{
						case 1:
							sb.insert(0, "  ");
							break;
						case 2:
							sb.insert(0, " ");
							break;
					}

					System.out.print(sb.toString());

					if (line[i]<32) System.out.print("(.) ");
					else System.out.print("("+(char)line[i]+") ");
					
				}

				System.out.println("");
					
				if (diff) {
					
					for (int i = 0; i<16; i++) {
						sb = new StringBuffer(new Byte(line2[i]).intValue()+"");

						switch (sb.length())
						{
							case 1:
								sb.insert(0, "  ");
								break;
							case 2:
								sb.insert(0, " ");
								break;
						}

						System.out.print(sb.toString());

						if (line2[i]<32) System.out.print("(.) ");
						else System.out.print("("+(char)line2[i]+") ");
					}
											
					System.out.println("");

				} else {
					System.out.println("");					
				}
				System.out.println("");
			}
		} catch (Exception ignored) 
		{
		}
	}
}
