/*
 * Created on Jan 5, 2012
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.followme.abastien.utilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ArrayListNoDuplicates<E> extends ArrayList<E> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public boolean add(E arg0) {
		
		if (!contains(arg0)) {
			return super.add(arg0);
		} else {
			return false;
		}
	}

    public boolean addAllNoDup(Collection<? extends E> collection) {

    	for (Iterator<? extends E> iterator = collection.iterator(); iterator.hasNext();) {
			E e = (E) iterator.next();
			add(e);
		}
        return true;
    }

	public String toString() {
		StringBuilder output = new StringBuilder();
		
		for (int i = 0; i < size(); i++) {
			if (output.length() > 0) {
				output.append(", ");
			}
			output.append(get(i).toString());
		}
		
		return output.toString();
		
	}

	public String toString(String separator) {
		StringBuilder output = new StringBuilder();
		
		for (int i = 0; i < size(); i++) {
			if (output.length() > 0) {
				output.append(separator);
			}
			output.append(get(i).toString());
		}
		
		return output.toString();
		
	}

	

}
