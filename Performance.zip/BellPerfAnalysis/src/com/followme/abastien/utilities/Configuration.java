package com.followme.abastien.utilities;

/**
 * This type was created in VisualAge.
 */
public class Configuration {
	private String fileName;
	private java.util.Vector records = new java.util.Vector(50,50);
	private CSVReader reader = new CSVReader(538795383L);
	private CSVWriter writer = new CSVWriter(96847764743L);
/**
 * Configuration constructor comment.
 */
public Configuration(String fileName)
{
	super();
	this.fileName = fileName;
}
private int find(String name)
{
	int i;
	for (i = 0; i < records.size(); i++)
	{
		if (((ConfigurationRecord) records.elementAt(i)).name.equals(name))
			return i;
	}
	return -1;
}
public java.util.GregorianCalendar getAsDate(String name)
{
	int pos = find(name);
	if (pos == -1)
		return null;
	return ((ConfigurationRecord) records.elementAt(pos)).dateValue;
}
public int getAsInt(String name)
{
	int pos = find(name);
	if (pos == -1)
		return -1;
	return ((ConfigurationRecord) records.elementAt(pos)).intValue;
}
public int[] getAsIntArray(String name)
{
	int pos = find(name);
	if (pos == -1)
		return null;
	return ((ConfigurationRecord) records.elementAt(pos)).intArrayValue;
}
public String getAsString(String name)
{
	int pos = find(name);
	if (pos == -1)
		return null;
	return ((ConfigurationRecord) records.elementAt(pos)).stringValue;
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	String fname = "c:\\Test_ini.csv";
	Configuration conf = new Configuration(fname);
	int[] ia = new int[3];
	ia[0] = 3;
	ia[1] = 43;
	ia[2] = 2332;
	conf.set("test", "test");
	conf.set("test2", 2);
	conf.set("test3", ia);
	conf.set("test4", new DateUtility("1999/01/28").toCalendar());
	System.out.println(conf.write());
	conf = new Configuration(fname);
	System.out.println(conf.read());
	System.out.println(conf.getAsString("test"));
	System.out.println(conf.getAsInt("test2"));
	System.out.println(conf.getAsIntArray("test3")[0] + " " + conf.getAsIntArray("test3")[1] + " " + conf.getAsIntArray("test3")[2]);
	System.out.println(new DateUtility(conf.getAsDate("test4")).toDateString());
}
public boolean read()
{
	ConfigurationRecord rec;
	if (reader.open(fileName))
	{
		while ((rec = ConfigurationRecord.read(reader)) != null)
		{
			records.addElement(rec);
		}
		reader.close();
	}
	else
		return false;
	if (records.size() == 0)
		return false;
	return true;
}
public void set(String name, int[] value)
{
	int cType = ConfigurationRecord.INT_ARRAY_TYPE;
	int pos = find(name);
	if (pos == -1)
	{
		ConfigurationRecord rec = new ConfigurationRecord();
		rec.name = name;
		rec.type = cType;
		rec.intArrayValue = value;
		records.addElement(rec);
		return;
	}
	((ConfigurationRecord) records.elementAt(pos)).type = cType;
	((ConfigurationRecord) records.elementAt(pos)).intArrayValue = value;
}
public void set(String name, int value)
{
	int cType = ConfigurationRecord.INT_TYPE;
	int pos = find(name);
	if (pos == -1)
	{
		ConfigurationRecord rec = new ConfigurationRecord();
		rec.name = name;
		rec.type = cType;
		rec.intValue = value;
		records.addElement(rec);
		return;
	}
	((ConfigurationRecord) records.elementAt(pos)).type = cType;
	((ConfigurationRecord) records.elementAt(pos)).intValue = value;
}
public void set(String name, String value)
{
	int cType = ConfigurationRecord.STRING_TYPE;
	int pos = find(name);
	if (pos == -1)
	{
		ConfigurationRecord rec = new ConfigurationRecord();
		rec.name = name;
		rec.type = cType;
		rec.stringValue = value;
		records.addElement(rec);
		return;
	}
	((ConfigurationRecord) records.elementAt(pos)).type = cType;
	((ConfigurationRecord) records.elementAt(pos)).stringValue = value;
}
public void set(String name, java.util.GregorianCalendar value)
{
	int cType = ConfigurationRecord.DATE_TYPE;
	int pos = find(name);
	if (pos == -1)
	{
		ConfigurationRecord rec = new ConfigurationRecord();
		rec.name = name;
		rec.type = cType;
		rec.dateValue = value;
		records.addElement(rec);
		return;
	}
	((ConfigurationRecord) records.elementAt(pos)).type = cType;
	((ConfigurationRecord) records.elementAt(pos)).dateValue = value;
}
public boolean write()
{
	int i;
	if (writer.open(fileName))
	{
		for (i = 0; i < records.size(); i++)
		{
			if (!((ConfigurationRecord) records.elementAt(i)).write(writer))
				return false;
		}
		writer.close();
	}
	else
		return false;
	return true;
}
}
