package com.followme.abastien.utilities;

import java.net.BindException;

public class SocketTesterOneWay implements SocketListenerOneWay {

	public static void main(String args[]) {

		SocketTesterOneWay tester = new SocketTesterOneWay();

		try {
			SocketServerReadOnly server = new SocketServerReadOnly(tester, 8020);
			server.start();
		} catch (BindException e) {
			System.out.println(e);
			System.exit(0);
		}

		SocketSenderSendOnly sender = new SocketSenderSendOnly("127.0.0.1",
				8081);

		sender.send("Test".getBytes());
		
		System.exit(0);
	}

	public void processData(byte[] data) {

		System.out.println(Utility.toString(data));

	}
}
