package com.followme.abastien.utilities;

import com.followme.abastien.io.StringWriter;

public class Logger {

	private StringWriter file;
	
	private static Logger singleon;
	
	public static Logger getInstance() {
		
		if (singleon == null) {
			
			createInstance("untitled.log");
			
		}
		
		return singleon;
		
	}


	public static synchronized Logger createInstance(String fileName) {

		if (singleon == null) {
			singleon = new Logger(fileName);
		}
		
		return singleon;
		
	}

	public static void close() {
		
		if (singleon == null) {

			return;
		}
		
		getInstance().closeInstance();
		
	}	

	private void closeInstance() {
		
		if (file != null) {
		
			file.close();	
			
			file = null;
		}
		
	}	

	public static void logEntry(Exception excep) {
		
		getInstance().file.writeLine(excep.toString());
		excep.printStackTrace(getInstance().file.getPrintWriter());
		getInstance().file.flush();
		
	}	

	public static void logEntry(String line) {
		
		getInstance().file.writeLine(line);
		getInstance().file.flush();
		
	}	

	public static void logEntryAndPrint(String line) {
		
		getInstance().file.writeLine(line);
		getInstance().file.flush();
		System.out.println(line);
		
	}	

	private Logger (String fileName) {

		if (file != null) {
		
			file.close();	
		}
		
		file = new StringWriter(fileName);
		
		file.open();
				
	}

}

