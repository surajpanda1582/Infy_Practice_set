package com.followme.abastien.utilities;

import java.util.Vector;

public class Domain
{
  // Attributes
  private Vector                    data;
  private String                    fileName;

// Constructors
public Domain(String fileName)
{
	DomainValue dv;
	this.fileName = fileName;
	data = new Vector(200, 100);
	CSVReader cs = new CSVReader(538795383L);
	if (cs.open(fileName))
	{
		while (cs.readRecord())
		{
			dv = new DomainValue(cs.getColumnAsInt(0), cs.getColumn(1));
			data.addElement(dv);
		}
		cs.close();
	}
}
/**
 * Returns all of the domain values
 * @return DomainValue[] (DomainValue array)
 */
public DomainValue[] getAll()
{
	int i;
	DomainValue[] ret = new DomainValue[data.size()];
	for (i = 0; i < data.size(); i++)
		ret[i] = ((DomainValue) data.elementAt(i));
	return ret;
}
/**
 * Returns all of the domain strings
 * @return String[] (String array)
 */
public String[] getAllAsString()
{
	int i;
	String[] ret = new String[data.size()];
	for (i = 0; i < data.size(); i++)
		ret[i] = ((DomainValue) data.elementAt(i)).value;
	return ret;
}
/**
 * Returns the given indexes into the domain as ids
 * @return int[] (id array)
 * @param indexes int[] (index array)
 */
public String getTheseIdsAsString(int[] ids)
{
	if (ids == null)
		return null;
	
	int i;
	StringBuffer ret = new StringBuffer();
	for (i = 0; i < data.size(); i++)
	{
		for (int j = 0; j < ids.length; j++)
			if (((DomainValue) data.elementAt(i)).id == ids[j])
			{
				if (ret.length() > 0) {
					ret.append(", ");
				}
				ret.append(((DomainValue) data.elementAt(i)).value);
			}
	}

	return ret.toString();
}

public int[] getTheseIds(int[] indexes)
{
	if (indexes == null)
		return null;
	int i;
	int[] ret = new int[indexes.length];
	for (i = 0; i < ret.length; i++)
		ret[i] = -1;
	for (i = 0; i < indexes.length; i++)
		ret[i] = ((DomainValue) data.elementAt(indexes[i])).id;
	return ret;
}
/**
 * Returns the given values as ids from the Domain
 * @return int[] (id array)
 * @param values String[] (value array)
 */
public int[] getTheseIds(String[] values)
{
	if (values == null)
		return null;
	int i, j = 0;
	int[] ret = new int[values.length];
	for (i = 0; i < ret.length; i++)
		ret[i] = -1;
	for (i = 0; i < data.size(); i++)
	{
		for (j = 0; j < values.length; j++)
			if (((DomainValue) data.elementAt(i)).value.equals(values[j]))
			{
				ret[j] = ((DomainValue) data.elementAt(i)).id;
			}
	}
	return ret;
}
/**
 * Returns the given ids as indexes into the Domain
 * @return int[] (index array)
 * @param ids int[] (id array)
 */
public int[] getTheseIndexes(int[] ids)
{
	if (ids == null)
		return null;
	int i, j = 0;
	int[] ret = new int[ids.length];
	for (i = 0; i < ret.length; i++)
		ret[i] = -1;
	for (i = 0; i < data.size(); i++)
	{
		for (j = 0; j < ids.length; j++)
			if (((DomainValue) data.elementAt(i)).id == ids[j])
			{
				ret[j] = i;
			}
	}
	return ret;
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	int i;
	CSVWriter cs = new CSVWriter(96847764743L);
	if (cs.open("c:\\temp\\domaintest.csv"))
	{
		cs.add(1);
		cs.add("item1");
		cs.writeRecord();
		cs.add(2);
		cs.add("item2");
		cs.writeRecord();
		cs.add(3);
		cs.add("item3");
		cs.writeRecord();
		cs.add(9);
		cs.add("item9");
		cs.writeRecord();
		cs.add(5);
		cs.add("item5");
		cs.writeRecord();
		cs.add(133);
		cs.add("item133");
		cs.writeRecord();
		cs.close();
		Domain dm = new Domain("c:\\temp\\domaintest.csv");
		String[] strs = dm.getAllAsString();
		for (i = 0; i < strs.length; i++)
			System.out.println(strs[i]);
		String[] ia = new String[4];
		ia[0] = "item3";
		ia[1] = "item1";
		ia[2] = "item6";
		ia[3] = "item133";
		int[] v = dm.getTheseIds(ia);
		for (i = 0; i < v.length; i++)
			System.out.println(v[i]);
	}
}
public int size()
{
	return data.size();
}
}