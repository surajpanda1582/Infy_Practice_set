package com.followme.abastien.utilities;

import java.awt.*;
import java.awt.event.*;

public class ImageView extends Dialog implements ActionListener
{
	private ImagePanel imagePanel = null;
/**
 * MessageBox constructor comment.
 * @param parent java.awt.Frame
 */
public ImageView(java.awt.Frame parent)
{
	super(parent);
	init();
}
/**
 * MessageBox constructor comment.
 * @param parent java.awt.Frame
 * @param title java.lang.String
 */
public ImageView(java.awt.Frame parent, String title)
{
	super(parent, title);
	init();
}
/**
 * MessageBox constructor comment.
 * @param parent java.awt.Frame
 * @param title java.lang.String
 * @param modal boolean
 */
public ImageView(java.awt.Frame parent, String title, boolean modal)
{
	super(parent, title, modal);
	init();
}
/**
 * MessageBox constructor comment.
 * @param parent java.awt.Frame
 * @param modal boolean
 */
public ImageView(java.awt.Frame parent, boolean modal)
{
	super(parent, modal);
	init();
}
public void actionPerformed(java.awt.event.ActionEvent e)
{
	String actionName = "";
	if (e.getSource() instanceof Button)
	{
		Button bn = (Button)e.getSource();
		actionName = bn.getName();
	}
	if (actionName.equals("OK")) setVisible(false);
}
public void init()
{
	addWindowListener(new WindowAdapter()
	{
		public void windowClosing(WindowEvent e)
		{
			setVisible(false);
		}
	});
	Panel pn = new Panel();
	setModal(true);
	setLayout(new BorderLayout());
	setSize(640, 480);
	imagePanel = new ImagePanel();
	add(imagePanel, "Center");
	Button bn = makeButton(pn, "OK");
  
	add(pn, "South");
}
/**
 * This method was created in VisualAge.
 * @param args java.lang.String[]
 */
public static void main(String args[])
{
	Frame fm = new Frame();
	fm.setVisible(true);
	MessageBox mb;
	System.out.println("");
	mb = new MessageBox(fm);
	mb.setButtons(MessageBox.BUTTONS_OK_CANCEL);
	mb.setMessage("Please insert the disk dshjds kjsdf kjdshf dshf dskjf.");
	mb.setVisible(true);
	System.exit(0);
}
protected Button makeButton(Panel pn, String name)
{
	Button button = new Button(name);
	pn.add(button);
	button.setName(name);
	button.addActionListener(this);
	return button;
}
/**
 * This method was created in VisualAge.
 * @param g Graphics
 */
public void oldpaint(Graphics g)
{
	Image im, sim;
	int w, h;
	im = imagePanel.getImage();
	System.out.println("painting");
	if (im != null)
	{
		java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
		Rectangle rect = imagePanel.getBounds();
		if (rect.width > 0 && rect.height > 0)
		{
			System.out.println("Checking image size");
			while ((w = im.getWidth(this)) < 0);
			while ((h = im.getHeight(this)) < 0);
			if (w - rect.width > 0 || h - rect.height > 0)
			{
				System.out.println("Scaling");
				if (im.getWidth(this) - rect.width > im.getHeight(this) - rect.height)
					sim = im.getScaledInstance(rect.width, -1, Image.SCALE_FAST);
				else
					sim = im.getScaledInstance(-1, rect.height, Image.SCALE_FAST);
				imagePanel.setImage(sim);
				imagePanel.repaint();
			}
		}
		else
			System.out.println("zero bounds");
	}
	else
		System.out.println("no image set");
	super.paint(g);
}
public void setImage(String imageName)
{
	Image im;
	java.awt.Toolkit tk = java.awt.Toolkit.getDefaultToolkit();
	if ((new java.io.File(imageName)).exists())
	{
		im = tk.getImage(imageName);
		imagePanel.setImage(im);
	}
	else
	{
		imagePanel.setImage(null);
	}
}
public void setVisible(boolean value)
{
	if (value)
		repaint();
	super.setVisible(value);
}
}