package com.followme.abastien.utilities;

public interface AskDialogListener {

	

}