package com.followme.abastien.utilities;

public interface SocketListenerOneWay {


	public void processData ( byte[] data );
}
