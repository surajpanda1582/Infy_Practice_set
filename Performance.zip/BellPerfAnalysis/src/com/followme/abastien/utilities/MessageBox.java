package com.followme.abastien.utilities;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.event.ActionListener;

public class MessageBox extends Dialog implements ActionListener {
	static public final int BUTTONS_OK_CANCEL = 1;
	static public final int BUTTONS_YES_NO = 2;
	static public final int BUTTONS_YES_NO_CANCEL = 3;
	static public final int BUTTONS_OK = 4;
	static public final int BUTTONS_NONE = 0;
	static public final int BUTTONS_OK_ALL_CANCEL = 5;

	static public final int OK = 1;
	static public final int YES = 2;
	static public final int NO = 3;
	static public final int CANCEL = 4;
	static public final int OK_ALL = 5;

	private int buttonPressed = -1;
	private String message = new String("");
	private int buttons = BUTTONS_OK_CANCEL;
	private TextArea lbMessage;
	private Button bnOK;
	private Button bnOKAll;
	private Button bnCancel;
	private Button bnYes;
	private Button bnNo;
	private Panel buttonPanel;

	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 */
	public MessageBox(java.awt.Frame parent) {

		super(parent, parent.getTitle());
		init(300, 120);
	}
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param title java.lang.String
	 */
	public MessageBox(java.awt.Frame parent, String title) {
		super(parent, title);
		init(350, 170);
	}
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param title java.lang.String
	 * @param modal boolean
	 */
	public MessageBox(java.awt.Frame parent, String title, boolean modal) {
		super(parent, title, modal);
		init(300, 120);
	}
	/**
	 * MessageBox constructor comment.
	 * @param parent java.awt.Frame
	 * @param modal boolean
	 */
	public MessageBox(java.awt.Frame parent, boolean modal) {
		super(parent, parent.getTitle(), modal);
		init(300, 120);
	}

	public MessageBox(
		Frame parent,
		String title,
		boolean modal,
		String message,
		int buttons, 
		int width, 
		int height) {
		super(parent, title, modal);

		init(width, height);
		setMessage(message);
		setButtons(buttons);
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
		String actionName = "";
		if (e.getSource() instanceof Button) {
			Button bn = (Button) e.getSource();
			actionName = bn.getName();
		}
		buttonPressed = -1;
		if (actionName.equals("OK"))
			buttonPressed = OK;
		else if (actionName.equals("Cancel"))
			buttonPressed = CANCEL;
		else if (actionName.equals("Yes"))
			buttonPressed = YES;
		else if (actionName.equals("No"))
			buttonPressed = NO;
		else if (actionName.equals("OK to All"))
			buttonPressed = OK_ALL;
		if (buttonPressed > 0) {
			setVisible(false);
			dispose();
		}
	}
	public int getButtonPressed() {
		return buttonPressed;
	}
	protected void init(int w, int h) {
		buttonPanel = new Panel();
		setModal(true);
		setLayout(new BorderLayout());
		setBounds(100, 300, w, h);
		lbMessage = new TextArea("", -1, -1, TextArea.SCROLLBARS_NONE);
		lbMessage.setEditable(false);
		add(lbMessage, "Center");
		add(buttonPanel, "South");
		bnOK = makeButton("OK");
		bnOKAll = makeButton("OK to All");
		bnYes = makeButton("Yes");
		bnNo = makeButton("No");
		bnCancel = makeButton("Cancel");
	}
	/**
	 * This method was created in VisualAge.
	 * @param args java.lang.String[]
	 */
	public static void main(String args[]) {
		Frame fm = new Frame();
		fm.setVisible(true);
		MessageBox mb;
		System.out.println("");
		mb = new MessageBox(fm);
		mb.setButtons(MessageBox.BUTTONS_OK_CANCEL);
		mb.setMessage("Please insert the disk dshjds kjsdf kjdshf dshf dskjf.");
		mb.setVisible(true);
		System.exit(0);
	}
	protected Button makeButton(Panel pn, String name) {
		Button button = new Button(name);
		pn.add(button);
		button.setName(name);
		button.addActionListener(this);
		return button;
	}
	protected Button makeButton(String name) {
		Button button = new Button(name);
		button.setName(name);
		button.addActionListener(this);
		return button;
	}
	public void setButtons(int bn) {
		buttons = bn;
		buttonPanel.removeAll();
		switch (buttons) {
			case BUTTONS_OK :
				buttonPanel.add(bnOK);
				break;
			case BUTTONS_OK_CANCEL :
				buttonPanel.add(bnOK);
				buttonPanel.add(bnCancel);
				break;
			case BUTTONS_YES_NO :
				buttonPanel.add(bnYes);
				buttonPanel.add(bnNo);
				break;
			case BUTTONS_YES_NO_CANCEL :
				buttonPanel.add(bnYes);
				buttonPanel.add(bnNo);
				buttonPanel.add(bnCancel);
				break;
			case BUTTONS_OK_ALL_CANCEL :
				buttonPanel.add(bnOK);
				buttonPanel.add(bnOKAll);
				buttonPanel.add(bnCancel);
				break;
		}
	}
	public void setMessage(String msg) {
		message = msg;
		lbMessage.setText(msg);
	}
}