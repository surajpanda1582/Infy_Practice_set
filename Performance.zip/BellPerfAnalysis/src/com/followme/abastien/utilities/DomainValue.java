package com.followme.abastien.utilities;

/**
 * This type was created in VisualAge.
 */
public class DomainValue 
{
	public int id;
	public String value;
/**
 * DomainValue constructor comment.
 */
public DomainValue(int id, String value)
{
	this.id = id;
	this.value = value;
}
}