package com.followme.abastien.utilities;


/**
 * @author ABastien
 *
 *               
 */
public class Geographic {

	public static void main(String[] args) {

		System.out.println(getDistanceKM(33.5, -118.5, 40.5, -73.5));
		System.out.println(getBearing(33.5, -118.5, 40.5, -73.5));
		System.out.println(getDistanceKM(33.5, -118.5, 40.5, -118.5));
		System.out.println(getBearing(33.5, -118.5, 40.5, -118.5));
		System.out.println(getDistanceKM(33.5, -74.5, 33.5, -73.5));
		System.out.println(getBearing(33.5, -74.5, 33.5, -73.5));
		System.out.println(getDistanceKM(33.5, -73.5, 33.5, -74.5));
		System.out.println(getBearing(33.5, -73.5, 33.5, -74.5));
		System.out.println(getDistanceKM(33.5, 73.5, 33.5, 74.5));
		System.out.println(getBearing(33.5, 73.5, 33.5, 74.5));
	}

	//	CONSTANTS USED INTERNALLY
	static final double DEGREES_TO_RADIANS = (Math.PI / 180.0);
	//	Mean radius in KM
	static final double EARTH_RADIUS = 6371.0;
	/** Method to compute Great Circle distance between 
	  * two points. Please note that this algorithm  
	  * assumes the Earth to be a perfect sphere, whereas
	  * in fact the equatorial radius is about 30Km 
	  * greater than the Polar.
	  *
	  * @param alt other point to compute distance to
	  * @return The distance in Kilometres
	  */

	public static double getDistanceKM(
		double lat1,
		double long1,
		double lat2,
		double long2) {

		double rlat1 = Math.toRadians(lat1);
		double rlong1 = Math.toRadians(long1);
		double rlat2 = Math.toRadians(lat2);
		double rlong2 = Math.toRadians(long2);
		//	There is no real reason to break this lot into 
		//	4 statements but I just feel it's a little more 
		//	readable.
		double p1 =
			Math.cos(rlat1)
				* Math.cos(rlong1)
				* Math.cos(rlat2)
				* Math.cos(rlong2);
		double p2 =
			Math.cos(rlat1)
				* Math.sin(rlong1)
				* Math.cos(rlat2)
				* Math.sin(rlong2);
		double p3 = Math.sin(rlat1) * Math.sin(rlat2);

		return (Math.acos(p1 + p2 + p3) * EARTH_RADIUS);
	}

	public static double getBearing(
		double lat1,
		double long1,
		double lat2,
		double long2) {
			
		if (lat1 == lat2) {
			
			if (long1 == long2) return Double.NaN;
			
			if (long1 > long2) return 270.0;
			else return 90.0;
		}

		if (long1 == long2) {
			
			if (lat1 == lat2) return Double.NaN;
			
			if (lat1 > lat2) return 180;
			else return 0.0;
		}

		double rlat1 = Math.toRadians(lat1);
		double rlong1 = Math.toRadians(long1);
		double rlat2 = Math.toRadians(lat2);
		double rlong2 = Math.toRadians(long2);

		double dst = radDist(lat1, long1, lat2, long2);

		double ac =
			(Math.sin(rlat2) - Math.sin(rlat1) * Math.cos(dst))
				/ (Math.sin(dst) * Math.cos(rlat1));
		double c0;
		c0 = Math.acos(ac);

		//CAux.perr("ic d=" + dst + " ac="+ac+ "c0="+c0, 3);

		// Rounding problems
		if (ac < -1d) {
			ac = -1d;
		}
		if (ac > 1d) {
			ac = 1d;
		}

		double ret = 0.0;

		if (Math.sin(rlong1 - rlong2) < 0d) {
			ret = c0;
		} else {
			ret = (2d * Math.PI - c0);
		}
		
		//System.out.println("NAN: "+lat1+", "+long1+" -> "+lat2+", "+long2);
		ret = Math.toDegrees(ret);
		
		return ret;
	}

	public static double radDist(
		double lat1,
		double long1,
		double lat2,
		double long2) {
		double rlat1 = Math.toRadians(lat1);
		double rlong1 = Math.toRadians(long1);
		double rlat2 = Math.toRadians(lat2);
		double rlong2 = Math.toRadians(long2);

		return (
			2d * Math.asin(
				Math.sqrt(
					Math.pow(Math.sin(rlat1 - rlat2) / 2d, 2)
						+ Math.cos(rlat1)
							* Math.cos(rlat2)
							* Math.pow(
								Math.sin((-rlong1 + rlong2) / 2d),
								2))));
	}

}
