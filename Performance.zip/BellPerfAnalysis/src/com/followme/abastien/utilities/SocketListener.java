package com.followme.abastien.utilities;

public interface SocketListener {


	public byte[] processData ( byte[] data );


}