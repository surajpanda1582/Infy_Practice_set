package com.followme.abastien.utilities;

public class WordString {

	private StringBuilder strData;
	private final static char[] defaultDelimiters = { ' ' };
	private char[] delimiters = defaultDelimiters;

	public WordString() {

	}
	
	public WordString(String str) {

		setString(str);

	}
	
	public WordString(StringBuilder str) {

		setString(str);

	}
	
	public void setDelimiters(char[] delimiters) {
		
		this.delimiters = delimiters;
		
	}


	public void setString(String str) {
		
		strData = cleanString(new StringBuilder(str));	
	}
	
	public void setString(StringBuilder str) {
		
		strData = cleanString(str);	
	}
	
	public void setStringNoClean(String str) {
		
		strData.setLength(0);
		strData.append(str);	
	}
	
	public static StringBuilder cleanString(StringBuilder str) {

		if (str == null) {
			return (null);
		}

		int i, l = str.length();
		boolean lastWasBlank = true;
		char ch;
		StringBuilder strRet = new StringBuilder(str.length());

		for (i = 0; i < l; i++) {

			ch = str.charAt(i);

			if (ch == ' ' || ch == '\t') {

				if (lastWasBlank) {

					lastWasBlank = true;

				} else {
					lastWasBlank = true;
					strRet.append(ch);
				}
			} else {

				lastWasBlank = false;
				strRet.append(ch);

			}

		}

		return strRet;

	}

	public String getWord(int position) {

		int i, j, counter;
		int st;
		char ch;

		counter = -1;
		st = 0;

		for (i = 1; i < strData.length(); i++) {

			ch = strData.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					counter++;
					if (counter == position) {
						return (strData.substring(st, i));
					} else {
						st = i + 1;
					}
					break;
				}
			}
		}

		if (counter == position - 1 && st < strData.length()) {
			return (strData.substring(st));
		}

		return (null);
	}

	public int getWordPos(int position) {

		int i, j, counter;
		int st;
		char ch;

		counter = -1;
		st = 0;

		for (i = 1; i < strData.length(); i++) {

			ch = strData.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					counter++;
					if (counter == position) {
						return (st);
					} else {
						st = i + 1;
					}
				}
			}
		}

		if (counter == position - 1 && st < strData.length()) {
			return (st);
		}

		return (-1);
	}

	public int getWordCount() {

		return getWordCount(strData, delimiters);
	}

	public static int getWordCount(String str) {

		return (getWordCount(str, defaultDelimiters));

	}

	public static int getWordCount(String str, char[] delimiters) {
		StringBuilder strData = new StringBuilder(str);
		
		return getWordCount(strData, delimiters);
	}
	
	public static int getWordCount(StringBuilder str, char[] delimiters) {

		int i, j, counter;
		int last = -1;
		char ch;

		counter = 0;

		str = cleanString(str);

		for (i = 1; i < str.length(); i++) {

			ch = str.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					counter++;
					last = i;
					break;
				}
			}
		}

		if (last < str.length() - 1) {
			counter++;
		}

		return (counter);
	}

	public int getWordCountQuoted() {

		return getWordCountQuoted(strData, delimiters);

	}

	public static int getWordCountQuoted(String str) {

		return (getWordCountQuoted(str, defaultDelimiters));

	}

	public static int getWordCountQuoted(String str, char[] delimiters) {
		return getWordCountQuoted(new StringBuilder(str), delimiters);
	}
	
	public static int getWordCountQuoted(StringBuilder str, char[] delimiters) {

		int counter, i;
		String word;

		counter = 0;
		i = 0;

		WordString words = new WordString(str);

		word = words.getWord(i);

		while (word != null) {

			counter++;

			if (word.startsWith("\"")) {

				word = words.getWords(i, "\"");
				i += WordString.getWordCount(word) - 1;

			}

			i++;
			word = words.getWord(i);

		}

		return (counter);
	}

	public String getWordQuoted(int position) {

		int counter, i;
		String word;
		String retS = null;

		counter = -1;
		i = 0;

		word = getWord(i);

		while (word != null && counter < position) {

			counter++;

			if (word.startsWith("\"")) {

				word = getWords(i, "\"");
				i += getWordCount(word) - 1;

			}

			if (counter == position) {
				retS = word;
			}
			i++;
			word = getWord(i);

		}

		if (retS != null
			&& retS.length() > 1
			&& retS.charAt(0) == '"'
			&& retS.charAt(retS.length() - 1) == '"') {
			return (retS.substring(1, retS.length() - 1));
		}

		return (retS);
	}

	public String getWordQuotedAndOn(int position) {

		int counter, i;
		String word;
		String retS = null;

		counter = -1;
		i = 0;

		word = getWord(i);

		while (word != null) {

			counter++;

			if (word.startsWith("\"")) {

				word = getWords(i, "\"");
				i += getWordCount(word) - 1;

			}

			if (counter == position) {
				retS = word;
			} else
				if (counter > position) {
					retS += " " + word;
				}
			i++;
			word = getWord(i);

		}

		return (retS);
	}

	public String getWordAndOn(int position) {

		int p = getWordPos(position);

		if (p >= 0) return strData.substring(p);
			
		return (null);
	}
	
	public String getWords(int startPosition, int number) {

		int i, j, counter;
		int st;
		char ch;
		
		st = -1;
		if (startPosition == 0) {
			st = 0;	
		}
		
		counter = 0;
		

		for (i = 1; i < strData.length(); i++) {

			ch = strData.charAt(i);

			for (j = 0; j < delimiters.length; j++) {
				if (ch == delimiters[j]) {
					counter++;
					if (counter == startPosition + number) {
						return (strData.substring(st, i));
					} else
						if (counter == startPosition) {
							st = i + 1;
						}
					break;
				}
			}
		}

		if (st > 0 && st < strData.length()) {
			return (strData.substring(st));
		}

		return (null);
	}

	public String getWords(int startPosition, String endChar) {

		int i = startPosition;
		String retS = null;
		String word;

		retS = getWord(i);
		if (retS.endsWith(endChar) && retS.length() != 1) {
			return retS;
		}

		word = getWord(++i);
		while (word != null) {

			retS = retS + delimiters[0] + word;

			if (word.endsWith(endChar)) {
				break;
			}

			i++;
			word = getWord(i);
		}

		return (retS);
	}

	public String toString() {
		return (strData.toString());
	}

	public static void main2(String args[]) {
		
		
		WordString words = new WordString(" 	  Vector currencyResponse = this.getParentEPanel().getCIBCEPanelContainer().sendCommsMessage(currencyRequest);");
    	words.setDelimiters(new char[] { '=', '}', '.', ' ', '{', '\t', '(', ')' });

		int l = words.getWordCount();

		for (int i = 0; i < l; i++) {

			String word = words.getWord(i);
			System.out.println(word);
		}
	}
	
	public static void main(String args[]) {

		//WordString words1 = new WordString("objectclasses: ( 1.3.18.0.2.6.120 NAME 'eNTGroup' DESC 'Object class class used to define entries that represent DNS domains in the directory. The domainComponent attribute should be used for naming entries of this object class.' SUP top MUST eNTDomainGroupID MAY ( description $ eNTGroupAttributes $ member $ ntGroupCreateNewGroup $ ntGroupDeleteGroup $ ntGroupID $ ntGroupType $ principalPtr ) )");
		WordString words1 =
			new WordString("####<Oct 29, 1999 8:41:13 AM EDT> <Debug> <cibc.cbfe> <cbfe-dev-app01> <1bdit-srv1> <ExecuteThread: '71' for queue: 'default'> <> <57:790404fcd71827fe> <000000> <1999.10.29 8:41:13:604 America/Montreal::BT001::LOGON::EA10004  com.bankframe.cibc.ei.transactionhandler.response.CoinsResponse::executeMethod::The methodName =  getResponseType> ");
						//   0          1        2     3     4   5   6     7     8       9        10     11    12      13              14          15    16171819       20         21   22  23      24     25 26         27          28  29 30  31 32                  33                                                    34     35      36        37                        38
		words1.setDelimiters("<>:".toCharArray());
		
		int l = words1.getWordCount();
		for (int i = 0; i < l; i++) {
			System.out.println(i + ": " +words1.getWord(i));
		}

		System.out.println(words1.getWords(24, 4));

		String desc = words1.getWords(1, "3");
		System.out.println(desc);
		int i = WordString.getWordCount(desc, "<>:".toCharArray());
		System.out.println(i);
		System.out.println(words1.getWord(i + 1));

		WordString words2 =
			new WordString("'Object class class used to define entries that represent DNS domains in the directory. The domainComponent attribute should be used for naming entries of this object class.'");
		System.out.println(words2.getWordCount());

		System.out.println("Quoted");
		//String strs = "\"word1 word2\" \"word3 word4\" word5";
		//String strs = "#ADDTO !S_TEMP \" minutes\" \" test \" \"";
		String strs = "#IF 1 = 1 \"\"";
		System.out.println(WordString.getWordCount(strs));

		WordString wqs = new WordString(strs);
		l = wqs.getWordCountQuoted();
		System.out.println(l);
		for (i = 0; i < l; i++) {
			System.out.println(i + ": " +wqs.getWordQuoted(i));
		}

		System.out.println(wqs.getWordQuotedAndOn(2));

	}

	public StringBuilder getString() {
		return strData;
	}

}