package com.followme.abastien.utilities;

public class SocketTesterLocal implements SocketListener {


	public static void main(String args[])	{


		SocketTesterLocal tester = new SocketTesterLocal();
		
		SocketServerLocal server = new SocketServerLocal(tester, 8020, 8021);

		server.start();

		SocketSenderLocal sender = new SocketSenderLocal("211.211.211.1", 8021, 8020);

		System.out.println(Utility.toString(sender.send("Test".getBytes())));
		System.out.println(Utility.toString(sender.send("Testing Testing...".getBytes())));

		System.exit(0);
	}
	public byte[] processData ( byte[] data ) {
	
		System.out.println(Utility.toString(data));
		
		return ("OK".getBytes());
	
	}
}
