import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellOmPerformanceLogsScenerioProcessor extends LineProcessorWithData {

	
	private File currentFile;
	private String currentServer;
	private String dir;
	private String outDir;

	private String startPath = "";
	@SuppressWarnings("rawtypes")
	Hashtable perfData = new Hashtable();

	Hashtable<String, String> reportScenarios = new Hashtable<String, String>();
	Hashtable<String, String> reportScenariosPath = new Hashtable<String, String>();
	Hashtable<String, String[]> reportScenariosFilter = new Hashtable<String, String[]>();
	ArrayListNoDuplicates<String[]> reportScenarioList = new ArrayListNoDuplicates<String[]>();
	ArrayListNoDuplicates<String> reportNameList = new ArrayListNoDuplicates<String>();
	ArrayListNoDuplicates<String> scenarios = new ArrayListNoDuplicates<String>();
	Hashtable<String, ScenarioData> hoiData = new Hashtable<String, ScenarioData>();
	Hashtable<String, ArrayListNoDuplicates<String>> HEADERS = new Hashtable<String, ArrayListNoDuplicates<String>>(); 
	Hashtable<String, BellScenarioAccess> accessEntries = new Hashtable<String, BellScenarioAccess>();
	Hashtable<String, Hashtable<Long, String>> errorEntries = new Hashtable<String, Hashtable<Long, String>>();
	Hashtable<String, String> hoiPath = new Hashtable<String, String>();
	Hashtable<String, String> hoiLastAction = new Hashtable<String, String>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String perfFileStartsWith = "omperf_";
	String accessFileStartsWith = "omaccess_";
	String dropFileStartsWith = "OMSessionDrop_";
	
	private WordString words = new WordString("");
	private WordString words2 = new WordString("");
	private 	StringWriter hoiWriter;
	private 	StringWriter jspWriter;
	private boolean logJsp = false;
	private int modePerformance = 0;
	private Hashtable<String, String> userHois = new Hashtable<String, String>();
	

	public BellOmPerformanceLogsScenerioProcessor(String dir, String outDir, String accessFileStartsWith, String dropFileStartsWith, String perfFileStartsWith, String minMs, String maxMs, String scenariosConfigFilename) {

		this.dir = dir;
		this.outDir = outDir;
		this.perfFileStartsWith = perfFileStartsWith;
		this.accessFileStartsWith = accessFileStartsWith;
		this.dropFileStartsWith = dropFileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { '|' });
		words2.setDelimiters(new char[] { ' ' });
		
		System.out.println("Output to: " + outDir);

		readScenariosConfig(scenariosConfigFilename);
		
		hoiWriter = new StringWriter(outDir + File.separator + "hoiScenarios.tab");
		hoiWriter.open();

		hoiWriter.writeLine("Name\tHOI\tResp Ms\tStart Ms\tEnd Ms\tPath\tStart Ms\tEnd Ms\tUser\tAction\tError\tScenario");

		if (logJsp) {
			jspWriter = new StringWriter(outDir + File.separator + "jsps.tab");
			jspWriter.open();
	
			jspWriter.writeLine("Name\tHOI\tResp Ms\tStart\tEnd");
		}			
	}

	private void readScenariosConfig(String scenariosConfigFilename) {

		System.out.println("Reading " + scenariosConfigFilename);
		StringReader reader = new StringReader(scenariosConfigFilename);
		int count = 0;
		
		if (reader.open() < 0) {
			System.out.println("ERROR: cannot open: " + scenariosConfigFilename);
			System.exit(-1);
		}
		
		String line = reader.readLine();
		String lastName = null;
		
		while (line != null)  {
			
			if (line.trim().length() > 0) {
				if (line.startsWith("f>")) {
					String name2 = reader.readLine().trim(); //New name
					reportScenariosFilter.put(lastName, new String[] {line.substring(2).trim(), name2});
					reportNameList.add(name2);
					
				} else if (line.startsWith(">>")) {
					lastName = line.substring(2);
					reportNameList.add(lastName);

					line = reader.readLine(); //URL
					String path = reader.readLine(); //Path

					
					String[] items = line.split("\\|");
					if (items.length == 1) {
						items = new String[]{items[0], ""};
					}
					
					StringBuilder scenario = new StringBuilder();
					scenario.append(items[0]);
					
					for (int i = 1; i < items.length; i++) {
						scenario.append('|');
						scenario.append(items[i]);
					}
					reportScenarios.put(scenario.toString(), lastName);
					reportScenariosPath.put(lastName, path);
					reportScenarioList.add(items);
					count++;
				}
			} 
			
			line = reader.readLine();
		}
		
		reader.close();
		
		System.out.println("Read " + count);

		
		//buildHeaders();
	}

	public void print(OmParameters data) {
		
		StringWriter writer;
		
		hoiWriter.close();
		if (logJsp) {
			jspWriter.close();
		}
		
		String lDir = "";
		lDir = outDir + File.separator;

//		writer = new StringWriter(lDir + "scenarios.txt");
//		writer.open();
//
//		Collections.sort(scenarios);
//
//		for (Iterator iterator = scenarios.iterator(); iterator.hasNext();) {
//			String scen = (String) iterator.next();
//			
//			writer.writeLine(scen);
//		}
//
//		writer.close();

		writer = null;
		
		buildHeaders();
		
		for (Iterator iterator = reportNameList.iterator(); iterator.hasNext();) {
			String scenario = (String) iterator.next();
			writeScenarioData(scenario, data, minMs, maxMs);
		}
		
		
		
	}

	private void writeScenarioData(String scenarioName, OmParameters cdata, long tMinMs, long tMaxMs) {
		
		StringWriter writer;
		String lDir = "";
		lDir = outDir + File.separator;
		
		writer = new StringWriter(lDir + scenarioName+".tab");
		writer.open();
		boolean headerWritten = false;
		
		minMs = tMinMs;
		maxMs = cdata.maxMs;
		
		Integer interval = new Integer((int)(minMs / cdata.interval));
		int maxInterval = (int)(maxMs / cdata.interval);

		while (interval.doubleValue() <= maxInterval) {
			OmScenarioDataIntervalElement intervalDataElement = (OmScenarioDataIntervalElement)perfData.get(interval);
			if (intervalDataElement != null) {
				OmScenarioDataElement dataElement = intervalDataElement.scenarios.get(scenarioName);
				
				if (headerWritten == false) {
					writeServicesHeader(writer, scenarioName);
					headerWritten = true;
				}
				writer.write(Utility.longTo24Hour(interval.intValue()*cdata.interval/1000) + "\t");
				

				if (dataElement != null) {
					
					writer.write(dataElement.servletStats.size() + "\t" + dataElement.servletStats.getAverage() + "\t" + dataElement.servletStats.getPercentile(.9) + "\t");

					ArrayList services = getHeaders(scenarioName);
					for (int i = 0; i < services.size(); i++) {
						StatisticalDoubleVector stats = (StatisticalDoubleVector)dataElement.byCall.get(services.get(i));
						
						if (stats != null) {
							writer.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t");
						} else {
							writer.write("\t\t\t");
						}
					}
					
				}
				
				writer.writeLine("");
			}
			
			interval = new Integer(interval.intValue()+1);
		}
		
		writer.close();
	}

	/**
	 * 
	 */
	private void writeServicesHeader(StringWriter writer, String scenarioName) {
		writer.write("\t");
		
		ArrayList calls = getHeaders(scenarioName);
		
		if (calls == null) {
			return;
		}
		
		writer.write("Servlets\t\t\t");

		for (Iterator iterator = calls.iterator(); iterator.hasNext();) {
			String call = (String) iterator.next();
			
			writer.write(call + "\t\t\t");
		}
		
		writer.writeLine("");
		writer.write("Interval\t");
		writer.write("Num\tAvg\t90%\t");
		for (int i = 0; i < calls.size(); i++) {
			writer.write("Num\tAvg\t90%\t");
		}
		writer.writeLine("");
	}


	public boolean processLine(String str, Object data) {
		
		if (modePerformance == 2) {
			return processLinePerf(str, data);
			
		} else if (modePerformance == 1) {
			return processLineAccess(str, data);
			
		} else {
			return processLineDrop(str, data);
		}
	}
	
	String cleanEmptyParms(String line) {
		
		//int p = line.indexOf("|");
		
		//if (p < 0) {
			//return line;
		//}
		String temps = line;//.substring(p+1);
		String parms = "";
		String parmsButtonClick = "";
		String parmsButton = "";
		String parmsAction = "";
		String parmsPath = "";
		
		String parm = "";
		char lastx = ' ';
		for (int i = 0; i < temps.length(); i++)
		{
			char x = temps.charAt(i);
			
			if (x == ',') {

				if (parm.indexOf("buttonclicked") >= 0) {
						parmsButtonClick = parmsButtonClick + parm + ",";
						
				} else if (parm.indexOf("button") >= 0) {
						parmsButton = parmsButton + parm + ",";
						
				} else if (parm.startsWith("Path=")) {
					parmsPath = parmsPath + parm + ",";
					
				} else if (parm.startsWith("action=")) {
					parmsAction = parmsAction + parm + ",";
					
				} else if (parm.length() > 0 && lastx != '=') {
						parms = parms + parm + ",";
				}
				parm = "";
			} else {
				parm = parm + x;
			}
			lastx = x;
		}
		
		if (parm.indexOf("buttonclicked") >= 0) {
			parmsButtonClick = parmsButtonClick + parm + ",";
			
		} else if (parm.indexOf("button") >= 0) {
				parmsButton = parmsButton + parm + ",";
				
		} else if (parm.startsWith("Path=")) {
			parmsPath = parmsPath + parm + ",";
			
		} else if (parm.startsWith("action=")) {
			parmsAction = parmsAction + parm + ",";
			
		} else if (parm.length() > 0 && lastx != '=') {
				parms = parms + parm + ",";
		}
		
		if (parmsPath.length() > 0) {
			parms = parmsPath + parms;
		}
		if (parmsAction.length() > 0) {
			parms = parmsAction + parms;
		}
		if (parmsButton.length() > 0) {
			parms = parmsButton + parms;
		}
		if (parmsButtonClick.length() > 0) {
			parms = parmsButtonClick + parms;
		}
		//return line.substring(0, p) + "|" + parms;
		return parms;
		
	}
	


	@SuppressWarnings("unchecked")
	public boolean processLineAccess(String str, Object data) {


		OmParameters parms = (OmParameters) data;
		if (str != null && str.length() > 40 && str.charAt(4) == '-' && str.charAt(7) == '-' && str.charAt(10) == ' ') {
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			String hoi = "";
			String user = "";
			if (parms.use(date, timeMs)) {
				
				if (str.indexOf("buttonclicked=qsNext") >= 0 || str.indexOf("buttonclicked=tvEditModeBtn") >= 0) {
					int dd = 0;
				}

				String txn = null;
				String txnData = null;
				
		    	if (words.getWordCount() >= 5) {
					hoi = words.getWord(1);
					user = words.getWord(2);
					txn = words.getWord(3);
					txnData = words.getWord(4);
					
					if (user.length() == 0) {
						int p = str.indexOf("loginId=");
						if (p > 0) {
							int p2 = str.indexOf(',', p);
							if (p2 < 0) {
								p2 = str.length();
							}
							
							user = str.substring(p+8, p2);
						}
					}
					
					String name = findScenario(txn, txnData);
					
					if (name != null) {
//						if (name.equals("Order Retrieve")) {
//							System.out.println("Order Retrieve: " + hoi);
//						}						
						BellScenarioAccess hData = getOrCreateHoiData(hoi, user);
						hData.addScenario(name, timeMs);
						hData.setUrl(cleanEmptyParms(txnData));
						hData.setUser(user);
					}
		    	}
		    	
		    	if (words.getWordCount() == 4) {
					hoi = words.getWord(1);
					user = words.getWord(2);
					txn = words.getWord(3);
					txnData = "";
					
					if (user.length() == 0) {
						int p = str.indexOf("loginId=");
						if (p > 0) {
							int p2 = str.indexOf(',', p);
							if (p2 < 0) {
								p2 = str.length();
							}
							
							user = str.substring(p+8, p2);
						}
					}
					
					String name = findScenario(txn, txnData);
					
					if (name != null) {
						BellScenarioAccess hData = getOrCreateHoiData(hoi, user);
						hData.addScenario(name, timeMs);
						hData.setUrl(txnData);
						hData.setUser(user);
					}
		    	}
			}
		}

		return true;
	}

	/**
	 * @param hoi
	 * @param user
	 * @return
	 */
	private BellScenarioAccess getOrCreateHoiData(String hoi, String user) {
		
		BellScenarioAccess hData = accessEntries.get(hoi+":"+user);  // Sometimes HOI modified be 2 users
		//BellScenarioAccess hData = accessEntries.get(hoi);
		if (hoi.length() == 0) {
			hData = accessEntries.get(user);
		}
		if (hData == null) {
			if (hoi.length() == 0) {
				hData = new BellScenarioAccess(user);
				accessEntries.put(user, hData);
			} else {
				hData = new BellScenarioAccess(hoi);
				accessEntries.put(hoi+":"+user, hData);
				//accessEntries.put(hoi, hData);
			}
		}
		return hData;
	}
	
	@SuppressWarnings("unchecked")
	public boolean processLineDrop(String str, Object data) {


		OmParameters parms = (OmParameters) data;
		if (str != null && str.length() > 40 && str.charAt(4) == '-' && str.charAt(7) == '-' && str.charAt(10) == ' ') {
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			String hoi = "";
			String error = "";
			
			if (parms.use(date, timeMs)) {
				
				String txn = null;
				String txnData = null;
				
				/*
				 * 
2015-03-24 21:41:55,180 ERROR OMDropSession- 9948VSSQFMbGTRz8DSfyhQHLGPFfyLc2W7dhxNvJhy1bLGBch4Zy!-460034409!1427247712137|OMXI0105|SearchResultDisplayAction|E57J33L9|OR|Marineth bccs.ey31190/EY31190/EY31190
2015-03-24 21:42:39,302 ERROR OMDropSession- 9948VSSQFMbGTRz8DSfyhQHLGPFfyLc2W7dhxNvJhy1bLGBch4Zy!-460034409!1427247712137|OMXI0266|ProductConfigurationAction|E57J33L9|OR|Marineth bccs.ey31190/EY31190/EY31190
2015-03-24 21:44:20,063 ERROR OMDropSession- 2phYVSSLsTTFxJL9c8nTYjjQvWCW5l5hb43MppX1GJJHhG8nxQhK!-460034409!1427247816918|OMXI0266|ProductConfigurationAction|E57J33Q5|QR|Marilou bccs.cd6051474/6051474/6051474
2015-03-24 21:44:20,063 ERROR OMDropSession- 2phYVSSLsTTFxJL9c8nTYjjQvWCW5l5hb43MppX1GJJHhG8nxQhK!-460034409!1427247816918|OMXI0216|ProductConfigurationAction|E57J33Q5|QR|Marilou bccs.cd6051474/6051474/6051474
2015-03-24 21:44:20,063 ERROR OMDropSession- 2phYVSSLsTTFxJL9c8nTYjjQvWCW5l5hb43MppX1GJJHhG8nxQhK!-460034409!1427247816918|OMXI0462|ProductConfigurationAction|E57J33Q5|QR|Marilou bccs.cd6051474/6051474/6051474

				 */
		    	if (words.getWordCount() == 6) {
					hoi = words.getWord(3);
					error = words.getWord(1);
				
					if (hoi.length() > 0) {
						Hashtable<Long, String> hData = errorEntries.get(hoi);
						if (hData == null) {
							hData = new Hashtable<Long, String>();
							errorEntries.put(hoi, hData);
						}
						
						String oldError = hData.get(timeMs);
						if (oldError != null) {
							error = oldError + "," + error;
						}
						hData.put(timeMs, error);
					}
		    	}
		    	
			}
		}

		return true;
	}

	private String findScenario(String txn, String txnData) {

		int d = 0;
		
		for (Iterator<String[]> iterator = reportScenarioList.iterator(); iterator.hasNext();) {
			String[] items = iterator.next();
			
			if (items[0].equals(txn)) {
				if (items[1].length() == 0 && items.length == 2) {
					return reportScenarios.get(items[0]+"|"+items[1]);
					
				} else if (txnData != null && txnData.length() > 0) {
					
					StringBuilder scenario = new StringBuilder();
					scenario.append(items[0]);
					
					int count = 0;
					for (int i = 1; i < items.length; i++) {
						if (txnData.indexOf(items[i]) >= 0) {
							count++;
							scenario.append('|');
							scenario.append(items[i]);
						}
					}
					
					if (count >= items.length - 1) {
						return reportScenarios.get(scenario.toString());
					}
				}
			}
		}
		
		return null;
	}

	@SuppressWarnings("unchecked")
	public boolean processLinePerf(String str, Object data) {

		OmParameters parms = (OmParameters) data;
		if (str != null && str.length() > 40 && str.substring(23, 29).equals(" INFO ") && ! str.contains(".jsp-")) {
			
			str = Utility.replaceString(str, "configureProductsRoute.do|collapse", "configureProductsExpandCollapse.do|collapse");
			str = Utility.replaceString(str, "configureProductsRoute.do|expand", "configureProductsExpandCollapse.do|expand");
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			String hoi = "";
			String user = "";
			String type = "";
			
			if (parms.use(date, timeMs)) {
				
				String txn = null;
				String txnNorm = null;
				String txnPerfS = null;
				boolean pcsAction = str.indexOf("ProductConfiguration|Action") > 0;
				
			    if (str.indexOf("|Session|") > 0 || str.indexOf("|Service|") > 0) {
			    	if (words.getWordCount() == 4) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(3);
						type = words.getWord(1);
						
					} else if (words.getWordCount() == 6) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(5);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);
						
					} else {
						throw new RuntimeException();
					}
			    	
			    } else if (str.indexOf("|Servlet|") > 0) {
			    	if (words.getWordCount() == 5) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(4);
						type = words.getWord(1);
						
					} else if (words.getWordCount() == 7) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(6);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);

					}else {
						throw new RuntimeException();
					}
			    	
			    } else if (! pcsAction && (str.indexOf("|Action|") > 0 || str.indexOf("|JSP|") > 0)) {
			    	if (words.getWordCount() == 6) {
						txn = words.getWord(3) + "-" + words.getWord(4);
						txnNorm = words.getWord(4);
						txnPerfS = words.getWord(5);
						hoi = words.getWord(1);
						user = words.getWord(2);
						type = words.getWord(3);

					} else if (words.getWordCount() == 4) {
						txn = words.getWord(1) + "-" + words.getWord(2);
						txnNorm = words.getWord(2);
						txnPerfS = words.getWord(3);
						type = words.getWord(1);

					}else {
						throw new RuntimeException();
					}
			    	
			    } else if (str.indexOf("|XMLParser|") > 0) {
					txn = words.getWord(3);
					txnNorm = words.getWord(3);
					txnPerfS = words.getWord(5);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = "Other";

			    } else if (str.indexOf("|EBCCS|") > 0) {
					txn = words.getWord(3);
					txnNorm = words.getWord(3);
					txnPerfS = words.getWord(4);
					txnPerfS = Utility.replaceString(txnPerfS, ":", "|");
					words.setString(txnPerfS);
					txnPerfS = words.getWord(words.getWordCount()-1);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = "Downstream";
					
			    } else if (str.indexOf("|Refresh DSL Product") > 0) {
					txn = "Refresh DSL Product";
					txnNorm = "Refresh DSL Product";
					txnPerfS = Utility.stripStringKeeping(words.getWord(3), "0123456789");
					type = "Other";
					
			    } else if (words.getWordCount() > 4) {
					txn = words.getWord(3) + "-" + words.getWord(4);
					txnNorm = words.getWord(4);
					txnPerfS = words.getWord(words.getWordCount()-1);
					hoi = words.getWord(1);
					user = words.getWord(2);
					type = words.getWord(3);
					
					if (type.indexOf(".jsp") > 0) {
						txn = null;
						txnNorm = null;
						txnPerfS = "0";
						hoi = null;
						user = null;
						type = null;
						
					}
				}
			    
			    String userAction = null;
				if (pcsAction) {
					String action = words.getWord(5).replace("Path::::", "");
					String product = words.getWord(6);
					userAction = action + ":" + product;
				}
				

			    
			    if (txnNorm != null) {
				    txnNorm = txnNorm.replace("/OrderMax/", "");
				    txnNorm = txnNorm.replace(".do", "");
				    txnNorm = txnNorm.replace("ca.bell.ordermax.service.", "");
			    }
				
				long txnPerf = -1;
				if (! pcsAction) {
					try {
						txnPerf = Long.parseLong(txnPerfS);
					} catch (Exception e) {
						
						if (str.indexOf("JSON") < 0 && str.indexOf("mapPCSResponse") < 0) {
							System.err.println("Line Ignored: " + str);
						}
					}
				}
				
				String thisHoi = hoi;
				if (user!=null && user.length()>0 && (hoi == null ||hoi.length() == 0)) {
					hoi = user;
					thisHoi = user;
					userHois.put(user, "");
					
				} else if (hoi != null && hoi.length() > 0) {
					String hoi2 = userHois.get(user);
					if (hoi2 != null) {
						if (hoi2.length() == 0) {
							userHois.put(user, hoi);
						}
						hoi = user;
					}
				}
				if (pcsAction || txnPerf >= 0  && hoi != null && hoi.length() > 0) {
					txn = Utility.replaceString(txn, "ca.bell.ordermax.service.", "");
					txn = Utility.replaceString(txn, "/OrderMax/", "");
					txn = Utility.replaceString(txn, ".do", "");
					
					ScenarioData hdata = hoiData.get(hoi);
					
					if (hdata == null) {
						
						hdata = new ScenarioData(hoi, type+'-'+txnNorm, timeMs, (int) txnPerf);
						hoiData.put(hoi, hdata);
						if (userAction != null) {
							if (hdata.lastPcsAction == null || hdata.lastPcsAction.length() == 0) {
								hdata.lastPcsAction = userAction;
							} else {
								hdata.lastPcsAction = hdata.lastPcsAction +','+ userAction;
							}
							return true;
						}
						
					} else {
						if (userAction != null) {
							if (hdata.lastPcsAction == null || hdata.lastPcsAction.length() == 0) {
								hdata.lastPcsAction = userAction;
							} else {
								hdata.lastPcsAction = hdata.lastPcsAction +','+ userAction;
							}
							return true;
						} else {
							hdata.addCall(type+'-'+txnNorm, timeMs, (int) txnPerf);
						}
					}
					
					
					if (type.equals("Servlet")) {
						
						String name = null;
						BellScenarioAccess accessData = accessEntries.get(hoi+":"+user);  // Sometimes HOI modified be 2 users
						//BellScenarioAccess accessData = accessEntries.get(hoi);
						if (accessData != null) {
							
							if (accessData.getUser() != null && (user == null || user.length() == 0)) {
								user = accessData.getUser();
							}
							name = accessData.findRemoveScenarioName(timeMs-txnPerf, timeMs);
						}
						if (name == null) {
							accessData = accessEntries.get(user);
							if (accessData != null) {
								name = accessData.findRemoveScenarioName(timeMs-txnPerf, timeMs);
							}

						}
						if (name == null) {
							int dd=1;
						}
						//scenarios.add(scen);
						hoiData.remove(hoi);
						hoiData.remove(user);

						long startMs = 0;
						if (name != null) {
							hdata.cleanScenario();
							String scen = hdata.getScenario();

							String[] filter = reportScenariosFilter.get(name); 
							if (filter != null && scen.indexOf(filter[0]) >= 0) {
								name = filter[1];
							}

							hdata.setScenarioName(name);
							
//								if (name.equals("Product Configuration Page (New)")) {
//									System.out.println("Product Configuration Page (New): " + hoi + "-" + scen);
//								}								
							Integer interval = new Integer((int)(timeMs/parms.interval));
							
							OmScenarioDataIntervalElement dataElement = (OmScenarioDataIntervalElement)perfData.get(interval);
							if (dataElement == null) {
								dataElement = new OmScenarioDataIntervalElement(interval);
								perfData.put(interval, dataElement);
							}
							
							dataElement.addStats(hdata);
							
							String path = hoiPath.get(hoi);
							if (path == null || path.equals("-")) {
								path = reportScenariosPath.get(name);
								if (path != null) {
									hoiPath.put(hoi, path);
								}
							}
							
							startMs = hdata.endTimes.get(0) - hdata.timesMs.get(0);
							
							hoiWriter.writeLine(name + '\t' + thisHoi + '\t' + (timeMs-startMs) +'\t' + startMs + '\t' + timeMs +'\t' + path +'\t' + Utility.longTo24HourMilli(startMs) + '\t' + Utility.longTo24HourMilli(timeMs) + '\t' + user + '\t' + hdata.lastPcsAction + '\t' + getErrors(hoi, startMs, timeMs) + '\t' + scen);
							hdata.lastPcsAction = null;
							
							addScenario(name, scen);
							
							if (logJsp) {
								
								int i = -1;
								for (Iterator<String> iterator = hdata.calls.iterator(); iterator
										.hasNext();) {
									String call = iterator.next();
									i++;
									
									if (call.startsWith("JSP-")){
										startMs = hdata.endTimes.get(i) - hdata.timesMs.get(i);
										long tms = hdata.endTimes.get(i);
										jspWriter.writeLine(call.substring(4) + '\t' + hoi + '\t' + (tms-startMs) +'\t' + Utility.longTo24HourMilli(startMs) + '\t' + Utility.longTo24HourMilli(tms));
										
									}
								}
									
							}
						}
						userHois.remove(user);
					}
					
				}
			}
		}

		return true;
	}

	private String getErrors(String hoi, long startMs, long endMs) {
		
		StringBuilder ret = new StringBuilder();
		
		ArrayList<Long> toRemove = new ArrayList<Long>();
		
		Hashtable<Long, String> errors = errorEntries.get(hoi);
		if (errors != null) {
			Set<Long> times = errors.keySet();
			
			for (Iterator<Long> iterator = times.iterator(); iterator.hasNext();) {
				Long time = iterator.next();
				
				if (time >= startMs && time <= endMs) {
					if (ret.length() > 0) {
						ret.append(',');
					}
					
					ret.append(errors.get(time));
					toRemove.add(time);
				}
			}
	
			for (int i = 0; i < toRemove.size(); i++) {
				errors.remove(toRemove.get(i));
	
			}
		}
		
		return ret.toString();
	}

	private void addScenario(String name, String scen) {

		ArrayListNoDuplicates<String> scenarios = HEADERS.get(name);
		
		if (scenarios == null) {
			scenarios = new ArrayListNoDuplicates<String>();
			HEADERS.put(name, scenarios);
		}
		
		scenarios.add(scen);
		
	}

	public boolean recursePerformance(File dirFile, Object data) {
		int i;

		modePerformance = 2;
		String[] list;
		System.out.println("Reading files : "+perfFileStartsWith);

		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(perfFileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(perfFileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recursePerformance(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	public boolean recurseAccess(File dirFile, Object data) {
		int i;

		modePerformance = 1;
		System.out.println("Reading files : "+accessFileStartsWith);

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(accessFileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(accessFileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurseAccess(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}
	
	public boolean recurseDrop(File dirFile, Object data) {
		int i;

		modePerformance = 0;
		System.out.println("Reading files : "+dropFileStartsWith);
		
		String[] list;
		list = dirFile.list();

		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(dropFileStartsWith)) {
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
			}			
		}
		
		return true;
	}
	
	
	static FileProcessorWithData fp = null;
	static BellOmPerformanceLogsScenerioProcessor line = null;

	public static void main(String[] args) {

		if (args.length != 10 && args.length != 11) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date (yyyy-mm-dd)");
			System.err.println("         time interval in ms");
			System.err.println("         access file starts with");
			System.err.println("         drop session file starts with");
			System.err.println("         perf file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.err.println("         scenarios config file name");
			System.err.println("         end date (yyyy-mm-dd)");
			System.err.println("   Only provide end date if needed to cross midnight");
			System.exit(-1);
				
		}
		
		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0] + "      Out Dir: " + args[8]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start this one is invalid: "+args[0]);
			System.exit(0);
		}

		StringWriter.fileWrite(args[8] + File.separatorChar + "date.txt", date);
		
		line = new BellOmPerformanceLogsScenerioProcessor(args[0], args[8], args[3], args[4], args[5], args[6], args[7], args[9]);

		line.setStartPath(f.getAbsolutePath());

		OmParameters parms = new OmParameters(date, Integer.parseInt(args[2]), line.minMs, line.maxMs);
		if (args.length > 10) {
			parms.date2 = args[10];
		}
		
		if (parms.interval >= 3600000) {
			OmScenarioDataElement.STATS_SIZE = 3000;

		} else if (parms.interval >= 1800000) {
			OmScenarioDataElement.STATS_SIZE = 1000;

		} else if (parms.interval > 600000) {
			OmScenarioDataElement.STATS_SIZE = 200;
		}

		line.recurseAccess(f, parms);
		line.recurseDrop(f, parms);
		line.recursePerformance(f, parms);

		line.print(parms);

		System.out.println("Done");
		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName().substring(7, 18);
		
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

	ArrayList getHeaders(String name) {
		
		ArrayListNoDuplicates<String> header = HEADERS.get(name);
		
		if (header == null) {
			return null;
		} else {
			return header;
		}
	}
	
	void buildHeaders() {
		
		Hashtable<String, ArrayListNoDuplicates<String>> oldHeaders = HEADERS;
		HEADERS = new Hashtable<String, ArrayListNoDuplicates<String>>();
		Set<String> keys = oldHeaders.keySet();
		
		int len = 0;
		String longest = null;
		
		for (Iterator<String> iterator = keys.iterator(); iterator.hasNext();) {
			String scenarioName = iterator.next();
			len = 0;
			longest = null;
			ArrayListNoDuplicates<String> scenarios = oldHeaders.get(scenarioName);
			
			for (Iterator<String> iterator2 = scenarios.iterator(); iterator2.hasNext();) {
				String scenario = iterator2.next();
				
				if (scenario.length() > len) {
					len = scenario.length();
					longest = scenario;
				}
			}
			
			scenarios.remove(longest);

			int p = longest.indexOf(':');
			String servletLongest = longest.substring(0, p);
			int countLongest = 1;
			int count = 0;
			
			
			// Check for multiple servlets
			for (Iterator<String> iterator2 = scenarios.iterator(); iterator2.hasNext();) {
				String scenario = iterator2.next();
				
				p = scenario.indexOf(':');
				String servlet = scenario.substring(0, p);
				
				if (servlet.equals(servletLongest)) {
					countLongest++;
				} else {
					count++;
				}
			}
			
			if (count > countLongest) {
				//System.err.println("Error in Scenario: " + scenarioName + " - more than 1 Servlet");
				//System.err.println("    Scenarios: " + scenarios);
				
				//System.exit(-1);
				
			} else if (count != 0) {
				//System.err.println("Warning in Scenario: " + scenarioName + " - more than 1 Servlet");
				//System.err.println("    Scenarios: " + scenarios);
			}
									
			ArrayListNoDuplicates<String> headers = new ArrayListNoDuplicates<String>();
			addHeaders(headers, longest);
			
			for (Iterator<String> iterator2 = scenarios.iterator(); iterator2.hasNext();) {
				String scenario = iterator2.next();
				
				addHeaders(headers, scenario);
			}
			
			HEADERS.put(scenarioName, headers);
		}
				
	}

	private void addHeaders(ArrayListNoDuplicates<String> headers, String scenario) {

		int p = scenario.indexOf(':');
		
		headers.add(scenario.substring(0, p));
		scenario = scenario.substring(p+1);
		
		String[] calls = scenario.split(",");
		
		for (int i = 0; i < calls.length; i++) {
			if (calls[i].length() > 0) {
				headers.add(calls[i]);
			}
		}
	}

}
