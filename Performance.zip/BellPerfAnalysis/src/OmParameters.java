import com.followme.abastien.utilities.Utility;

/*
 * Created on Aug 22, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class OmParameters {

	String date;
	int interval;
	String date2;
	long minMs, maxMs;
	public String outDir;
	static final long MAXMS = Utility.time24HourMilliToLong("23:59:59:999");
	
	OmParameters(String date, int interval, long minMs, long maxMs) {
		this.date = date;
		this.interval = interval;
		this.minMs = minMs;
		this.maxMs = maxMs;
	}
	
	public boolean use (String pdate, long timeMs) {
		
		if (date2 == null) {
			return timeMs >= minMs && timeMs <= (maxMs) && date.equals(pdate);
			
		} else if (date.equals(pdate)) {
			return timeMs >= minMs && timeMs <= (MAXMS);
			
		} else if (date2.equals(pdate)) {
			return timeMs >= 0 && timeMs <= (maxMs);
			
		} else {
			return false;
		}
	}
}
