import java.util.Hashtable;

import com.followme.abastien.utilities.StatisticalDoubleVector;

/*
 * Created on Jan 7, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class OmScenarioDataIntervalElement {

	Integer interval;
	Hashtable<String, OmScenarioDataElement> scenarios = new Hashtable<String, OmScenarioDataElement>(); 

	public OmScenarioDataIntervalElement(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(ScenarioData scenData) {
		String name = scenData.getScenarioName();
		
		OmScenarioDataElement data = scenarios.get(name);
		
		if (data == null) {
			data = new OmScenarioDataElement(name);
			scenarios.put(name, data);
		}
		
		data.addStats(scenData);
	}
}

