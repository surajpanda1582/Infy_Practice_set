import java.util.Hashtable;

import com.followme.abastien.utilities.StatisticalDoubleVector;

/*
 * Created on Jun 4, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class PerfDataElement {
	Integer interval;
	Hashtable<String, StatisticalDoubleVector> sData = new Hashtable<String, StatisticalDoubleVector>();

	public PerfDataElement(Integer interval) {
		this.interval = interval;
	}

	public void addStats(String txn, long timeMs) {
		
		StatisticalDoubleVector data = sData.get(txn);
		
		if (data == null) {
			data = new StatisticalDoubleVector(100,100);
			
			sData.put(txn, data);
		}
		
		data.add(timeMs);
	}
}
