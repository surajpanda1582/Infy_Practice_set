import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.followme.abastien.io.FileProcessorLogServer;
import com.followme.abastien.io.FileProcessorLogWithData;
import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.DateUtility;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;
//import com.ibm.xtq.xslt.runtime.RuntimeError;

class BellOmfPerformanceLogsProcessorOrdered extends LineProcessorWithData {

	static private Pattern NUM_DASH_PATTERN = Pattern.compile("[0-9]-- ");
	public static int STATS_SIZE = 100;

	private int serverCount;
	public StringWriter writer;

	private boolean writeTransactions = false;
	public StringWriter writerTransaction;
	
	private HashMap<String, TransactionOrdered> transactionData = new HashMap<String, TransactionOrdered>(); 
	
	private String startPath = "";
	Hashtable<Integer, OmfScenarioDataElementOrdered> perfData = new Hashtable<Integer, OmfScenarioDataElementOrdered>();
	Hashtable<Integer, OmfModelDataElementOrdered> modelPerfData = new Hashtable<Integer, OmfModelDataElementOrdered>();
	Hashtable<Integer, OmfModelDataElementOrdered> pcsModelPerfData = new Hashtable<Integer, OmfModelDataElementOrdered>();

	public  static ArrayListNoDuplicates<String> channelPathList = new ArrayListNoDuplicates<String>();
	
	static Hashtable<String, String> HOI_PATH = new Hashtable<String, String>();

	ArrayList<String> servers = new ArrayList<String>();
	ArrayList<String> allServices = new ArrayList<String>();
	ArrayListNoDuplicates<String> models = new ArrayListNoDuplicates<String>();
	ArrayListNoDuplicates<String> channels = new ArrayListNoDuplicates<String>();
	ArrayListNoDuplicates<String> reportNameList = new ArrayListNoDuplicates<String>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	private WordString words = new WordString("");
	private WordString cpqWords = new WordString("");

	HashMap<String, String> txnType = new HashMap<String, String>();

	HashMap<String, Long> yifCalls = new HashMap<String, Long>();
	HashMap<String, String[]> yifCallsModel = new HashMap<String, String[]>();
	private boolean pcsSubTransaction = false;
	private boolean oesSubTransaction = false;
	private String lastFile;
//	HashMap<String, Long> channelTxnGenerator = new HashMap<String, Long>();
	static Pattern yifPattern = Pattern.compile("\\[YIFWebService\\]");
	static Pattern modelPattern = Pattern.compile("\\[PCSBFO_PERFORMANCE:CPQ:.*");
	static Pattern datePattern = Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}");

	static FileProcessorLogWithData fp = null;
	static BellOmfPerformanceLogsProcessorOrdered line = null;

	private static ArrayList detailChannels = new ArrayList();
	private static ArrayList detailService = new ArrayList();
	private static ArrayList detailSubServiceName = new ArrayList();
	private static ArrayList detailSubServiceExp = new ArrayList();

	private static HashMap<String, HoiDataOrdered> hoiFilterData;

	public static boolean LOG_DATA = false;

	public BellOmfPerformanceLogsProcessorOrdered(String dir, String outDir, String fileStartsWith, String minMs, String maxMs) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { ' ', '[', ']' });
		cpqWords.setDelimiters(new char[] { ':', '[', ']' });

		writer = new StringWriter(outDir + File.separator + "veryHighCalls.tab");
		writer.open();
		
		if (writeTransactions) {
			writerTransaction = new StringWriter(outDir + File.separator + "transactions.tab");
			writerTransaction.open();

		}
	}

	public void print(OmfParameters data) {
		
		writer.close();
		if (writeTransactions) {
			TransactionOrdered.printHeaders(writerTransaction);
			writerTransaction.close();
		}
		
		for (Iterator<String> iterator = reportNameList.iterator(); iterator.hasNext();) {
			String name = iterator.next();
			
			print(data, name);
		}
		
		if (reportNameList.size() == 0) {
			print(data, "All");
		}
		
		StringWriter writer2;
		Integer interval = new Integer((int)(minMs / data.interval));
		int maxInterval = (int)(maxMs / data.interval);
		
		Collections.sort(channels);
		Collections.sort(models);
//		System.out.println(OmfModelDataElement.maxDepCats);

		for (int k = 0; k < channels.size(); k++) {
			String channel = channels.get(k);
			
			writer2 = new StringWriter(outDir + File.separator + "models-"+channel+".tab");
			writer2.open();
			StringWriter writer3 = new StringWriter(outDir + File.separator + "modelsFireByCat-"+channel+".tab");
			writer3.open();

	
			writer2.write("\t");
			writer3.write("\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write(models.get(i) + "\t\t\t\t\t");
				writer3.write(models.get(i) + "\t\t\t\t");
			}
			writer2.writeLine("All");
			writer3.writeLine("All");
			writer2.write("Interval\t");
			writer3.write("Interval\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
				writer3.write("Num\t% All Cats\t% Cats\tAvg (ms)\t");
			}
			writer2.writeLine("Num\tAvg\t90%\t95%\tMax");
			writer3.writeLine("Num\t% All Cats\t% Cats\tAvg (ms)\t");
	
			interval = new Integer((int)(minMs / data.interval));
			while (interval.doubleValue() <= maxInterval) {
				OmfModelDataElementOrdered dataElement = modelPerfData.get(interval);   //CPQ
				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				writer3.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				
				if (dataElement != null) {
					Hashtable<String, StatisticalDoubleVector[]> channelData = dataElement.byChannelModel.get(channel);
					StatisticalDoubleVector[] channelAllData = dataElement.allStats.get(channel);

					if (channelData != null) {
						for (int i = 0; i < models.size(); i++) {
							
							StatisticalDoubleVector[] stats = channelData.get(models.get(i));
							
							if (stats != null) {
								writer2.write(stats[0].size() + "\t" + stats[0].getAverage() + "\t" + stats[0].getPercentile(.9) + "\t" + stats[0].getPercentile(.95) + "\t" + stats[0].getMaximum() + "\t");
								writer3.write(stats[1].size() + "\t" + stats[2].getAverage() + "\t" + (stats[1].getAverage()/OmfModelDataElementOrdered.maxDepCats) + "\t" + stats[0].getAverage() + "\t");
							} else {
								writer2.write("\t\t\t\t\t");
								writer3.write("\t\t\t\t");
							}
						}
					} else {
						for (int i = 0; i < models.size(); i++) {
							writer2.write("\t\t\t\t\t");
							writer3.write("\t\t\t\t");
						}						
					}
					if (channelAllData != null) {
						writer2.write(channelAllData[0].size() + "\t" + channelAllData[0].getAverage() + "\t" + channelAllData[0].getPercentile(.9) + "\t" + channelAllData[0].getPercentile(.95) + "\t" + channelAllData[0].getMaximum());
						writer3.write(channelAllData[1].size() + "\t" + channelAllData[2].getAverage() + "\t" + (channelAllData[1].getAverage()/OmfModelDataElementOrdered.maxDepCats) + "\t" + channelAllData[0].getAverage() + "\t");
				} else {
						writer2.write("0\t0\t0\t0\t0");
						writer3.write("0\t0\t0\t0\t0");
					}
				}
				
				writer2.writeLine("");
				writer3.writeLine("");
				
				interval = new Integer(interval.intValue()+1);
			}
			writer2.close();
			writer3.close();

	
			writer2 = new StringWriter(outDir + File.separator + "pcsbymodel-"+channel+".tab");
			writer2.open();
			
			writer2.write("\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write(models.get(i) + "\t\t\t\t\t");
			}
			writer2.writeLine("All");
			writer2.write("Interval\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
			}
			writer2.writeLine("Num\tAvg\t90%\t95%\tMax");
	
			interval = new Integer((int)(minMs / data.interval));
			while (interval.doubleValue() <= maxInterval) {
				OmfModelDataElementOrdered dataElement = pcsModelPerfData.get(interval);   //PCS
				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				
				if (dataElement != null) {
					Hashtable<String, StatisticalDoubleVector[]> channelData = dataElement.byChannelModel.get(channel);
					StatisticalDoubleVector[] channelAllData = dataElement.allStats.get(channel);

					if (channelData != null) {
						for (int i = 0; i < models.size(); i++) {
							StatisticalDoubleVector[] stats = channelData.get(models.get(i));
							
							if (stats != null) {
								writer2.write(stats[0].size() + "\t" + stats[0].getAverage() + "\t" + stats[0].getPercentile(.9) + "\t" + stats[0].getPercentile(.95) + "\t" + stats[0].getMaximum() + "\t");
							} else {
								writer2.write("\t\t\t\t\t");
							}
						}
					} else {
						for (int i = 0; i < models.size(); i++) {
							writer2.write("\t\t\t\t\t");
						}						
					}
	
					if (channelAllData != null) {
						writer2.write(channelAllData[0].size() + "\t" + channelAllData[0].getAverage() + "\t" + channelAllData[0].getPercentile(.9) + "\t" + channelAllData[0].getPercentile(.95) + "\t" + channelAllData[0].getMaximum());
					} else {
						writer2.write("0\t0\t0\t0\t0");
					}
				}
				
				writer2.writeLine("");
				
				interval = new Integer(interval.intValue()+1);
			}
			
			writer2.close();
		}
		
		for (int k = 0; k < channelPathList.size(); k++) {
			String channel = channelPathList.get(k);
			
			Collections.sort(OmfModelDataElementOrdered.categoryModelList);
			
			writer2 = new StringWriter(outDir + File.separator + "modelCategory-"+channel+".tab");
			writer2.open();
			
			writer2.write("Model-Category\tAll #\tAll Avg\t");
			interval = new Integer((int)(minMs / data.interval));
			while (interval.doubleValue() <= maxInterval) {
				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t\t\t\t\t");
				interval = new Integer(interval.intValue()+1);
			}
			writer2.writeLine("");
			
			interval = new Integer((int)(minMs / data.interval));
			writer2.write("\t");
			while (interval.doubleValue() <= maxInterval) {
				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
				interval = new Integer(interval.intValue()+1);
			}
			writer2.writeLine("");
			
			for (int i = 0; i < OmfModelDataElementOrdered.categoryModelList.size(); i++) {
				String name = OmfModelDataElementOrdered.categoryModelList.get(i);
				
				int count = 0;
				double avg = 0;
				interval = new Integer((int)(minMs / data.interval));
				while (interval.doubleValue() <= maxInterval) {
					
					OmfModelDataElementOrdered dataElement = modelPerfData.get(interval);
					
					if (dataElement != null) {
						Hashtable<String, StatisticalDoubleVector> modelCategoryData = dataElement.modelCategory.get(channel);

						if (modelCategoryData != null) {
							StatisticalDoubleVector stats = modelCategoryData.get(name);
							
							if (stats != null) {
								count += stats.size();
								avg += stats.getAverage()*stats.size();
							} 
						}
					} 					

					interval = new Integer(interval.intValue()+1);
				}

				if (count > 0) {
					writer2.write(name + "\t" + count + "\t" + (avg/count) + "\t");
	
					interval = new Integer((int)(minMs / data.interval));
					while (interval.doubleValue() <= maxInterval) {
						
						OmfModelDataElementOrdered dataElement = modelPerfData.get(interval);
						
						if (dataElement != null) {
							Hashtable<String, StatisticalDoubleVector> modelCategoryData = dataElement.modelCategory.get(channel);
	
							if (modelCategoryData != null) {
								StatisticalDoubleVector stats = modelCategoryData.get(name);
								
								if (stats != null) {
									writer2.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
								} else {
									writer2.write("\t\t\t\t\t");
								}
							}
						} else {
								writer2.write("\t\t\t\t\t");
						}						
	
						interval = new Integer(interval.intValue()+1);
					}
					writer2.writeLine("");
				}
			}
			
			writer2.close();

		}
		
		System.out.println("Done");

	}		
	
	public ArrayList<String> getServices(String name) {
		
		ArrayListNoDuplicates<String> services = new ArrayListNoDuplicates<String>();
		
		Set<Integer> keys = perfData.keySet();
		
		for (Iterator<Integer> iterator = keys.iterator(); iterator.hasNext();) {
			Integer key = iterator.next();
			
			OmfScenarioDataElementOrdered dataElement = perfData.get(key);
			NameDataOrdered nData = null;
			if (dataElement != null) {
				nData = dataElement.sData.get(name);
			}
			
			if (nData != null) {
				Set<String> sKeys = nData.byService.keySet();
				services.addAllNoDup(sKeys);
			}
		}
		
		return services;
	}
	
	public void print(OmfParameters data, String name) {

		Integer interval = new Integer((int)(minMs / data.interval));
		int maxInterval = (int)(maxMs / data.interval);
		
		Collections.sort(servers);
		
		ArrayList<String> services = getServices(name);
		Collections.sort(services);

//		for (int si = 0; si < servers.size(); si++) {
//			String server = servers.get(si);
//			interval = new Integer((int)(minMs / data.interval));
//
//			StringWriter writer2 = new StringWriter(outDir + File.separator + "server-"+name+'-'+server+".tab");
//			writer2.open();
//	
//			writer2.write("\t");
//			for (int i = 0; i < services.size(); i++) {
//				writer2.write(services.get(i) + "\t\t\t\t\t");
//			}
//			writer2.writeLine("All");
//			writer2.write("Interval\t");
//			for (int i = 0; i < services.size(); i++) {
//				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
//			}
//			writer2.writeLine("Num\tAvg\t90%\t95%\tMax");
//	
//			while (interval.doubleValue() <= maxInterval) {
//				OmfScenarioDataElement dataElement = perfData.get(interval);
//				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
//				NameData nData = null;
//				if (dataElement != null) {
//					nData = dataElement.sData.get(name);
//				}
//				
//				if (nData != null) {
//					
//					StatisticalDoubleVector allServerData = nData.allStatsByServer.get(server);
//					
//					for (int i = 0; i < services.size(); i++) {
//						StatisticalDoubleVector stats = nData.byServer.get(server+":"+services.get(i));
//						
//						if (stats != null) {
//							writer2.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
//						} else {
//							writer2.write("\t\t\t\t\t");
//						}
//					}
//					
//					if (allServerData != null) {
//						writer2.write(allServerData.size() + "\t" + allServerData.getAverage() + "\t" + allServerData.getPercentile(.9) + "\t" + allServerData.getPercentile(.95) + "\t" + allServerData.getMaximum());
//					} else {
//						writer2.write("\t\t\t\t\t");
//					}
//				}
//				
//				writer2.writeLine("");
//				
//				interval = new Integer(interval.intValue()+1);
//			}
//			writer2.writeLine("");
//			writer2.close();
//		}
		
		StringWriter writer2 = new StringWriter(outDir + File.separator + "services-"+name+".tab");
		writer2.open();
		
		writer2.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write(services.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			OmfScenarioDataElementOrdered dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			NameDataOrdered nData = null;
			if (dataElement != null) {
				nData = dataElement.sData.get(name);
			}

			if (nData != null) {
				
				for (int i = 0; i < services.size(); i++) {
					StatisticalDoubleVector stats = nData.byService.get(services.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(nData.allStats.size() + "\t" + nData.allStats.getAverage() + "\t" + nData.allStats.getPercentile(.9) + "\t" + nData.allStats.getPercentile(.95) + "\t" + nData.allStats.getMaximum());
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.close();

		
	}

	public boolean checkLastLines(String str, Object data) {

		if (str == null) {
			return false;
		}
		
		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50) {
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			
			if (time == null) {
				return true;
			}
			
			long timeMs = Utility.time24HourMilliToLong(time);
			
			if (parms.before(date, timeMs)) {
				//System.out.println("Skipping: " + date + " - " + time);
				return false;  //End if earlier than start time
			}
		}
		
		return true;
	}

	public boolean processLine(String str, Object data) {

//		if (! ((FileProcessorLogWithData)ivFP).getCurrentFile().equals(lastFile)) {
//			lastFile = ((FileProcessorLogWithData)ivFP).getCurrentFile();
//			txnType.clear();
//		}
		
		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			
			str = Utility.replaceString(str, "- Target ", "- ");
			str = Utility.replaceString(str, " (self-tuning)'", "");
			
			if (str.indexOf("OrderControlService.cancelOrder") > 0 && str.indexOf("OrderSubmission.OrderDispatchDelegateImpl.sendReceive") > 0) {
				int dd = 0;
			}

			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);
			
			if (parms.after(date, timeMs)) {
				return false;  //End if past test time
			}
			

			//System.out.println(str);
			//for (int i = 0; i < words.getWordCount(); i++) {
			//	System.out.println(i + " -> " + words.getWord(i));
			//}
			if (parms.use(date, timeMs)) {
				
				
				str = str.replaceAll("\\[ +", "[");
				words.setString(str);
				if (str.indexOf("CACHE_") > 0) {
				    Matcher matcher = NUM_DASH_PATTERN.matcher(str);
				    if (matcher.find()) {
				    	int p = matcher.start(); 
				    	str = str.substring(0, p+1);
				    }
					words.setString(str);
				}

				String txn = words.getWord(6);
				
				txn = txn.replace("OMF.", "");
				int p = str.indexOf(" PERFORMANCE-");
				String txn2 = words.getWord(16);
				if (txn2 != null) txn2 = txn2.replace("OMF.", "");
				String srvTxn2 = txn2;
				if (p > 0) {
					txn2 = str.substring(p+13).trim();
				}

				if (str.indexOf("orderRetrievalService") > 0) {
					int dd = 0;
				}

				String channel = words.getWord(8);
				String hoi = words.getWord(10);
				String stxnPerf = words.getWord(words.getWordCount()-1);
				p = stxnPerf.lastIndexOf(':');
				if (p > 0) {
					stxnPerf = stxnPerf.substring(p+1);
				}
				
				if (Utility.isNumber(stxnPerf) && (detailChannels.size()==0 || detailChannels.contains(channel))) {
					long txnPerf = Long.parseLong(stxnPerf);
					
					//String consumer = words.getWord(8);
					String txnId = words.getWord(4);
					String txnSrvcName = null;
					if (txnId.length() == 0) {
						txnId = hoi;
					} else {
						txnSrvcName = txnType.get(txnId);
						if ((str.indexOf("5-09-03 01:16:13") > 0 || str.indexOf("5-09-03 01:16:14") > 0) && str.indexOf("TranID-[L82L22V3]") > 0) {
							int dd = 0;
						}
						if (txnSrvcName == null) {
							if (txnId.length() > 0 && str.indexOf("handleResponse") < 0) {
								txnType.put(txnId, txn);
							}
						} else {
							txn = txnSrvcName;
						}
					}
					if (txnId.length() == 0 && hoi.length() == 0) {
//						Long id = channelTxnGenerator.get(channel+'-'+txn);
//						if (id == null) {
//							id = 1L;
//							channelTxnGenerator.put(channel+'-'+txn, id);
//						}
						txnId = channel+'-'+txn;
					}

					p = txn.indexOf('.');
					//String txnOperName = "";
					txnSrvcName = txn;
					if (p > 0) {
						//txnOperName = txn.substring(p+1);
						txnSrvcName = txn.substring(0, p);
					}
					
					if (srvTxn2 != null && srvTxn2.indexOf(txnSrvcName+'.') >= 0) {
						srvTxn2 = txnSrvcName;
					}
					
					if (txnPerf > 0) {
						
						HoiDataOrdered hData = null;
						String name = null;
						if (hoiFilterData != null) {
							hData = hoiFilterData.get(hoi);
							if (hData != null) {
								name = hData.findTime(timeMs);
								if (name != null) {
									reportNameList.add(name);
								}
							}
						}
						
						if (hoiFilterData == null || name != null) { 
							
							Integer interval = new Integer((int)(timeMs/parms.interval));
							
							if (serverCount < 1000 && txnPerf > 20000) {
								writer.writeLine(txn + "\t" + txnPerf + "\t" + getCurrentServer() + "\t" + str);
								serverCount++;
							}
							
							Matcher matcher = modelPattern.matcher(txn2);
							//Process CPQ model times
							if (("ProductConfigurationService.configureProducts".equals(txn) || "ProductConfigurationService.productConfigurationRequest".equals(txn)) && matcher.find()) {
								
								Long yif = yifCalls.get(txnId);
								
								if (yif != null) {
									if (pcsSubTransaction) {
										yifCalls.remove(txnId);
									}
									processModelData(interval, txnId, txn2, channel, yif, HOI_PATH.get(hoi));
								}
							}
							
							boolean subTxn = false;
							if (txn != null && ! txn.equals(srvTxn2) && txn.length() > 0) {
								String txn3 = matchSubTransation(txn, txn2);
								if (str.indexOf("1d27da4d02db") > 0) {
									int dd = 0;
								}
								if (txn3 != null) {
									txn = txn3;
									txn2 = txn3;
									srvTxn2 = txn3;
									txnSrvcName = txn3;
									subTxn = true;
									if (txn.indexOf("ProductConfigurationService.productConfigurationRequest") >= 0 || txn.indexOf("ProductConfigurationService.configureProducts") >= 0) {
										pcsSubTransaction  = true;
									}
									if (txn.indexOf("ProductAvailabilityService.getOfferEligibility") >= 0) {
										oesSubTransaction  = true;
									}
								}
							}
							
							if (yifPattern.matcher(txn2).find()) { // Only works if no sub transaction on OCS and OES
								txn = "YIFWebService";
								txn2 = "YIFWebService";
								srvTxn2 = "YIFWebService";
								
							}
							
							if (txn != null && txn.length() > 0 && ("YIFWebService".equals(srvTxn2) || txnSrvcName.equals(srvTxn2))) {
								
								if (txnSrvcName.equals(srvTxn2) && !subTxn) {
									txnType.remove(txnId);
	//								Long id = channelTxnGenerator.get(channel+'-'+txn);
	//								if (id != null) {
	//									id++;
	//									channelTxnGenerator.put(channel+'-'+txn, id);
	//								}
								}
								if (txn.trim().length()==0) {
									//System.out.println("ERROR: Blank Transaction: "+str);
									return true;
								}
//								if (!servers.contains(currentServer)) {
//									servers.add(currentServer);
//								}
								
								
								OmfScenarioDataElementOrdered dataElement = perfData.get(interval);
								if (dataElement == null) {
									dataElement = new OmfScenarioDataElementOrdered(interval);
									perfData.put(interval, dataElement);
								}
	
								
								if ("YIFWebService".equals(srvTxn2)) {
									
									yifCalls.put(txnId, new Long(txnPerf));
								
								} else if (srvTxn2.indexOf("YIFWebService") >= 0 || srvTxn2.indexOf("CPQ") >= 0) {
									
									yifCalls.put(txnId, new Long(txnPerf));
									dataElement.addStats(getCurrentServer(), txn, txnPerf, name); 
									if (writeTransactions) {
										addTransaction(txnId, timeMs, txn, txnPerf);
									}

									if (LOG_DATA) System.out.println(hoi+"\t"+txn+"\t"+txnPerf);
									
									if (!allServices.contains(txn)) {
										allServices.add(txn);
									}
									
								} else if ((!pcsSubTransaction && txn.equals("ProductConfigurationService.configureProducts")) || 
										   (!pcsSubTransaction && txn.equals("ProductConfigurationService.productConfigurationRequest")) ||
										   (!oesSubTransaction && txn.equals("ProductAvailabilityService.getOfferEligibility"))) {
									
									Long yif = yifCalls.get(txnId);
									if (yif != null) {
										yifCalls.remove(txnId);
										if (txn.indexOf("getProductAvail") > 0) {
											int dd = 0;
										}
										
										long lyif = yif.longValue();
										
										txnPerf -= lyif;
	
										if (!allServices.contains(txn+"-CPQ")) {
											allServices.add(txn+"-CPQ");
										}
										dataElement.addStats(getCurrentServer(), txn+"-CPQ", lyif, name);
										if (writeTransactions) {
											addTransaction(txnId, timeMs, txn+"-CPQ", lyif);
										}
										if (LOG_DATA) System.out.println(hoi+"\t"+txn+"-CPQ"+"\t"+lyif);
										
										if (!allServices.contains(txn)) {
											allServices.add(txn);
										}
										dataElement.addStats(getCurrentServer(), txn, txnPerf, name);
										if (writeTransactions) {
											addTransaction(txnId, timeMs, txn, txnPerf);
										}

										if (LOG_DATA) System.out.println(hoi+"\t"+txn+"\t"+txnPerf);
										
										if (txnSrvcName.equals("ProductConfigurationService")) {
											String[] modelData = yifCallsModel.get(txnId);
											if (modelData != null) {
												yifCallsModel.remove(txnId);
												
												OmfModelDataElementOrdered dataElement2 = pcsModelPerfData.get(interval);
												if (dataElement2 == null) {
													dataElement2 = new OmfModelDataElementOrdered(interval);
													pcsModelPerfData.put(interval, dataElement2); 
												}
												
												channels.add(channel);
	
												dataElement2.addData(channel, modelData, txnPerf, false, HOI_PATH.get(hoi)); 
											}
										}
										
									} else {
										if (!allServices.contains(txn)) {
											allServices.add(txn);
										}
										dataElement.addStats(getCurrentServer(), txn, txnPerf, name);
										if (writeTransactions) {
											addTransaction(txnId, timeMs, txn, txnPerf);
										}

										if (LOG_DATA) System.out.println(hoi+"\t"+txn+"\t"+txnPerf);
	
										if (! pcsSubTransaction && (txn.equals("ProductConfigurationService.productConfigurationRequest") || 
												txn.equals("ProductConfigurationService.configureProducts")) && txnPerf > 1000) {
											System.out.println("ERR: PCS no YIF: " + ivFP.ivLineCounter + " - " + channel + " - " + hoi + " - " + str.substring(0, 24));
										}
									}
									
								} else {
				
									if (!allServices.contains(txn)) {
										allServices.add(txn);
									}
									
									dataElement.addStats(getCurrentServer(), txn, txnPerf, name);
									if (writeTransactions) {
										addTransaction(txnId, timeMs, txn, txnPerf);
									}

									if (LOG_DATA) System.out.println(hoi+"\t"+txn+"\t"+txnPerf);
								}
								
								if (txnSrvcName.equals(srvTxn2) && ! subTxn) {
									TransactionOrdered transaction = transactionData.get(txnId);
									
									if (transaction != null) {
										transactionData.remove(txnId);
										
										transaction.print(writerTransaction, txn, txnPerf);
									}
								}
							}
						}
					} else if (txnSrvcName.equals(txn2)) {
						System.err.println("Zero Time: " + str);
					}
				} else if (txn.equals(txn2)) {
					System.err.println("ERR in: " + str);
				}
			}
		}

		return true;
	}

	private String getCurrentServer() {
		return fp.getCurrentServer();
	}

	private void addTransaction(String txnId, long timeMs, String txn, long txnPerf) {

		TransactionOrdered transaction = transactionData.get(txnId);
		
		if (transaction == null) {
			transaction = new TransactionOrdered(txnId, timeMs-txnPerf);
			transactionData.put(txnId, transaction);
		}
		
		transaction.addData(txn, txnPerf);
		
	}

	private void addModel(String txnId, String model) {

		TransactionOrdered transaction = transactionData.get(txnId);
		
		transaction.setModel(model);
		
	}

	/**
	 * @param interval
	 * @param txnId
	 * @param txn2
	 * @param channel
	 * @param yif
	 */
	private void processModelData(Integer interval, String txnId, String txn2,
			String channel, Long yif, String path) {
		cpqWords.setString(txn2);
		String model = cpqWords.getWord(3);
		
		String dependentCats = "-1";
		String action = "";
		if (cpqWords.getWordCount() > 6) {
			dependentCats = cpqWords.getWord(4);
			action = cpqWords.getWord(7);
		}
		models.add(model);
		
		if (writeTransactions) {
			addModel(txnId, model);
		}
		
		String[] modelData = new String[] {model, action, dependentCats};
		yifCallsModel.put(txnId, modelData);
		
		OmfModelDataElementOrdered dataElement = modelPerfData.get(interval);
		if (dataElement == null) {
			dataElement = new OmfModelDataElementOrdered(interval);
			modelPerfData.put(interval, dataElement);
		}
		
		channels.add(channel);

		dataElement.addData(channel, modelData, yif.longValue(), true, path);
	}

	public boolean recurse(File dirFile, Object data, long start) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				//int p1 = child.getName().indexOf('_');
				//int p2 = child.getName().indexOf(".log");
				//String server = child.getName().substring(p1+1, p2);
				
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					try {
						num -= Integer.parseInt(ext);
					} catch (NumberFormatException ignored) {
						
					}
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		ArrayList<String> filenames = new ArrayList<String>();
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			if (isValidFile(dirFile.getAbsolutePath() + File.separator + fileName)) {
				filenames.add(dirFile.getAbsolutePath() + File.separator + fileName);
			} else {
				filenames.add("*"+dirFile.getAbsolutePath() + File.separator + fileName);
			}
			
		}

		try {

			fp = new FileProcessorLogWithData(filenames, line, data, true);
			fp.processFile();
			fp.close();

		} catch (Exception e) {

			e.printStackTrace();
			System.exit(-1);
		}

//			File child = new File(dirFile, fileName);
//
//			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
//				
//				long time = 0;
//				if (i > 0) {
//					long msPer = ((System.currentTimeMillis()-start) / (i));
//					time = (files.size()-i) * msPer;
//					System.out.println("Processing: "+child.getName() + " approximately " + Utility.longTo24DayHour((time+500)/1000L) + " - each: " + Utility.longTo24HourMilli(msPer));
//				} else {
//					System.out.println("Processing: "+child.getName());
//					
//				}
//				
//				try {
//
//					setCurrentFile(child);
//					txnType.clear();
//
//					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);
//
//				} catch (Exception e) {
//
//					System.out.println("Can't open file: " + child.getAbsolutePath());
//					e.printStackTrace();
//					System.exit(-1);
//				}
//
//				fp.processFile();
//				fp.close();
//				
//			} else if (child.isDirectory()) {
//
//				boolean ret = recurse(child, data, start);
//				if (!ret)
//					return ret;
//
//			}
//		}

		return true;
	}

	private boolean isValidFile(String fileName) {
		
		File file = new File(fileName);
		
		String[] lines = Utility.getFileStart(file, 1);
		if (lines[0] == null) {
			System.out.println("Empty file: " + fileName);
			return false;
		}
		String line1 = lines[0].substring(0, 23);
		String lineN = Utility.tailFile(file, 2)[0].substring(0, 23);
		
		SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS");
		try {
			long time0 = f.parse(line1).getTime();
			long timeN = f.parse(lineN).getTime();

			long diffHours = timeN - time0;
			diffHours /= 3600000;
			
			if (diffHours > 5) {
				System.out.println("Problem in File Times: " + fileName + ": " + line1 + " -> " + lineN);
				return false;
			}
		} catch (ParseException e) {
			e.printStackTrace();
			System.exit(-1);
		}
		
		return true;
	}

	public static void main(String[] args) {

		if (args.length < 7) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date yyyy-mm-dd");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.err.println("         config file [Optional]");
			System.err.println("         end date (yyyy-mm-dd)");
			System.err.println("   Only provide end date if needed to cross midnight");
			System.exit(-1);
				
		}
		
		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0] + "      Out Dir: " + args[6]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellOmfPerformanceLogsProcessorOrdered(args[0],args[6],args[3], args[4], args[5]);
		}

		String endDate = null;
		if (args.length > 7) {
			
			Matcher matcher = datePattern.matcher(args[7]);

			if (matcher.find()) {
				endDate = args[7];
			} else {
				parseCfg(args[7], args[0], args[6]);
			}
			
			if (args.length > 8) {
				endDate = args[8];
			}
		}

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(date, Integer.parseInt(args[2]));
		parms.date2 = endDate;
		parms.setStartEnd(args[4], args[5]);
		
		if (parms.interval >= 3600000) {
			STATS_SIZE = 3000;

		} else if (parms.interval >= 1800000) {
			STATS_SIZE = 1000;

		} else if (parms.interval > 600000) {
			STATS_SIZE = 200;
		}

		line.recurse(f, parms, System.currentTimeMillis());

		line.print(parms);

		exit(0);
	}

	private String matchSubTransation(String txn, String txn2) {

		for (int i = 0; i < detailService.size(); i++) {
			
			if (detailService.get(i).equals(txn)) {
				if (((Pattern)detailSubServiceExp.get(i)).matcher(txn2).find()) {
					return txn+"."+detailSubServiceName.get(i);
				}
			}
		}
		return null;
	}

	
	@SuppressWarnings("unchecked")
	private static void parseCfg(String fileName, String dir1, String dir2) {
		StringReader reader = new StringReader(fileName);
		
		if (reader.open() != 0) {
			System.out.println("Cannot open config file: "+fileName);
			throw new RuntimeException("Cannot open config file: "+fileName);
		}
		
		String lineStr = reader.readLine();
		String service = null;
		
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length()==0 || lineStr.charAt(0) == '#') {
				//nop - comment line or blank line
				
			}else if (lineStr.toUpperCase().startsWith("*HOI_FILE=")) {
				int pos = fileName.lastIndexOf(File.separatorChar);
				
				String hoiFilterFilename = lineStr.substring(10).trim();
				if (pos > 0) {
					String dir = fileName.substring(0, pos+1);
					hoiFilterFilename = dir + lineStr.substring(10).trim();
				} 
				
				if (! (new File(hoiFilterFilename).exists())) {
					hoiFilterFilename = dir1 + File.separator  + lineStr.substring(10).trim();
				}
				if (! (new File(hoiFilterFilename).exists())) {
					hoiFilterFilename = dir2 + File.separator  + lineStr.substring(10).trim();
				}
				parseHoiFile(hoiFilterFilename);
				
			}else if (lineStr.charAt(0) == '[') {
				service = lineStr.substring(1, lineStr.length()-1).trim();
				
			} else {
				int p = lineStr.indexOf('=');
				
				if (p >0) {
					String name = lineStr.substring(0, p).trim();
					String value = lineStr.substring(p+1).trim();
					
					if (name.equals("*CHANNEL*")) {
						detailChannels.add(value);
					} else {
						detailService.add(service);
						detailSubServiceName.add(name);
						detailSubServiceExp.add(Pattern.compile(value));
					}
				}
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
	}

	private static void parseHoiFile(String fileName) {

		System.out.println("Reading " + fileName);
		StringReader reader = new StringReader(fileName);
		int count = 0;

		hoiFilterData = new HashMap<String, HoiDataOrdered>();
		
		if (reader.open() != 0) {
			System.out.println("Cannot open config file: "+fileName);
			throw new RuntimeException("Cannot open config file: "+fileName);
		}
		
		String lineStr = reader.readLine();
		if (lineStr != null) {
			lineStr = reader.readLine();  // Skip header
		}
		
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length() > 0) {
				String[] data = lineStr.split("\\t");
				
				HoiDataOrdered hdata = hoiFilterData.get(data[1]);
				if (hdata == null) {
					hdata = new HoiDataOrdered(data[1]);
					hoiFilterData.put(data[1], hdata);
				}
				hdata.addData(data[0], Long.parseLong(data[3]), Long.parseLong(data[4]));

				if (data[5].length() > 1) {
					String path = HOI_PATH.get(data[1]);
					if (path == null || path.equals("-")) {
						HOI_PATH.put(data[1], data[5]);
					}
				}
				count++;
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
		System.out.println("Read " + count);
		
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	
	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}

class OmfModelDataElementOrdered {

	Integer interval;
	
										// Response time, dependent cats, no actions
	Hashtable<String, Hashtable<String, StatisticalDoubleVector[]>> byChannelModel = new Hashtable<String, Hashtable<String, StatisticalDoubleVector[]>>(); 
	static int maxDepCats;
	
	Hashtable<String, StatisticalDoubleVector[]> allStats = new Hashtable<String, StatisticalDoubleVector[]>();
	Hashtable<String, Hashtable<String, StatisticalDoubleVector>> modelCategory = new Hashtable<String, Hashtable<String, StatisticalDoubleVector>>();

	public  static ArrayListNoDuplicates<String> categoryModelList = new ArrayListNoDuplicates<String>();
	
	OmfModelDataElementOrdered(Integer interval) {
		this.interval = interval;
	}

										// model, action, cats
	void addData(String channel, String[] modelData, long timems, boolean recordModelCat, String path) {
		
		Hashtable<String, StatisticalDoubleVector[]> channelData = byChannelModel.get(channel);
		if (channelData == null) {
			channelData = new Hashtable<String, StatisticalDoubleVector[]>();
			byChannelModel.put(channel, channelData);
		}

		StatisticalDoubleVector[] data = channelData.get(modelData[0]);
		
		if (data == null) {
			data = new StatisticalDoubleVector[] {new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10), new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10), new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10)};
			channelData.put(modelData[0], data);
		}
		
		data[0].add(timems);
		int numDepCats = Integer.parseInt(modelData[2]);
		if (modelData[1].length() == 0) {
			maxDepCats = Math.max(maxDepCats, numDepCats);
		}
		data[1].add(numDepCats);
		data[2].add(modelData[1].length() == 0?1:0);

		StatisticalDoubleVector[] channelAllData = allStats.get(channel);
		if (channelAllData == null) {
			channelAllData = new StatisticalDoubleVector[] {new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10), new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10), new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE/10)};
			allStats.put(channel, channelAllData);
		}
		channelAllData[0].add(timems);
		channelAllData[1].add(numDepCats);
		channelAllData[2].add(modelData[1].length() == 0?1:0);
		
		String channelPath = channel+"-"+path;
		BellOmfPerformanceLogsProcessorOrdered.channelPathList.add(channelPath);
		if (recordModelCat) {
			Hashtable<String, StatisticalDoubleVector> channelModel = modelCategory.get(channelPath);
			if (channelModel == null) {
				channelModel = new Hashtable<String, StatisticalDoubleVector>();
				modelCategory.put(channelPath, channelModel);
			}
			String key = modelData[0]+'-'+modelData[1];
			StatisticalDoubleVector category = channelModel.get(key);
			if (category == null) {
				category = new StatisticalDoubleVector(500, 500);
				channelModel.put(key, category);
			}
			category.add(timems);
			categoryModelList .add(key);
		}
	}
	
}

class NameDataOrdered {
	
	StatisticalDoubleVector allStats = new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE,BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE);
//	Hashtable<String, StatisticalDoubleVector> byServer = new Hashtable<String, StatisticalDoubleVector>(); 
//	Hashtable<String, StatisticalDoubleVector> allStatsByServer = new Hashtable<String, StatisticalDoubleVector>(); 
	Hashtable<String, StatisticalDoubleVector> byService = new Hashtable<String, StatisticalDoubleVector>(); 
}

class OmfScenarioDataElementOrdered {
	
	Integer interval;
	Hashtable<String, NameDataOrdered> sData = new Hashtable<String, NameDataOrdered>();
	
	OmfScenarioDataElementOrdered(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(String server, String service, double value, String name) {
		StatisticalDoubleVector data, data2;
		
		if (service.trim().length()==0) {
			throw new RuntimeException("Blank Transaction");
		}

		if (name == null) {
			name = "All";
		}
		
		NameDataOrdered dt = sData.get(name);
		
		if (dt == null) {
			dt = new NameDataOrdered();
			sData.put(name, dt);
		}
		
		dt.allStats.add(value);
		
//		data = dt.byServer.get(server+":"+service);
//		if (data == null) {
//			data = new StatisticalDoubleVector(500, 100);
//			dt.byServer.put(server+":"+service, data);
//		}
//		data2 = dt.allStatsByServer.get(server);
//		if (data2 == null) {
//			data2 = new StatisticalDoubleVector(500, 100);
//			dt.allStatsByServer.put(server, data2);
//		}
		
//		data.add(value);
//		data2.add(value);
		
		data = dt.byService.get(service);
		if (data == null) {
			data = new StatisticalDoubleVector(BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE, BellOmfPerformanceLogsProcessorOrdered.STATS_SIZE);
			dt.byService.put(service, data);
		}
		
		data.add(value);

	}

}


class HoiDataOrdered {
	
	String hoi;
	String path;
	ArrayList<Long[]> times = new ArrayList<Long[]>();
	ArrayList<String> names = new ArrayList<String>();
	
	
	public HoiDataOrdered(String hoi) {
		this.hoi = hoi;
	}


	public String findTime(long timeMs) {
		
		for (int i = 0; i < times.size(); i++) {
			Long[] tms = times.get(i);
			
			if (timeMs >= tms[0] && timeMs <= tms[1]) {
				return names.get(i);
			}
		}
		
		return null;
	}


	public void addData(String name, long startMs, long endMs) {

		times.add(new Long[]{startMs, endMs});
		names.add(name);
		
	}
	
}

class TransactionOrdered implements Comparable<TransactionOrdered> {
	long startTime;
	long endTime;
	String id;
	String model;
	
	static HashMap<String, ArrayList<String>> printedTxn = new HashMap<String, ArrayList<String>>();
	
	HashMap<String, Long> data = new HashMap<String, Long>();
	
	public TransactionOrdered(String id, long startTime) {
		this.id = id;
		this.startTime = startTime;
	}

	public void print(StringWriter writerTransaction, String name, long timeMs) {

		data.remove(name);
		
		StringBuilder str = new StringBuilder();

		ArrayList<String> columns = printedTxn.get(name);
		if (columns == null) {
			columns = new ArrayList<String>();
			printedTxn.put(name, columns);
			if (model != null) {
				columns.add("Model");
			}
		}
		
		str.append(name);
		
		str.append('\t');
		str.append(Utility.longTo24HourMilli(startTime));
		
		str.append('\t');
		str.append(timeMs);

		if (model != null) {
			str.append('\t');
			str.append(model);
		}
		
		for (Iterator<String> iterator = data.keySet().iterator(); iterator.hasNext();) {
			String key = iterator.next();
			
			if (! columns.contains(key)) {
				columns.add(key);
			}
		}
		
		for (Iterator<String> iterator = columns.iterator(); iterator.hasNext();) {
			String key = iterator.next();

			if (! key.equals("Model")) {
				str.append('\t');
				Long time = data.get(key);
			
				str.append(time == null? 0:time);
			}
		}

		writerTransaction.writeLine(str.toString());
		
	}

	public static void printHeaders(StringWriter writerTransaction) {
		
		for (Iterator<String> iterator = printedTxn.keySet().iterator(); iterator.hasNext();) {
			String key = iterator.next();
			ArrayList<String> columns = printedTxn.get(key);
			
			StringBuilder str = new StringBuilder();
	
			str.append(key);
	
			str.append('\t');
			str.append(0);
			str.append('\t');
			str.append(0);
			
			for (Iterator<String> iterator1 = columns.iterator(); iterator1.hasNext();) {
				String key1 = iterator1.next();
				str.append('\t');
				int p = key1.lastIndexOf('.');
				str.append(key1.substring(p+1));
			}
	
			writerTransaction.writeLine(str.toString());
			
			str.setLength(0);
		}
	}

	
	@Override
	public int compareTo(TransactionOrdered o) {
		
		return (int)(startTime-o.startTime);
	}
	
	public void addData(String txn, long txnPerf) {
		
		Long old = data.get(txn);
		
		if (old != null) {
			txnPerf += old;
		}
		data.put(txn, txnPerf);
	}
	
	public void setModel(String model) {
		
		this.model = model;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static HashMap<String, ArrayList<String>> getPrintedTxn() {
		return printedTxn;
	}

	public static void setPrintedTxn(HashMap<String, ArrayList<String>> printedTxn) {
		TransactionOrdered.printedTxn = printedTxn;
	}

	public HashMap<String, Long> getData() {
		return data;
	}

	public void setData(HashMap<String, Long> data) {
		this.data = data;
	}

	public String getModel() {
		return model;
	}
}

