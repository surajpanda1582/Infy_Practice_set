import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellOmfTraceLogsOrQsSvcPntProb extends LineProcessorWithData {

	private static final String S_ENVELOPE = "<S:Envelope";
	private File currentFile;
	private String server;
	private String idir;
	private String odir;

	private String startPath = "";
	Hashtable<String, String> orRequests = new Hashtable<String, String>();
	ArrayListNoDuplicates<String> hois = new ArrayListNoDuplicates<String>();
	
	String fileStartsWith = "*";
	
	private WordString words = new WordString("");
	StringWriter writer, writerPcs;
	
	private static Pattern bceStart = Pattern.compile("<[ns]{0,2}[0-9]{0,2}:{0,1}bceOrder>");
	private static Pattern bceEnd = Pattern.compile("</[ns]{0,2}[0-9]{0,2}:{0,1}bceOrder>");
	private static Pattern splStart = Pattern.compile("<{0,1}[ns]{0,2}[0-9]{0,2}:{0,1}servicePointList[ xsi>]{1}");
	private static Pattern splEnd = Pattern.compile("</[ns]{0,2}[0-9]{0,2}:{0,1}servicePointList>");
	private static Pattern servicePoint = Pattern.compile("</[ns]{0,2}[0-9]{0,2}:{0,1}servicePoint>");


	public BellOmfTraceLogsOrQsSvcPntProb(String idir, String fileStartsWith, String odir, String date) {

		this.fileStartsWith = fileStartsWith;
		words.setDelimiters(new char[] { ' ', '[', ']' });
		
		this.idir = idir;
		this.odir = odir;
		writer = new StringWriter(odir + File.separator + "QualSrvceProblem-"+date+".txt");
		writer.open();
		
		writerPcs = new StringWriter(odir + File.separator + "QualSrvceProblemPcs-"+date+".txt");
		writerPcs.open();
		
	}

	public void print(OmfParameters data) {
		
		
		writer.close();
		writerPcs.close();
		
	}

	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50) {
			

			str = str.replace("[ ", "[");
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			
			if (time == null) {
				return true;
			}
			long timeMs = Utility.time24HourMilliToLong(time);
			
			if (date.equals(parms.date)) {
				
				boolean req = false;
				boolean resp = false;
				
				//long start=System.currentTimeMillis();
				if (str.indexOf(":requestHeader>") > 0 || str.indexOf("<requestHeader>") > 0 || str.indexOf("{\"requestHeader\":") > 0) {
					req = true;
				}
				if (str.indexOf(":responseHeader>") > 0 || str.indexOf("<responseHeader>") > 0) {
					resp = true;
				}
				
				if (!req && str.indexOf("ProductConfigurationService.") >= 0 && (str.indexOf("sessionData") > 0 || str.indexOf("actionList") > 0)) {
					req = true;
				}
				
				//System.out.println("A:" + (System.currentTimeMillis()-start));start=System.currentTimeMillis();
				if (req || resp) {
					
					String hoi = words.getWord(10);
					String txn = words.getWord(6);
					String channel = words.getWord(8);
					String txnId = words.getWord(4);
					//System.out.println("B:" + (System.currentTimeMillis()-start));
					
					if (txn.length() == 0) {
						txn = words.getWord(16);
					}
					
					txn = txn.replaceFirst("OMF\\.", "");


					if (txn.equals("QualificationService.getQualificationData")) {
						processQS(timeMs, server, hoi, txnId, str, words);
					}
					
					if (hois.contains(hoi)) {
						if (txn.indexOf("ProductConfigurationService.") == 0 || str.indexOf("OMF.OrderControlService.submit Request") > 0 || str.indexOf("OMF.CalendaringService.checkAppointmentAvailability Request") > 0) {
							writerPcs.writeLine(hoi + '\t' + str.substring(0, 23) + '\t' + currentFile.getName() + '\t' + str.substring(24));
						}
					}
				} 
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data, long start) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				//long modTime = child.lastModified();
				//files.add(String.valueOf(modTime) + "-" + child.getName());
				
				int p = child.getName().lastIndexOf('.');
				
				String txt = child.getName().substring(p+1);
				
				int num = 0;
				if (! txt.equals("log")) {
					num = Integer.parseInt(txt);
				}
				files.add(String.valueOf(999-num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		long lastSizeHoiRequests = 0;
		long lastSizeHoiActions = 0;
		int counter = 0;
		for (i = 0; i < files.size() && counter <= 10; i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				long time = 0;
				if (i > 0) {
					long msPer = ((System.currentTimeMillis()-start) / (i));
					time = (files.size()-i) * msPer;
					System.out.println("Processing: "+child.getName() + " approximately " + Utility.longTo24DayHour((time+500)/1000L) + " - each: " + Utility.longTo24HourMilli(msPer));
				} else {
					System.out.println("Processing: "+child.getName());
					
				}
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);
					
					counter = 0;
					
				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data, start);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;
	static BellOmfTraceLogsOrQsSvcPntProb line = null;

	public static void main(String[] args) {

		if (args.length != 4) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date");
			System.err.println("         file starts with");
			System.err.println("         out dir name");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		line = new BellOmfTraceLogsOrQsSvcPntProb(args[0], args[2], args[3], args[1]);
		
		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(args[1], 0);
		line.recurse(f, parms, System.currentTimeMillis());

		line.print(parms);

		exit(0);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		String str = currentFile.getName();
		
		int pos = str.indexOf("_OM");
		if (pos > 0) {
			server = str.substring(pos+4, pos+13);
		} else {
			pos = str.indexOf("_");
			int pos2 = str.indexOf(".");
			server = str.substring(pos+1, pos2);
		}
		

	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}
	
	
	private void processQS(Long timeMs, String currentServer, String hoi, String txnId, String str, WordString words) {

		String data;
		if (str.indexOf("OMF.OrderRetrieval.orderRetrievalService Response") > 0) {
			int p = str.indexOf("<S:Envelope");
			if (p > 0) {
				data = str.substring(p);
				orRequests.put(txnId, data);
			}
			
			return;
		}
		
		if (str.indexOf("OMF.QualificationService.getQualificationData Response") > 0) {
			data = orRequests.get(txnId);
			if (data == null) {
				return;
			}
			
			orRequests.remove(txnId);
			int p = str.indexOf("<env:Envelope");
			if (p > 0) {

				String data2 = str.substring(p);
				
				int c1 = countServicePoints(data);
				int c2 = countServicePoints(data2);

				if (c1 != c2) {
					writer.writeLine(Utility.longTo24HourMilli(timeMs) + "\t" + currentFile.getName() + "\t" + hoi + "\t" + txnId);
					writer.writeLine('\t' + data);
					writer.writeLine('\t' + data2);
					writer.writeLine("");
					hois.add(hoi);
				}

			}

		}		
	}

	private int countServicePoints(String data) {

		int p = findPatternIndex(data, bceStart, 0);
		
		if (p < 0) {
			return 0;
		}
		int start = findPatternIndex(data, splStart, p);
		if (start < 0) {
			return 0;
		}
		int end = findPatternIndex(data, splEnd, p);
		
		data = data.substring(start, end);
		
		int count = countPatternIndex(data, servicePoint);
		
		return count;
	}

	private static int findPatternIndex(String str, Pattern pattern, int start) {
	    Matcher matcher = pattern.matcher(str);
	    if (matcher.find(start)) {
	        return matcher.start();
	    }	
	    
	    return -1;
	}

	private static int countPatternIndex(String str, Pattern pattern) {
	    Matcher matcher = pattern.matcher(str);
	    
        int count = 0;
        while (matcher.find()) {
            count++;
        }
	    
	    return count;
	}

}
