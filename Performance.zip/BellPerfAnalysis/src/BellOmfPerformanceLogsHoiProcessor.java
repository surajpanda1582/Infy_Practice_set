import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellOmfPerformanceLogsHoiProcessor extends LineProcessorWithData {

	private File currentFile;
	private String currentServer;
	private int serverCount;
	public StringWriter writer;

	private String startPath = "";

	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	private WordString words = new WordString("");
	private WordString cpqWords = new WordString("");

	HashMap<String, String> txnType = new HashMap<String, String>();

	HashMap<String, Long> yifCalls = new HashMap<String, Long>();
	HashMap<String, String[]> yifCallsModel = new HashMap<String, String[]>();
//	HashMap<String, Long> channelTxnGenerator = new HashMap<String, Long>();
	static Pattern hoiPattern = Pattern.compile("[A-Z][0-9][0-9][A-Z][0-9][0-9][A-Z][0-9]");
	
	static FileProcessorWithData fp = null;
	static BellOmfPerformanceLogsHoiProcessor line = null;

	public BellOmfPerformanceLogsHoiProcessor(String dir, String outDir, String fileStartsWith) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;

		words.setDelimiters(new char[] { ' ', '[', ']' });
		cpqWords.setDelimiters(new char[] { ':', '[', ']' });

		writer = new StringWriter(outDir + File.separator + "HoiData.tab");
		writer.open();
	}

	public void print(OmfParameters data) {
		
		writer.close();
		
	}

	static private Pattern NUM_DASH_PATTERN = Pattern.compile("[0-9]-- ");
	public boolean processLine(String str, Object data) {

		if (str != null && str.length() > 50 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			
			str = Utility.replaceString(str, "- Target ", "- ");
			str = Utility.replaceString(str, " (self-tuning)'", "");
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			//System.out.println(str);
			//for (int i = 0; i < words.getWordCount(); i++) {
			//	System.out.println(i + " -> " + words.getWord(i));
			//}
			if (timeMs > 0) {
				
				str = str.replaceAll("\\[ +", "[");
				words.setString(str);
				if (str.indexOf("CACHE_") > 0) {
				    Matcher matcher = NUM_DASH_PATTERN.matcher(str);
				    if (matcher.find()) {
				    	int p = matcher.start(); 
				    	str = str.substring(0, p+1);
				    }
					words.setString(str);
				}

				String txn = words.getWord(6);
				
				txn = txn.replace("OMF.", "");
				int p = str.indexOf(" PERFORMANCE-");
				String txn2 = words.getWord(16);
				if (txn2 != null) txn2 = txn2.replace("OMF.", "");
				String srvTxn2 = txn2;
				if (p > 0) {
					txn2 = str.substring(p+13).trim();
				}

				String channel = words.getWord(8);
				String hoi = words.getWord(10);
				String stxnPerf = words.getWord(words.getWordCount()-1);
				p = stxnPerf.lastIndexOf(':');
				if (p > 0) {
					stxnPerf = stxnPerf.substring(p+1);
				}
				
				if (Utility.isNumber(stxnPerf)) {
					long txnPerf = Long.parseLong(stxnPerf);
					
					//String consumer = words.getWord(8);
					String txnId = words.getWord(4);
					String txnSrvcName = null;
					if (txnId.length() == 0) {
						txnId = hoi;
					} else {
						txnSrvcName = txnType.get(txnId);
						if (txnSrvcName == null) {
							if (txnId.length() > 0) {
								txnType.put(txnId, txn);
							}
						} else {
							txn = txnSrvcName;
						}
					}
					if (txnId.length() == 0 && hoi.length() == 0) {
						txnId = channel+'-'+txn;
					}

					p = txn.indexOf('.');
					txnSrvcName = txn;
					if (p > 0) {
						txnSrvcName = txn.substring(0, p);
					}
					
					if (srvTxn2 != null && srvTxn2.indexOf(txnSrvcName+'.') >= 0) {
						srvTxn2 = txnSrvcName;
					}
					
					if (txnPerf > 0) {
						
						if (txn != null && txnSrvcName.equals(srvTxn2) && hoi != null && hoi.length() == 8 && 
								hoiPattern.matcher(hoi).find()) {
							writer.writeLine(date + "\t" + time + "\t" + currentServer + "\t" + channel + "\t" + hoi + "\t" + txn + "\t" + txnId + "\t" + txnPerf);
						}
					}
				}
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	public static void main(String[] args) {

		if (args.length != 3) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         file starts with");
			System.err.println("         out dir name");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		line = new BellOmfPerformanceLogsHoiProcessor(args[0], args[2], args[1]);

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(null, 0);
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName();
		int p = currentFile.getName().indexOf('.');
		
		if (p > 15) {
			this.currentServer = currentFile.getName().substring(15, p);
		}
		this.serverCount = 0;
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}
