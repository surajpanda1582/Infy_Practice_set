import java.util.Hashtable;

import com.followme.abastien.utilities.StatisticalDoubleVector;

/*
 * Created on Aug 22, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class OmDataElement {
	Integer interval;
	StatisticalDoubleVector allStats = new StatisticalDoubleVector(5000,1000);
	Hashtable byServer = new Hashtable(); 
	Hashtable byService = new Hashtable(); 
	
	OmDataElement(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(String server, String service, double value) {
		StatisticalDoubleVector data;
		
		allStats.add(value);
		
		data = (StatisticalDoubleVector)byServer.get(server);
		if (data == null) {
			data = new StatisticalDoubleVector(1000,500);
			byServer.put(server, data);
		}
		
		data.add(value);
		
		data = (StatisticalDoubleVector)byService.get(service);
		if (data == null) {
			data = new StatisticalDoubleVector(1000,500);
			byService.put(service, data);
		}
		
		data.add(value);

	}
}
