import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;

/*
 * Created on Aug 22, 2011
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */


public class OmScenarioDataElement {
	String name;
	public static int STATS_SIZE = 100;
	
	StatisticalDoubleVector servletStats = new StatisticalDoubleVector(STATS_SIZE, STATS_SIZE);
	Hashtable<String, StatisticalDoubleVector> byCall = new Hashtable<String, StatisticalDoubleVector>();

	public OmScenarioDataElement(String scenarioName) {
		name = scenarioName;
	}
	
	void addStats(ScenarioData scenData) {
		StatisticalDoubleVector data;
		
		for(int i = 0; i < scenData.calls.size(); i++) {
			String call = scenData.calls.get(i);
			//long start = scenData.start.get(i);
			int time = scenData.timesMs.get(i);
			
			data = byCall.get(call);
			if (data == null) {
				data = new StatisticalDoubleVector(STATS_SIZE, STATS_SIZE);
				byCall.put(call, data);
			}
			
			data.add(time);
		}
		
		servletStats.add(scenData.timesMs.get(scenData.calls.size()-1).doubleValue());
		
	}

}
