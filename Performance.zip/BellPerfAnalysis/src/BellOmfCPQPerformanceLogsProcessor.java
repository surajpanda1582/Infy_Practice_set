import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellOmfCPQPerformanceLogsProcessor extends LineProcessorWithData {

	private File currentFile;
	private String currentServer;
	private int serverCount;
	public StringWriter writer;

	private String startPath = "";
	Hashtable<Integer, OmfDataElement> perfData = new Hashtable<Integer, OmfDataElement>();
	Hashtable<Integer, OmfModelDataElement> modelPerfData = new Hashtable<Integer, OmfModelDataElement>();
	Hashtable<Integer, OmfModelDataElement> pcsModelPerfData = new Hashtable<Integer, OmfModelDataElement>();
	ArrayList<String> servers = new ArrayList<String>();
	ArrayList<String> services = new ArrayList<String>();
	ArrayListNoDuplicates<String> models = new ArrayListNoDuplicates<String>();
	ArrayListNoDuplicates<String> channels = new ArrayListNoDuplicates<String>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	private WordString words = new WordString("");
	private WordString cpqWords = new WordString("");

	HashMap<String, String> txnType = new HashMap<String, String>();

	HashMap<String, Long> yifCalls = new HashMap<String, Long>();
	HashMap<String, String[]> yifCallsModel = new HashMap<String, String[]>();
	static Pattern yifPattern = Pattern.compile("\\[YIFWebService\\]");
	static Pattern modelPattern = Pattern.compile("\\[PCSBFO_PERFORMANCE:CPQ:.*");
	
	static FileProcessorWithData fp = null;
	static BellOmfCPQPerformanceLogsProcessor line = null;

	private static ArrayList detailChannels = new ArrayList();
	private static ArrayList detailService = new ArrayList();
	private static ArrayList detailSubServiceName = new ArrayList();
	private static ArrayList detailSubServiceExp = new ArrayList();
	
	public BellOmfCPQPerformanceLogsProcessor(String dir, String outDir, String fileStartsWith, String minMs, String maxMs) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { ' ', '[', ']' });
		cpqWords.setDelimiters(new char[] { ':', '[', ']' });

		writer = new StringWriter(outDir + File.separator + "veryHighCalls.tab");
		writer.open();
	}

	public void print(OmfParameters data) {
		
		writer.close();
		
		Integer interval = new Integer((int)(minMs / data.interval));
		int maxInterval = (int)(maxMs / data.interval);
		
		Collections.sort(servers);

		StringWriter writer2 = new StringWriter(outDir + File.separator + "servers.tab");
		writer2.open();

		writer2.write("\t");
		for (int i = 0; i < servers.size(); i++) {
			writer2.write(servers.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < servers.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		while (interval.doubleValue() <= maxInterval) {
			OmfDataElement dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < servers.size(); i++) {
					StatisticalDoubleVector stats = dataElement.byServer.get(servers.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(dataElement.allStats.size() + "\t" + dataElement.allStats.getAverage() + "\t" + dataElement.allStats.getPercentile(.9) + "\t" + dataElement.allStats.getPercentile(.95) + "\t" + dataElement.allStats.getMaximum());
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.writeLine("");
		writer2.close();
		
		writer2 = new StringWriter(outDir + File.separator + "services.tab");
		writer2.open();
		
		Collections.sort(services);

		writer2.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write(services.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			OmfDataElement dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < services.size(); i++) {
					StatisticalDoubleVector stats = dataElement.byService.get(services.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(dataElement.allStats.size() + "\t" + dataElement.allStats.getAverage() + "\t" + dataElement.allStats.getPercentile(.9) + "\t" + dataElement.allStats.getPercentile(.95) + "\t" + dataElement.allStats.getMaximum());
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.close();

		Collections.sort(channels);
		Collections.sort(models);
		System.out.println(OmfModelDataElement.maxDepCats);

		for (int k = 0; k < channels.size(); k++) {
			String channel = channels.get(k);
			
			writer2 = new StringWriter(outDir + File.separator + "models-"+channel+".tab");
			writer2.open();
			StringWriter writer3 = new StringWriter(outDir + File.separator + "modelsFireByCat-"+channel+".tab");
			writer3.open();

	
			writer2.write("\t");
			writer3.write("\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write(models.get(i) + "\t\t\t\t\t");
				writer3.write(models.get(i) + "\t\t\t\t");
			}
			writer2.writeLine("All");
			writer3.writeLine("All");
			writer2.write("Interval\t");
			writer3.write("Interval\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
				writer3.write("Num\t% All Cats\t% Cats\tAvg (ms)\t");
			}
			writer2.writeLine("Num\tAvg\t90%\t95%\tMax");
			writer3.writeLine("Num\t% All Cats\t% Cats\tAvg (ms)\t");
	
			interval = new Integer((int)(minMs / data.interval));
			while (interval.doubleValue() <= maxInterval) {
				OmfModelDataElement dataElement = modelPerfData.get(interval);   //CPQ
				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				writer3.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				
				if (dataElement != null) {
					Hashtable<String, StatisticalDoubleVector[]> channelData = dataElement.byChannelModel.get(channel);
					StatisticalDoubleVector[] channelAllData = dataElement.allStats.get(channel);

					if (channelData != null) {
						for (int i = 0; i < models.size(); i++) {
							
							StatisticalDoubleVector[] stats = channelData.get(models.get(i));
							
							if (stats != null) {
								writer2.write(stats[0].size() + "\t" + stats[0].getAverage() + "\t" + stats[0].getPercentile(.9) + "\t" + stats[0].getPercentile(.95) + "\t" + stats[0].getMaximum() + "\t");
								writer3.write(stats[1].size() + "\t" + stats[2].getAverage() + "\t" + (stats[1].getAverage()/OmfModelDataElement.maxDepCats) + "\t" + stats[0].getAverage() + "\t");
							} else {
								writer2.write("\t\t\t\t\t");
								writer3.write("\t\t\t\t");
							}
						}
					} else {
						for (int i = 0; i < models.size(); i++) {
							writer2.write("\t\t\t\t\t");
							writer3.write("\t\t\t\t");
						}						
					}
					if (channelAllData != null) {
						writer2.write(channelAllData[0].size() + "\t" + channelAllData[0].getAverage() + "\t" + channelAllData[0].getPercentile(.9) + "\t" + channelAllData[0].getPercentile(.95) + "\t" + channelAllData[0].getMaximum());
						writer3.write(channelAllData[1].size() + "\t" + channelAllData[2].getAverage() + "\t" + (channelAllData[1].getAverage()/OmfModelDataElement.maxDepCats) + "\t" + channelAllData[0].getAverage() + "\t");
				} else {
						writer2.write("0\t0\t0\t0\t0");
						writer3.write("0\t0\t0\t0\t0");
					}
				}
				
				writer2.writeLine("");
				writer3.writeLine("");
				
				interval = new Integer(interval.intValue()+1);
			}
			writer2.close();

	
			writer2 = new StringWriter(outDir + File.separator + "pcsbymodel-"+channel+".tab");
			writer2.open();
			
			writer2.write("\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write(models.get(i) + "\t\t\t\t\t");
			}
			writer2.writeLine("All");
			writer2.write("Interval\t");
			for (int i = 0; i < models.size(); i++) {
				writer2.write("Num\tAvg\t90%\t95%\tMax\t");
			}
			writer2.writeLine("Num\tAvg\t90%\t95%\tMax");
	
			interval = new Integer((int)(minMs / data.interval));
			while (interval.doubleValue() <= maxInterval) {
				OmfModelDataElement dataElement = pcsModelPerfData.get(interval);   //PCS
				writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
				
				if (dataElement != null) {
					Hashtable<String, StatisticalDoubleVector[]> channelData = dataElement.byChannelModel.get(channel);
					StatisticalDoubleVector[] channelAllData = dataElement.allStats.get(channel);

					if (channelData != null) {
						for (int i = 0; i < models.size(); i++) {
							StatisticalDoubleVector[] stats = channelData.get(models.get(i));
							
							if (stats != null) {
								writer2.write(stats[0].size() + "\t" + stats[0].getAverage() + "\t" + stats[0].getPercentile(.9) + "\t" + stats[0].getPercentile(.95) + "\t" + stats[0].getMaximum() + "\t");
							} else {
								writer2.write("\t\t\t\t\t");
							}
						}
					} else {
						for (int i = 0; i < models.size(); i++) {
							writer2.write("\t\t\t\t\t");
						}						
					}
	
					if (channelAllData != null) {
						writer2.write(channelAllData[0].size() + "\t" + channelAllData[0].getAverage() + "\t" + channelAllData[0].getPercentile(.9) + "\t" + channelAllData[0].getPercentile(.95) + "\t" + channelAllData[0].getMaximum());
					} else {
						writer2.write("0\t0\t0\t0\t0");
					}
				}
				
				writer2.writeLine("");
				
				interval = new Integer(interval.intValue()+1);
			}
			writer2.close();
			writer3.close();

		}
	}

	static private Pattern NUM_DASH_PATTERN = Pattern.compile("[0-9]-- ");
	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50 && str.charAt(4) == '-' && str.charAt(7) == '-') {
			
			str = Utility.replaceString(str, "- Target ", "- ");
			str = Utility.replaceString(str, " (self-tuning)'", "");
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			
			//System.out.println(str);
			//for (int i = 0; i < words.getWordCount(); i++) {
			//	System.out.println(i + " -> " + words.getWord(i));
			//}
			if (timeMs >= minMs && timeMs <= (maxMs+parms.interval) && date.equals(parms.date)) {
				
				str = str.replaceAll("\\[ +", "[");
				words.setString(str);
				if (str.indexOf("CACHE_") > 0) {
				    Matcher matcher = NUM_DASH_PATTERN.matcher(str);
				    if (matcher.find()) {
				    	int p = matcher.start(); 
				    	str = str.substring(0, p+1);
				    }
					words.setString(str);
				}

				String txn = words.getWord(6);
				
				txn = txn.replace("OMF.", "");
				int p = str.indexOf(" PERFORMANCE-");
				String txn2 = words.getWord(16);
				if (txn2 != null) txn2 = txn2.replace("OMF.", "");
				String srvTxn2 = txn2;
				if (p > 0) {
					txn2 = str.substring(p+13).trim();
				}

				String channel = words.getWord(8);
				String stxnPerf = words.getWord(words.getWordCount()-1);
				p = stxnPerf.lastIndexOf(':');
				if (p > 0) {
					stxnPerf = stxnPerf.substring(p+1);
				}
				
				if (Utility.isNumber(stxnPerf) && (detailChannels.size()==0 || detailChannels.contains(channel))) {
					long txnPerf = Long.parseLong(stxnPerf);
					
					//String consumer = words.getWord(8);
					String txnId = words.getWord(4);
					String txnSrvcName = txnType.get(txnId);
					if (txnSrvcName == null) {
						txnType.put(txnId, txn);
					} else {
						txn = txnSrvcName;
					}
					p = txn.indexOf('.');
					//String txnOperName = "";
					txnSrvcName = txn;
					if (p > 0) {
						//txnOperName = txn.substring(p+1);
						txnSrvcName = txn.substring(0, p);
					}
					
					if (srvTxn2 != null && srvTxn2.indexOf(txnSrvcName+'.') >= 0) {
						srvTxn2 = txnSrvcName;
					}
					
					if (txnPerf > 0) {
						Integer interval = new Integer((int)(timeMs/parms.interval));
						
						if (serverCount < 1000 && txnPerf > 20000) {
							writer.writeLine(txn + "\t" + txnPerf + "\t" + currentServer + "\t" + str);
							serverCount++;
						}
						
						
						Matcher matcher = modelPattern.matcher(txn2);
						//Process CPQ model times
						if (matcher.find()) {
							
							Long yif = txnPerf;  //yifCalls.get(txnId);
							
							if (yif != null) {
								cpqWords.setString(txn2);
								String model = cpqWords.getWord(3);
								
								String dependentCats = "-1";
								String action = "";
								if (cpqWords.getWordCount() > 6) {
									dependentCats = cpqWords.getWord(4);
									action = cpqWords.getWord(7);
								}
								models.add(model);
								String[] modelData = new String[] {model, action, dependentCats};
								yifCallsModel.put(txnId, modelData);
								
								OmfModelDataElement dataElement = modelPerfData.get(interval);
								if (dataElement == null) {
									dataElement = new OmfModelDataElement(interval);
									modelPerfData.put(interval, dataElement);
								}
								
								channels.add(channel);

								dataElement.addData(channel, modelData, yif.longValue(), false, "");
							}
						}
						
						if (txn != null && ! txn.equals(srvTxn2)) {
							String txn3 = matchSubTransation(txn, txn2);
							if (txn3 != null) {
								txn = txn3;
								txn2 = txn3;
								srvTxn2 = txn3;
							}
						}
						
						if (yifPattern.matcher(txn2).find()) {
							txn = "YIFWebService";
							txn2 = "YIFWebService";
							srvTxn2 = "YIFWebService";
							
						}
						
//						if (txn != null && ("YIFWebService".equals(srvTxn2) || txnSrvcName.equals(srvTxn2))) {
//							if (txn.trim().length()==0) {
//								System.out.println("ERROR: Blank Transaction: "+str);
//								return true;
//							}
//							if (!servers.contains(currentServer)) {
//								servers.add(currentServer);
//							}
//							
//							
//							OmfDataElement dataElement = perfData.get(interval);
//							if (dataElement == null) {
//								dataElement = new OmfDataElement(interval);
//								perfData.put(interval, dataElement);
//							}
//
//							
//							if (srvTxn2.equals("YIFWebService") || srvTxn2.indexOf("CPQ") >= 0) {
//								
//								yifCalls.put(txnId, new Long(txnPerf));
//							
//							} else if (txnSrvcName.equals("ProductConfigurationService") || txnSrvcName.equals("ProductAvailabilityService")) {
//								
//								Long yif = yifCalls.get(txnId);
//								if (yif != null) {
//									yifCalls.remove(txnId);
//									
//									long lyif = yif.longValue();
//									
//									txnPerf -= lyif;
//
//									if (!services.contains(txn+"-CPQ")) {
//										services.add(txn+"-CPQ");
//									}
//									dataElement.addStats(currentServer, txn+"-CPQ", lyif);
//									if (!services.contains(txn)) {
//										services.add(txn);
//									}
//									dataElement.addStats(currentServer, txn, txnPerf);
//									
//									if (txnSrvcName.equals("ProductConfigurationService")) {
//										String[] modelData = yifCallsModel.get(txnId);
//										if (modelData != null) {
//											yifCallsModel.remove(txnId);
//											
//											OmfModelDataElement dataElement2 = pcsModelPerfData.get(interval);
//											if (dataElement2 == null) {
//												dataElement2 = new OmfModelDataElement(interval);
//												pcsModelPerfData.put(interval, dataElement2);
//											}
//											
//											channels.add(channel);
//
//											dataElement2.addData(channel, modelData, txnPerf);
//
//										}
//									}
//									
//								} else {
//									if (!services.contains(txn)) {
//										services.add(txn);
//									}
//									dataElement.addStats(currentServer, txn, txnPerf);
//								}
//								
//							} else {
//			
//								if (!services.contains(txn)) {
//									services.add(txn);
//								}
//								
//								dataElement.addStats(currentServer, txn, txnPerf);
//								
//								if (txnSrvcName.equals("ProductConfigurationService")) {
//									System.out.println("ERR: PCS no YIF: " + line);
//								}
//							}
//						}
					} else if (txnSrvcName.equals(txn2)) {
//						System.err.println("Zero Time: " + str);
					}
				} else if (txn.equals(txn2)) {
					System.err.println("ERR in: " + str);
				}
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					num -= Integer.parseInt(ext);
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	public static void main(String[] args) {

		if (args.length < 7) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date yyyy-mm-dd");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.err.println("         config file [Optional]");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellOmfCPQPerformanceLogsProcessor(args[0],args[6],args[3], args[4], args[5]);
		}

		if (args.length > 7) {
			parseCfg(args[7]);
		}

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(args[1], Integer.parseInt(args[2]));
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	private String matchSubTransation(String txn, String txn2) {

		for (int i = 0; i < detailService.size(); i++) {
			
			if (detailService.get(i).equals(txn)) {
				if (((Pattern)detailSubServiceExp.get(i)).matcher(txn2).find()) {
					return txn+"."+detailSubServiceName.get(i);
				}
			}
		}
		return null;
	}

	
	@SuppressWarnings("unchecked")
	private static void parseCfg(String fileName) {
		StringReader reader = new StringReader(fileName);
		
		if (reader.open() != 0) {
			System.out.println("Cannot open config file: "+fileName);
			throw new RuntimeException("Cannot open config file: "+fileName);
		}
		
		String lineStr = reader.readLine();
		String service = null;
		
		while (lineStr != null) {
			lineStr = lineStr.trim();
			
			if (lineStr.length()==0 || lineStr.charAt(0) == '#') {
				//nop - comment line or blank line
				
			}else if (lineStr.charAt(0) == '[') {
				service = lineStr.substring(1, lineStr.length()-1).trim();
				
			} else {
				int p = lineStr.indexOf('=');
				
				if (p >0) {
					String name = lineStr.substring(0, p).trim();
					String value = lineStr.substring(p+1).trim();
					
					if (name.equals("*CHANNEL*")) {
						detailChannels.add(value);
					} else {
						detailService.add(service);
						detailSubServiceName.add(name);
						detailSubServiceExp.add(Pattern.compile(value));
					}
				}
			}
			
			lineStr = reader.readLine();
		}
		
		reader.close();
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName();
		int p = currentFile.getName().indexOf('.');
		
		if (p > 15) {
			this.currentServer = currentFile.getName().substring(15, p);
		}
		this.serverCount = 0;
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}

class OmfDataElement {
	
	Integer interval;
	StatisticalDoubleVector allStats = new StatisticalDoubleVector(100000,50000);
	Hashtable<String, StatisticalDoubleVector> byServer = new Hashtable<String, StatisticalDoubleVector>(); 
	Hashtable<String, StatisticalDoubleVector> allStatsByServer = new Hashtable<String, StatisticalDoubleVector>(); 
	Hashtable<String, StatisticalDoubleVector> byService = new Hashtable<String, StatisticalDoubleVector>(); 
	
	OmfDataElement(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(String server, String service, double value) {
		StatisticalDoubleVector data, data2;
		
		if (service.trim().length()==0) {
			throw new RuntimeException("Blank Transaction");
		}

		allStats.add(value);
		
		data = byServer.get(server+":"+service);
		if (data == null) {
			data = new StatisticalDoubleVector(10000, 5000);
			byServer.put(server+":"+service, data);
		}
		data2 = allStatsByServer.get(server);
		if (data2 == null) {
			data2 = new StatisticalDoubleVector(10000, 5000);
			allStatsByServer.put(server, data2);
		}
		
		data.add(value);
		data2.add(value);
		
		data = byService.get(service);
		if (data == null) {
			data = new StatisticalDoubleVector(10000, 5000);
			byService.put(service, data);
		}
		
		data.add(value);

	}
}