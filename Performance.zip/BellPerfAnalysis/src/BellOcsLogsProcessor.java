import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Stack;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellOcsLogsProcessor extends LineProcessorWithData {

	private File currentFile;
	private String currentServer;

	private String startPath = "";
	
	//Performance Data in Time Slices inside the OrderAction
	Hashtable<String, Long> txnStartData = new Hashtable<String, Long>();
	Hashtable<Integer, PerfDataElement> perfData = new Hashtable<Integer, PerfDataElement>();
	ArrayListNoDuplicates<String> transactions = new ArrayListNoDuplicates<String>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	
	private WordString words = new WordString("");
	private WordString words2 = new WordString("");

	public BellOcsLogsProcessor(String fileStartsWith) {

		this.fileStartsWith = fileStartsWith;
		words.setDelimiters(new char[] { '[',']' });
		words2.setDelimiters(new char[] { ' ' });
	}

	public BellOcsLogsProcessor(String fileStartsWith, String minMs, String maxMs) {

		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] { '[',']' });
		words2.setDelimiters(new char[] { ' ' });
	}

	public void print(OmParameters data) {
		
		int maxInterval = (int)(maxMs / data.interval);

		Collections.sort(transactions);
		
		StringWriter writer = new StringWriter(data.outDir + File.separator + "perfData.tab");
		writer.open();
		
		writer.write("\t");
		for (int i = 0; i < transactions.size(); i++) {
			writer.write(transactions.get(i) + "\t\t\t\t\t");
		}
//		writer.writeLine("All");
		writer.writeLine("");
		writer.write("Interval\t");
		for (int i = 0; i < transactions.size(); i++) {
			writer.write("Num\tAvg\t90%\t95%\tMax\t");
		}
//		writer.writeLine("Num\tAvg\t90%\t95%\tMax");
		writer.writeLine("");
		
		Integer interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			PerfDataElement dataElement = perfData.get(interval);   //PCS
			writer.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {

				for (Iterator iterator = transactions.iterator(); iterator.hasNext();) {
					String txn = (String) iterator.next();
					
					StatisticalDoubleVector stats = dataElement.sData.get(txn);
					if (stats != null) {
						for (int i = 0; i < transactions.size(); i++) {
							if (stats != null) {
								writer.write(stats.size() + "\t" + stats.getAverage() + "\t" + stats.getPercentile(.9) + "\t" + stats.getPercentile(.95) + "\t" + stats.getMaximum() + "\t");
							} else {
								writer.write("\t\t\t\t\t");
							}
						}
					} else {
						for (int i = 0; i < transactions.size(); i++) {
							writer.write("\t\t\t\t\t");
						}						
					}
					
				}

			}
			
			writer.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		
		writer.close();

		
	}

	public boolean processLine(String str, Object cData) {

		OmParameters parms = (OmParameters) cData;
		if (str != null && str.length() > 50 && str.startsWith("20")) {
			
			words.setString(str);
			words2.setString(words.getWord(0));
			
			String date = words2.getWord(0);
			String time = words2.getWord(1);
			long timeMs = Utility.time24HourMilliToLong(time);
			String txnId = words.getWord(1);
			
			if (parms.use(date, timeMs)) {
				
				String txn = null;
				String txnPerfS = null;
				String orderNumber = words.getWord(1);
				Integer interval = new Integer((int)(timeMs/parms.interval));

				
			    if (str.indexOf("Dispatch order ") > 0) {
			    	txn = "ODS";
			    	txnStartData.put(txnId+txn, timeMs);
			    	
			    } else if (str.indexOf("Receiving from ODS: ") > 0) {
			    	txn = "ODS";
			    	transactions.add(txn);
			    	long startMs = txnStartData.get(txnId+txn);
			    	long perfTime = timeMs-startMs;
			    	
			    	PerfDataElement data = perfData.get(interval);
			    	if (data == null) {
			    		data = new PerfDataElement(interval);
			    		perfData.put(interval, data);
			    	}
			    	
			    	data.addStats(txn, perfTime);
				}
				
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		ArrayList<String> files = new ArrayList<String>();
		
		//Sort by Time
		for (i = 0; i < list.length; i++) {
			File child = new File(dirFile, list[i]);
			
			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				int p = child.getName().lastIndexOf('.');
				String ext = child.getName().substring(p+1);
				int num = 999;
				if (!ext.equals("log")) {
					try {
						num -= Integer.parseInt(ext);
					} catch (NumberFormatException ignored) {
						
					}
				}
				
				files.add(String.valueOf(num) + "-" + child.getName());
			}			
		}
		
		Collections.sort(files);
		
		for (i = 0; i < files.size(); i++) {
			
			String fileName = files.get(i);
			int pos = fileName.indexOf('-');
			fileName = fileName.substring(pos+1);
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	static FileProcessorWithData fp = null;
	static BellOcsLogsProcessor line = null;

	public static void main(String[] args) {

		if (args.length < 7) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date (yyyy-mm-dd)");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir");
			System.err.println("         end date (yyyy-mm-dd)");
			System.err.println("   Only provide end date if needed to cross midnight");
			System.exit(-1);
				
		}

		String date = args[1];
		if (date.length() == 8) {
			date = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6);
		}

		System.out.println("Date: " + date + "      In Dir: " + args[0] + "      Out Dir: " + args[6]);

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length < 5) {
			line = new BellOcsLogsProcessor(args[3]);
		} else {
			line = new BellOcsLogsProcessor(args[3], args[4], args[5]);
		}
		
		line.setStartPath(f.getAbsolutePath());

		OmParameters parms = new OmParameters(date, Integer.parseInt(args[2]), line.minMs, line.maxMs);
		
		parms.outDir = args[6];
		if (args.length > 7) {
			parms.date2 = args[7];
		}
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName().substring(7, 18);
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}

