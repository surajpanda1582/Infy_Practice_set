import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.followme.abastien.io.FileProcessorWithData;
import com.followme.abastien.io.LineProcessorWithData;
import com.followme.abastien.io.StringReader;
import com.followme.abastien.io.StringWriter;
import com.followme.abastien.utilities.ArrayListNoDuplicates;
import com.followme.abastien.utilities.StatisticalDoubleVector;
import com.followme.abastien.utilities.Utility;
import com.followme.abastien.utilities.WordString;

class BellCPQTimerLogsProcessor extends LineProcessorWithData {

	private File currentFile;
	private String currentServer;

	private String startPath = "";
	Hashtable<Integer, CpqTimerDataElement> perfData = new Hashtable<Integer, CpqTimerDataElement>();
	ArrayListNoDuplicates<String> services = new ArrayListNoDuplicates<String>();
	ArrayListNoDuplicates<String> models = new ArrayListNoDuplicates<String>();
	Hashtable<String, String> threadModelMap = new Hashtable<String, String>();

	long minMs = Utility.time24HourMilliToLong("00:00:00:000");
	long maxMs = Utility.time24HourMilliToLong("23:59:59:999");
	String fileStartsWith = "*";
	String dir;
	String outDir;
	
	private WordString words = new WordString("");

	HashMap<String, Long> yifCalls = new HashMap<String, Long>();
	HashMap<String, String> yifCallsModel = new HashMap<String, String>();
	static Pattern yifPattern = Pattern.compile("\\[YIFWebService\\]");
	static Pattern modelPattern = Pattern.compile("\\[PCSBFO_PERFORMANCE:CPQ:.*");
	
	static FileProcessorWithData fp = null;
	static BellCPQTimerLogsProcessor line = null;

	private static ArrayList detailChannels = new ArrayList();
	private static ArrayList detailService = new ArrayList();
	private static ArrayList detailSubServiceName = new ArrayList();
	private static ArrayList detailSubServiceExp = new ArrayList();
	
	public BellCPQTimerLogsProcessor(String dir, String outDir, String fileStartsWith, String minMs, String maxMs) {
		this.dir = dir;
		this.outDir = outDir;
		this.fileStartsWith = fileStartsWith;
		this.minMs = Utility.time24HourMilliToLong(minMs);
		this.maxMs = Utility.time24HourMilliToLong(maxMs);

		words.setDelimiters(new char[] {' ', '[', ']' });
	}

	public void print(OmfParameters data) {
		
		Integer interval = new Integer((int)(minMs / data.interval));
		int maxInterval = (int)(maxMs / data.interval);
		
		StringWriter writer2 = new StringWriter(outDir + File.separator + "CpqData.tab");
		writer2.open();
		
		Collections.sort(services);

		writer2.write("\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write(services.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < services.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			CpqTimerDataElement dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < services.size(); i++) {
					StatisticalDoubleVector stats = dataElement.byService.get(services.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + Math.round(stats.getAverage()) + "\t" + Math.round(stats.getPercentile(.9)) + "\t" + Math.round(stats.getPercentile(.95)) + "\t" + Math.round(stats.getMaximum()) + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(dataElement.allStats.size() + "\t" + Math.round(dataElement.allStats.getAverage()) + "\t" + Math.round(dataElement.allStats.getPercentile(.9)) + "\t" + Math.round(dataElement.allStats.getPercentile(.95)) + "\t" + Math.round(dataElement.allStats.getMaximum()));
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.close();
		
		writer2 = new StringWriter(outDir + File.separator + "CpqDataPriceByModel.tab");
		writer2.open();
		
		Collections.sort(models);

		writer2.write("\t");
		for (int i = 0; i < models.size(); i++) {
			writer2.write(models.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < models.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			CpqTimerDataElement dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < models.size(); i++) {
					StatisticalDoubleVector stats = dataElement.byModel1.get(models.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + Math.round(stats.getAverage()) + "\t" + Math.round(stats.getPercentile(.9)) + "\t" + Math.round(stats.getPercentile(.95)) + "\t" + Math.round(stats.getMaximum()) + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(dataElement.allStats.size() + "\t" + Math.round(dataElement.allStats.getAverage()) + "\t" + Math.round(dataElement.allStats.getPercentile(.9)) + "\t" + Math.round(dataElement.allStats.getPercentile(.95)) + "\t" + Math.round(dataElement.allStats.getMaximum()));
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.close();
		
		writer2 = new StringWriter(outDir + File.separator + "CpqDataRulesByModel.tab");
		writer2.open();
		
		Collections.sort(models);

		writer2.write("\t");
		for (int i = 0; i < models.size(); i++) {
			writer2.write(models.get(i) + "\t\t\t\t\t");
		}
		writer2.writeLine("All");
		writer2.write("Interval\t");
		for (int i = 0; i < models.size(); i++) {
			writer2.write("Num\tAvg\t90%\t95%\tMax\t");
		}
		writer2.writeLine("Num\tAvg\t90%\t95%\tMax");

		interval = new Integer((int)(minMs / data.interval));
		while (interval.doubleValue() <= maxInterval) {
			CpqTimerDataElement dataElement = perfData.get(interval);
			writer2.write(Utility.longTo24Hour(interval.intValue()*data.interval/1000) + "\t");
			
			if (dataElement != null) {
				
				for (int i = 0; i < models.size(); i++) {
					StatisticalDoubleVector stats = dataElement.byModel2.get(models.get(i));
					
					if (stats != null) {
						writer2.write(stats.size() + "\t" + Math.round(stats.getAverage()) + "\t" + Math.round(stats.getPercentile(.9)) + "\t" + Math.round(stats.getPercentile(.95)) + "\t" + Math.round(stats.getMaximum()) + "\t");
					} else {
						writer2.write("\t\t\t\t\t");
					}
				}
				
				writer2.write(dataElement.allStats.size() + "\t" + Math.round(dataElement.allStats.getAverage()) + "\t" + Math.round(dataElement.allStats.getPercentile(.9)) + "\t" + Math.round(dataElement.allStats.getPercentile(.95)) + "\t" + Math.round(dataElement.allStats.getMaximum()));
			}
			
			writer2.writeLine("");
			
			interval = new Integer(interval.intValue()+1);
		}
		writer2.close();
		
	}

	String lastDate, lastTime;
	public boolean processLine(String str, Object data) {

		OmfParameters parms = (OmfParameters) data;
		if (str != null && str.length() > 50) {
			
			words.setString(str);
			
			String date = words.getWord(0);
			String time = words.getWord(1);
			if (str.charAt(4) != '-' || str.charAt(10) != ' ' || str.charAt(13) != ':') {
				date = lastDate;
				time = lastTime;
			} else {
				if (time.endsWith(":TIMER")) {
					time = time.substring(0, time.length()-6);
				}
				lastDate = date;
				lastTime = time;
			}
			long timeMs = 0L;
			if (time != null) {
				timeMs = Utility.time24HourMilliToLong(time);
			}
			
			if (timeMs >= minMs && timeMs <= (maxMs+parms.interval) && date.equals(parms.date)) {
				
				String stxnPerf = "unknown";
				String thread = "unknown";
				String txnId = null;
				int p = str.indexOf("- End -");
				if (p > 0) {
					int p2 = str.indexOf('[', p);
					int p3 = str.indexOf(']', p);
					stxnPerf = str.substring(p2+1, p3);
					p3 = str.indexOf("(self-tuning)':");
					txnId = str.substring(p3+15, p-1).trim();
				}

				p = str.indexOf("sum of pauses ");
				if (p > 0) {
					int p2 = p+13;
					int p3 = str.indexOf(' ', p2+1);
					stxnPerf = str.substring(p2+1, p3);
					txnId = "Garbage Collection";
				}

				p = str.indexOf(" ExecuteThread:");
				if (p > 0) {
					int p2 = str.indexOf('\'', p);
					int p3 = str.indexOf('\'', p2+1);
					thread = str.substring(p2+1, p3);
				}

				String model = threadModelMap.get(thread);
				p = str.indexOf(" CLONED ");
				if (p > 0) {
					int p2 = str.indexOf("BellCanada");
					int p3 = str.indexOf('.', p2);
					model = str.substring(p2+11, p3);
					threadModelMap.put(thread, model);
				}

				if (Utility.isDecimalNumber(stxnPerf)) {
					long txnPerf = Math.round(Double.parseDouble(stxnPerf));
					
					Integer interval = new Integer((int)(timeMs/parms.interval));
					
					services.add(txnId);
					CpqTimerDataElement dataElement = perfData.get(interval);
					if (dataElement == null) {
						dataElement = new CpqTimerDataElement(interval);
						perfData.put(interval, dataElement);
					}
					
					dataElement.addStats(txnId, txnPerf);
					if (txnId.equals("buildEntitlementAndPrice")) {
						dataElement.addStatsModel1(model, txnPerf);
						models.add(model);
					}
					if (txnId.equals("fireRules")) {
						dataElement.addStatsModel2(model, txnPerf);
						models.add(model);
					}
				}
			}
		}

		return true;
	}

	public boolean recurse(File dirFile, Object data) {
		int i;

		String[] list;
		list = dirFile.list();

		for (i = 0; i < list.length; i++) {
			
			String fileName = list[i];
			
			File child = new File(dirFile, fileName);

			if (child.isFile() && child.getName().startsWith(fileStartsWith)) {
				
				System.out.println("Processing: "+child.getName());
				
				try {

					setCurrentFile(child);

					fp = new FileProcessorWithData(child.getAbsolutePath(), line, data);

				} catch (Exception e) {

					System.out.println("Can't open file: " + child.getAbsolutePath());
					e.printStackTrace();
					System.exit(-1);
				}

				fp.processFile();
				fp.close();
				
			} else if (child.isDirectory()) {

				boolean ret = recurse(child, data);
				if (!ret)
					return ret;

			}
		}

		return true;
	}

	public static void main(String[] args) {

		if (args.length < 7) {
			
			System.err.println("ERROR: You must specify:");
			System.err.println("         dir name");
			System.err.println("         date yyyy-mm-dd");
			System.err.println("         time interval in ms");
			System.err.println("         file starts with");
			System.err.println("         start time (hh:mm:ss:ttt)");
			System.err.println("         end time (hh:mm:ss:ttt)");
			System.err.println("         out dir name");
			System.exit(-1);
				
		}

		File f = new File(args[0]);
		if (!f.isDirectory()) {
			System.out.println("You must specify a directory to start");
			System.exit(0);
		}

		if (args.length > 5) {
			line = new BellCPQTimerLogsProcessor(args[0],args[6],args[3], args[4], args[5]);
		}

		line.setStartPath(f.getAbsolutePath());

		OmfParameters parms = new OmfParameters(args[1], Integer.parseInt(args[2]));
		line.recurse(f, parms);

		line.print(parms);

		exit(0);
	}

	private String matchSubTransation(String txn, String txn2) {

		for (int i = 0; i < detailService.size(); i++) {
			
			if (detailService.get(i).equals(txn)) {
				if (((Pattern)detailSubServiceExp.get(i)).matcher(txn2).find()) {
					return txn+"."+detailSubServiceName.get(i);
				}
			}
		}
		return null;
	}

	
	static private void exit(int num, String msg) {

		System.out.println(msg);

		exit(num);
	}

	static private void exit(int num) {

		if (fp != null)
			fp.close();

		if (line != null) {}

		System.exit(num);
	}

	/**
	 * Gets the currentFile
	 * @return Returns a File
	 */
	public File getCurrentFile() {

		return currentFile;
	}
	/**
	 * Sets the currentFile
	 * @param currentFile The currentFile to set
	 */
	public void setCurrentFile(File currentFile) {

		this.currentFile = currentFile;
		this.currentServer = currentFile.getName();
		int p = currentFile.getName().indexOf('.');
		
		if (p > 15) {
			this.currentServer = currentFile.getName().substring(15, p);
		}
	}

	/**
	 * Gets the startPath
	 * @return Returns a String
	 */
	public String getStartPath() {

		return startPath;
	}
	/**
	 * Sets the startPath
	 * @param startPath The startPath to set
	 */
	public void setStartPath(String startPath) {

		this.startPath = startPath;
	}

}

class CpqTimerDataElement {
	
	Integer interval;
	StatisticalDoubleVector allStats = new StatisticalDoubleVector(100000,50000);
	Hashtable<String, StatisticalDoubleVector> byService = new Hashtable<String, StatisticalDoubleVector>(); 
	Hashtable<String, StatisticalDoubleVector> byModel1 = new Hashtable<String, StatisticalDoubleVector>(); 
	Hashtable<String, StatisticalDoubleVector> byModel2 = new Hashtable<String, StatisticalDoubleVector>(); 
	
	CpqTimerDataElement(Integer interval) {
		this.interval = interval;
	}
	
	void addStats(String service, double value) {
		StatisticalDoubleVector data;
		
		if (service.trim().length()==0) {
			throw new RuntimeException("Blank Transaction");
		}

		allStats.add(value);
		
		data = byService.get(service);
		if (data == null) {
			data = new StatisticalDoubleVector(10000, 5000);
			byService.put(service, data);
		}
		
		data.add(value);

	}
	
	void addStatsModel1(String model, double value) {
		StatisticalDoubleVector data;
		
		if (model.trim().length()==0) {
			throw new RuntimeException("Blank Transaction");
		}

		allStats.add(value);
		
		data = byModel1.get(model);
		if (data == null) {
			data = new StatisticalDoubleVector(10000, 5000);
			byModel1.put(model, data);
		}
		
		data.add(value);

	}

	void addStatsModel2(String model, double value) {
		StatisticalDoubleVector data;
		
		if (model.trim().length()==0) {
			throw new RuntimeException("Blank Transaction");
		}

		allStats.add(value);
		
		data = byModel2.get(model);
		if (data == null) {
			data = new StatisticalDoubleVector(10000, 5000);
			byModel2.put(model, data);
		}
		
		data.add(value);

	}
}
