import java.util.ArrayList;
import java.util.Iterator;

//import com.ibm.xtq.xml.types.EntitiesType;

/*
 * Created on Jan 7, 2015
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class ScenarioData {

	String hoi;
	String scenarioName;
	ArrayList<String> calls = new ArrayList<String>();
	ArrayList<Integer> timesMs = new ArrayList<Integer>();
	ArrayList<Long> endTimes = new ArrayList<Long>();
	long startTime = 0;
	String lastPcsAction = "";
	
	public ScenarioData(String hoi, String call, long endTime, int timeMs) {
		this.hoi = hoi;
		calls.add(call);
		timesMs.add(timeMs);
		this.endTimes.add(endTime);
		
		this.startTime = endTime-timeMs;
	}
	
	public void addCall(String call, long endTime, int timeMs) {
		calls.add(call);
		timesMs.add(timeMs);
		this.endTimes.add(endTime);
	}

	public String getScenario() {
		
		StringBuilder ret = new StringBuilder();
		ret.append(calls.get(calls.size()-1));
		ret.append(':');
		boolean first = true;
		
		for (int i = 0; i < calls.size()-1; i++) {
			if (! first) {
				ret.append(',');
				
			} else {
				first = false;
			}
			ret.append(calls.get(i));
		}
		
		return ret.toString();
	}
	
	public void cleanScenario() {
		
		int last = calls.size()-1;
		long endTime = endTimes.get(last);
		long startTime = endTime - timesMs.get(last).longValue();
		
		for (int i = calls.size()-2; i >= 0; i--) {
			long end = endTimes.get(i);
			long start = end - timesMs.get(i).longValue();
			
			if (start < startTime || end > endTime) {
				calls.remove(i);
				endTimes.remove(i);
				timesMs.remove(i);
			}
		}
		
	}
	
	public String getScenarioName() {
		return scenarioName;
	}

	public void setScenarioName(String scenarioName) {
		this.scenarioName = scenarioName;
	}

	public long getStartTime() {
		return startTime;
	}


}
