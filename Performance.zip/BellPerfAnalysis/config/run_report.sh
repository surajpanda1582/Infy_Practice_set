#!/bin/ksh
# $1 = directory
# $2 = date
# $3 = starttime
# $4 = endtime

nice -n 10 java -Xmx2048M -cp /support/logs/performance/config/BellOmOmfPerfAnalysis.jar BellOmfPerformanceLogsProcessor $1/OMF/applogs $2 120000 performance_OMF $3 $4 $1 /support/logs/performance/config/OmfTransaction.cfg
