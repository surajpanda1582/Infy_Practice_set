#!/bin/ksh
# $1 = directory
# $2 = date
# $3 = starttime
# $4 = endtime

# cd /support/logs/ordermax/$1
nice -n 10 java -Xmx3072M -cp /support/logs/performance/config/BellOmOmfPerfAnalysis.jar BellOmPerformanceLogsScenerioProcessor $1/OM/applogs $2 120000 omaccess_ OMSessionDrop_ omperf_OM $3 $4 $1 /support/logs/performance/config/reportScenarios.txt

# cd /support/logs/omf/$1
nice -n 10 java -Xmx2048M -cp /support/logs/performance/config/BellOmOmfPerfAnalysis.jar BellOmfPerformanceLogsProcessor $1/OMF/applogs $2 120000 performance_OMF $3 $4 $1 /support/logs/performance/config/OmfTransactionHoiScenarios.cfg

java -Xmx2048M -cp /support/logs/performance/config/BellOmOmfPerfAnalysis.jar BellProcessMergePerformanceOmOmf /support/logs/performance/config/PerformanceMerge.cfg $1

